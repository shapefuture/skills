# Evals (development-time only — SKILL.md never references these)

- `evals.json` — 13 behaviour cases, prompts deliberately disjoint from `references/examples.md`.
- `trigger_evals.json` — 12 should-trigger / 10 near-miss queries for description tuning.

Run each behaviour case with and without the skill, grade the `expectations` blind (grader sees outputs, not which arm), and record pass rates per expectation. Retire any SKILL.md instruction whose removal doesn't lower a pass rate; add a case whenever a real-world failure is observed.

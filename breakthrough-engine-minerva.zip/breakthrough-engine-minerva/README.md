# Breakthrough Engine — Minerva HC edition

A refined Breakthrough Engine skill that preserves its original stuck-problem workflow and adds Minerva University's official Cornerstones Habits of Mind (HoM) and Foundational Concepts (FC) as a selective rigor layer.

## What changed

- Kept the original DIRECT / CRISIS / ENGINE / DEEP routing, stuck-type diagnosis, reframing, independent attacks, red-team pass, claim ledger, decisive tests, and convergence protocol.
- Added HC routing at the points where it strengthens the work: problem definition, systems diagnosis, evidence/bias checks, hypothesis design, trade-offs, testing, and stakeholder legitimacy.
- Added explicit safeguards against HC name-dropping, forcing HCs into simple/crisis requests, and misattributing Breakthrough Engine methods to Minerva.
- Bundled the full 76-page Cornerstones HC reference set, its index, a concise integration bridge, and additional behavior checks for the HC layer.

## Structure

```text
SKILL.md
references/
  hc/                         # INDEX.md + 76 Minerva HC Handbook pages
  minerva-hc-bridge.md        # Quick mapping from engine stages to HCs
  guides.md                   # Catalog of 45 Minerva faculty custom guides
  crack-moves.md              # Original stuck-type move catalog
  epistemics.md               # Original evidence/claim-ledger guidance
  examples.md                 # Original worked examples
  move-library.md             # Original move reference
  protocols.md                # Original protocol detail
  solver-briefs.md            # Original DEEP-mode briefs
evals/
  evals.json                  # Original behavior cases
  trigger_evals.json          # Original trigger tests
  minerva-hc-evals.json       # New HC integration tests
```

## Use

Load `SKILL.md` as the skill entry point. For a nontrivial stuck problem, it directs the agent to `references/hc/INDEX.md` and only the few HC pages that fit the case. Direct answers, emergencies, and plain-conversation requests remain lightweight. For reference-only use, start at `references/hc/INDEX.md`.

## Official reference attribution

The HC reference pages are sourced from Minerva University's public Cornerstones HC Handbook. Each page preserves its Minerva source URL; the catalog begins at <https://my.minerva.edu/academics/hc-resources/hc-handbook/>. The HC material is included as an educational reference and is not a Minerva University product or endorsement. Minerva University retains its rights in its handbook content. The Breakthrough Engine's independent protocols and methods are not Minerva HCs.

## Origin

The Breakthrough Engine files and evaluation suite were downloaded from `shapefuture/skills` and preserved as the starting point. This edition adds the Minerva HC layer and its bundled reference pages.

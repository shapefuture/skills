# Evals (development-time only — SKILL.md never references these)

- `evals.json` — original behavior cases, prompts deliberately disjoint from `references/examples.md`.
- `trigger_evals.json` — original should-trigger / near-miss queries for description tuning.
- `minerva-hc-evals.json` — six added cases to check that HCs sharpen reasoning selectively, don't replace the engine, and stay out of simple/direct answers.

Run each behaviour case with and without the skill, grade the `expectations` blind (grader sees outputs, not which arm), and record pass rates per expectation. Retire any SKILL.md instruction whose removal doesn't lower a pass rate; add a case whenever a real-world failure is observed.

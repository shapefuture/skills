# Protocols in depth

## 1. Impossibility protocol (S10): walls have premises

An impossibility result is a conditional statement: *if* these premises hold, *then* X can't be done. The way through is almost always to find a premise that doesn't apply to *this* case.

### Worked walls

| Wall | Exact premises | Known ways through |
|---|---|---|
| **Arrow's theorem** (ranked voting) | 3+ options; voters submit rankings; any ranking profile is allowed; Pareto; independence of irrelevant alternatives; no dictator | Use cardinal or approval ballots, so the method is no longer purely rank-based. Strategic voting remains possible (Gibbard). Restrict to *single-peaked* preferences, where majority rule picks the median and is coherent; deliberation that structures the issue along one dimension can produce this. Relax independence of irrelevant alternatives deliberately (e.g. Borda). Change the question so fewer options are on the table. |
| **CAP theorem** (distributed data) | During a network *partition*, you must choose consistency or availability | Partitions are rare, so design for the normal case (PACELC: when there is no partition, the tradeoff is latency vs. consistency). Use CRDTs for strong eventual consistency. Choose consistency per operation, not per system. |
| **NP-hardness** | Worst case, over *all* instances, requiring exact optimality | Real instances have structure that SAT and integer-programming solvers exploit. Use approximation with a guarantee, fixed-parameter tractability on a small parameter, randomisation or average-case analysis, or change the objective to "good enough by Friday". |
| **Carnot limit** (heat engines) | Converting heat to work between two temperatures | Use a process that isn't a heat engine (fuel cells convert chemical energy to electricity directly). Use the waste heat (cogeneration). Change the temperatures. |
| **Shannon capacity** | One channel with fixed bandwidth and signal-to-noise ratio | Add channels (MIMO spatial multiplexing), more bandwidth or a better SNR. Compress the source. Send less by sharing context, i.e. transmit the difference. |
| **Monetary trilemma** | Fixed exchange rate, free capital flows and independent monetary policy: you can have only two | Partial or temporary capital controls, managed bands, or a currency union. Choose consciously which two, and when. |
| **"Nobody will pay"** (economic) | The payer and the beneficiary are the same party, and value is per unit | Find the indirect beneficiary. Delink revenue from volume. Bundle. Use pull incentives or advance commitments. Change who pays. |
| **Veto player** (political) | The decision has to go through this venue, and this actor can block it | Change the venue, sequence decisions so the veto is never triggered, compensate the vetoer, split the decision, or create facts on the ground through pilots. |

### Procedure

1. **Classify the wall.** Physical law, theorem, complexity bound, economic, political, or merely unprecedented.
2. **Write the premises precisely.** Search for the formal statement if you are unsure; don't recall it loosely.
3. **Test each premise against this specific situation.** For each, ask whether it actually holds here, and whether you could make it stop holding.
4. **Change the objective:** optimal → good enough, certain → probable, everywhere → where it matters, permanent → renewable.
5. **Move layers:** a wall at the physical layer may be avoidable at the system, market or social layer, and vice versa.
6. **If the wall holds:** say it plainly. Stop spending effort on the wall itself and redirect to least-regret design and managing the tension. Telling people exactly where the wall is, and that it is real, is a valuable answer in itself.

---

## 2. Wicked protocol (S11)

From Rittel & Webber (1973). Use the ten characteristics to confirm the diagnosis, rather than pattern-matching on "it's hard":

1. There is no definitive formulation.
2. There is no stopping rule.
3. Solutions are good or bad, not true or false.
4. There is no immediate or ultimate test of a solution.
5. Every attempt is a one-shot operation that leaves traces.
6. There is no enumerable set of solutions.
7. Every case is essentially unique.
8. Each problem is a symptom of another.
9. The choice of explanation determines the resolution.
10. The planner has no right to be wrong.

If most of these apply, it is wicked. If two or three apply, it is probably complex with a values conflict, and S5/S8 moves may be enough.

### The moves

1. **Make "better" the target and redefine success.** Use per-group improvement metrics, plus a relational metric (are relationships between the factions improving?).
2. **Map the field.** For each faction, record its rationality (individualist, hierarchist, egalitarian or fatalist), what it must protect, what it fears, and whether it can veto. Then map the institutions whose authority depends on the problem *persisting* (Foucault's problematisation). That is often the maintaining force.
3. **Find the overlap:**
   - Agreement on actions without agreement on reasons.
   - Backcasting to a shared future that factions which disagree about today can endorse.
   - "Two-eyed seeing": hold different knowledge systems side by side instead of ranking one above the other.
4. **Build a clumsy, safe-to-fail portfolio.** Run 4–8 small interventions, each legible to at least one rationality, each with a learning goal, a kill criterion and a scale-up trigger. Fund the conventional and unconventional streams at the same time (Sun Tzu's *zheng* and *qi*), not one after the other.
5. **Engineer the process.** Decide who is in the room, including the people affected, who hold local knowledge experts don't. Surface objections privately before public positions harden. Make the decision rights explicit and record the reasoning, not just the decision. Legitimacy is load-bearing.
6. **Win a kernel.** Choose a subproblem that is small, visible, high-leverage and broadly agreed. Winning it builds the coalition, the trust and the data for the next step (Weick's "small wins").
7. **Install learning loops.** Set signposts for the key assumptions, hold review points, and give someone the authority to change course. Treat implementation as inquiry.
8. **Name the limits.** Several of these steps need real people. Offer facilitation scripts, stakeholder maps and meeting designs the user can run. Don't simulate a consensus.

**Default anti-pattern to avoid:** an elegant, expert-designed solution built inside one rationality. It will be technically sound and resisted by everyone else.

---

## 3. Commitment protocol (irreversible spending: hardware, R&D, architecture, suppliers)

The point of a research phase is not to reduce *total* uncertainty. It is to **move uncertainty from irreversible decisions to reversible ones.** A design whose only remaining unknowns are reversible is ready to build.

- **Allocate effort by reversibility.** Irreversible decisions (cash spent, architecture frozen, supplier committed) get deep analysis. Reversible ones (positions, mounts, firmware constants) get *none*; leave them open on purpose.
- **Simulate before measuring.** In order: compute from what you already have, bound it, neutralise it, and only then measure. Writing "needs a test rig" without attempting the computation means that step hasn't been earned. Aim for a margin large enough that being wrong by 10× doesn't matter, rather than for precision.
- **Neutralise instead of resolving.** Price two things: answering the unknown, and buying the component or design change that makes both answers work. If the second is cheaper, the question was never a research question.
- **Corroboration needs independent origins.** Two documents quoting identical figures may share a single source. Name each source's origin.
- **Match benchmark conditions** before computing a ratio: the same load, quantity, duty cycle and product scope (DIY vs. retail). Mismatched conditions produce fake 5× gaps.
- **Assume optimism in unverified numbers.** Unverified favourable numbers tend to break against the design, because vendors have an incentive to overstate. Keep them out of headlines and computed tables until verified.
- **Use an arithmetic gate before expensive generation.** Kill any candidate whose own numbers don't add up inside its own budget. The gate must be arithmetic only, never taste.

Credit: distilled from an n=1 instrumented hardware project. Treat the mechanisms as transferable and the magnitudes as not.

---

## 4. Crisis protocol

1. Take the most stabilising action that is **reversible**. Being correct comes later.
2. Get one decision-maker and one channel for facts.
3. Avoid irreversible actions unless forced. "Better" moves are unknowable right now.
4. Record what you observe for the post-incident analysis.
5. Once the situation is legible, re-route. The underlying cause is often an S5 maintaining force (an incentive or a loop) worth a full ENGINE run.

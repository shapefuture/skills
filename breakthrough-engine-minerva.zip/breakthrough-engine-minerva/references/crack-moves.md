# Crack moves: an expanded catalogue by stuck-type

Load the section(s) for the stuck-types diagnosed in SKILL.md §2. Every move here is a *Move* (do it now), a *Method* (follow the steps), or a *Model* (map the situation onto it and read off the implication). Moves marked **[humans]** need real participants; name the gap if you can't convene them.

## S1 — Wrong representation
- **Representation change is the insight.** Impasses break when the problem's representation changes (Kaplan & Simon 1990; Ohlsson's representational change theory). Spend effort generating framings, not solutions.
- **Inventor's paradox (Pólya).** The more ambitious general problem is often easier — it exposes structure the special case hides.
- **Isomorph search.** Ask "what known, solved problem has this exact causal structure?" Map component by component (see the far-transfer bank below).
- **Notation swap.** Redraw it as a graph, a market, a queue, a game, a flow network, a control loop, an evolutionary population, a constraint-satisfaction problem. Each formalism comes with its own toolbox.
- **Ladder of abstraction.** Restate it at five levels: mechanism → function → intent → value → identity. The stuck level is usually not the one being worked on.
- **Buchanan's four orders.** Is it a sign problem, a thing problem, an interaction problem or a system problem? Breakthroughs often come from switching orders.

## S2 — False constraint
- **Provenance trace.** Ask who wrote the rule, when, and why, and whether that reason still holds.
- **Physics vs. engineering.** Would the constraint still bind with unlimited budget and any manufacturing process? If not, it is negotiable.
- **Constraint-inversion sweep.** Negate each constraint in turn and classify the result as collapsed, softened or unchanged.
- **Chesterton's fence.** Write the strongest case for why the constraint exists before removing it. If you can't write one, remove it. If you can, that case is the real constraint.
- **Lock-in audit.** Ask what is enforced only by switching cost, not by merit.

## S3 — Hidden constraint / requirement
- **Failure autopsy.** Line up every failed attempt. The shared failure point is the hidden constraint.
- **Interface audit.** Wherever two teams, systems or parties meet, list what each side assumes about units, definitions, formats and success criteria. The Mars Climate Orbiter was lost at exactly such a seam: one team worked in imperial units and the other in metric.
- **Need vs. solution.** "We need an app" is a solution. Ask: if this solution were banned, what need would remain?
- **Stater vs. judge.** Check whether the person stating the requirement is the one who will judge success.
- **Measurability.** Every adjective doing real work ("robust", "scalable") needs a number.

## S4 — Contradiction
- **Technical vs. physical contradiction (TRIZ).** Two parameters conflicting is a technical contradiction. One parameter needing two opposite values is a physical contradiction. Reduce a technical contradiction to the physical one underneath it, then separate.
- **Separation** in space, time, condition, or between part and whole.
- **Ideal final result.** The function happens and the system doesn't exist. Work backward to the closest real version.
- **Resources already present** (the ASIT "closed world" rule). Solve using only elements already in the system or its surroundings: fields, waste, idle time, the environment.
- **Symmetry breaking.** If the tradeoff exists because the situation is symmetric, introduce an asymmetry.
- **Polarity check.** If every "solution" recreates the tension in a new form, it is a polarity to *manage* (oscillate on purpose), not a contradiction to solve.

## S5 — Maintaining force
- **Named actor + specific gain.** "Inertia" and "culture" are not explanations. Name who gains what from the status quo.
- **Loop map.** Draw the reinforcing and balancing loops, then find the delay that makes the system oscillate or overshoot.
- **Meadows' leverage ladder,** from weakest to strongest: parameters → buffers → stock/flow structure → delays → balancing loops → reinforcing loops → information flows → rules → self-organisation → goals → paradigm. Failed fixes usually aimed at parameters.
- **Mechanism design.** Redesign the rules so the desired behaviour becomes each actor's dominant strategy. Delinking revenue from volume is a canonical example (see examples.md).
- **Goodhart audit.** Compare the stated goal with what is actually measured and rewarded. The system optimises the measured version.
- **Baptists and bootleggers.** Find the moral argument and the economic interest that jointly defend the status quo.
- **Autocatalytic set.** Find the components that sustain each other, and insert a breaker rather than attacking any single member.
- **Jevons check.** Ask what new demand will absorb an efficiency gain.

## S6 — Knowledge gap
- **Cheapest decisive test.** Work down this ladder: compute → bound → neutralise → search → ask an expert → small probe → physical test.
- **Value of information.** If perfect information would be worth less than it costs to get, skip it and decide now.
- **Break-even inversion.** Ask what value the unknown would need to take for the decision to flip, then sanity-check that threshold.
- **Tagged Fermi chain.** Tag every link. Halve the shakiest one and see whether the conclusion survives.
- **The crib.** One verified anchor fact collapses the hypothesis space more than lots of unverified generation does (the cryptanalysts' "crib").

## S7 — Capability / resource gap
- **Exaptation scan.** What already exists, built for something else, that performs this function? Byproducts, waste streams and idle assets count.
- **Frugal reframe (jugaad).** Ask what the version costing a tenth, built from parts already at hand, would look like.
- **Adjacent possible.** Ask what has only just become feasible because of a new capability, price drop, regulation or dataset.
- **Borrow the capability:** partner, license, outsource, or recruit the user.
- **Sequence.** Ask which first step creates the capability the second step needs.

## S8 — Values / legitimacy conflict
- **Four rationalities (cultural theory).** Classify each faction as individualist, hierarchist, egalitarian or fatalist. A solution built entirely within one rationality provokes the other three.
- **Clumsy solutions.** Build a deliberately messy settlement with a recognisable piece for each rationality.
- **Incompletely theorised agreement (Sunstein).** Agree on the action and leave the reasons unresolved.
- **Constructive controversy.** Each side argues its own case, then switches roles and argues the other's, then the group synthesises. **[humans]** Solo substitute: write a steelman of each side, and flag that it lacks a real advocate who would push back.
- **Pre-consultation (nemawashi).** Hold private one-to-one conversations before any public proposal, while objections can still be raised without loss of face. **[humans]**
- **Veil-of-ignorance test.** Would you endorse this without knowing which stakeholder you would be?
- **Relational metric.** Track whether relationships were strengthened or damaged. Damaged relationships sabotage technically correct fixes.

## S9 — Coordination / strategic
- **Name the game:** prisoner's dilemma, stag hunt, chicken or battle of the sexes. The right move depends on which one it is.
- **Focal points.** Choose the option that is salient *because* both sides can see that it is salient.
- **Commitment devices and costly signals.** Make a promise credible by making it expensive to break or to fake.
- **Fallback option first.** Improve your own best alternative to a deal before negotiating.
- **Two-level games.** Every counterpart also has an internal table, so design for their internal politics.
- **Three faces of power (Lukes).** Look beyond who decides to who keeps issues off the agenda and whose wants have been shaped.
- **Repeated game.** Turn a one-shot defection into an iterated relationship.

## S10–S12
See `protocols.md` for impossibility (S10) and wicked (S11) problems. For ill-posed problems (S12), use the goal ladder, measurability and need-vs-solution checks in S3, and the dissolve operator in SKILL.md §3.

---

## Far-transfer bank (check before inventing; every entry still needs its own component mapping)

| Source mechanism (field) | Structure it solves | Candidate targets |
|---|---|---|
| Below-threshold decay: SIR epidemic model, R₀ < 1 (epidemiology) | Spread is self-sustaining only above a reproduction threshold | Referral growth, advocacy within customer accounts, adoption of norms |
| Critical mass (chain reactions) | Value exists only above a participation threshold | Marketplaces, protocols, communities |
| Red Queen coevolution (evolutionary biology) | Matching a rival only restores relative position | Feature-parity races: change the dimension you compete on |
| Asymmetric warfare | The incumbent's strengths become liabilities in certain segments | Entering the segments the incumbent can't serve |
| Keystone species (ecology) | Importance comes from structural position, not size | Finding the component whose loss cascades |
| Annealing (metallurgy) | Converging too fast freezes in a poor solution | Pacing exploration before commitment |
| Bet-hedging and algorithm portfolios (biology, CS) | Under real uncertainty, variety beats the single best guess | Why a portfolio rather than one bet |
| Crib-based cryptanalysis | One verified anchor collapses the search | Prioritising verification |
| Market making / clearing houses (finance) | Counterparty risk blocks trade | Trust gaps between parties that won't deal directly |
| Immune memory, vaccines (immunology) | Rehearsing against a weakened threat builds a lasting defence | Red-team drills, chaos engineering |
| Mycorrhizal networks (ecology) | Resource sharing through an intermediary that takes a cut | Platform and ecosystem design |
| Advance market commitments, pull incentives (health economics) | Nobody invests because future demand is uncertain or deliberately suppressed | Public goods, stewardship goods, R&D markets |
| Insurance pooling | Individually catastrophic risks become collectively affordable | Shared risk among small actors |
| Queueing theory (Little's law L = λW) | Throughput, wait time and work-in-progress are linked by an identity | Any backlog problem |
| Control theory (delays + gain → oscillation) | Overreaction to delayed signals | Bullwhip effects, hiring cycles, inventory |
| Error-correcting codes (information theory) | Reliable output from unreliable parts through redundancy and structure | Unreliable processes, people or suppliers |

**Mapping test:** name what plays each component's role in the target problem. Then check that the mapping works in reverse, teaching something back to the source field. If either check fails, it is a metaphor, so drop it.

## Combination operators (for DEEP mode after named moves are exhausted)

The eight primitives are INVERT, RELAX, RESCALE, RETIME, RECAST-ACTOR, RECOMBINE, RELOCATE-BOUNDARY and SUBSTITUTE-MECHANISM.

1. Bind each primitive to a concrete operand in *this* problem. A primitive with no operand is just a word.
2. Walk the 28 unordered pairs. Apply both operations to the problem.
3. Filter each pair in one sentence each: nonsense, a duplicate of a named move, or worth a look.
4. Check any survivor against prior art ("why hasn't this been done?").
5. **Stop rule:** if no pair survives, report that as the finding. Go to triples only to sharpen a specific surviving pair.

Candidates from this process are new and unvalidated. Tag them no higher than `derived` on the reasoning, label them as freshly generated, and say so in the output.

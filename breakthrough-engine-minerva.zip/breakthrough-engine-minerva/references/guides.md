# Minerva Custom HC Guides — Catalog

45 in-depth guides written by Minerva faculty, organized by cornerstone. Use them for deep dives after the HC page itself; related-HC tags link to local pages.

## Formal Analyses (12)

### Inductive Reasoning
- **Citation:** Wilkins, J. (2020, Aug). Inductive Reasoning. Minerva University.
- **Related HCs:** [#induction](hc/induction.md)
- **Guide:** [open](https://docs.google.com/document/d/1IWr7Lxu_l0Gn84KKEM8--fLfpCaHsVdKIeutsg0PjzU/edit)

### Fallacies Applications, Document 1: Fallacies Analysis Framework and Excerpts
- **Citation:** Flora, T., Koloskov, N., Stan, T., & Terrana, A. (2021, Sept 14). Fallacies Applications, Document 1: Framework & Excerpts. Minerva University.
- **Related HCs:** [#fallacies](hc/fallacies.md)
- **Guide:** [open](https://docs.google.com/document/d/1ly2V0TXWdwSx3i1Mnt6Hhp7i6m_Ar8CoGhR6dUvybnE/edit)

### Fallacies Applications, Document 2: Solutions
- **Citation:** Flora, T., Koloskov, N., Stan, T., & Terrana, A. (2021, Sept 14). Fallacies Applications, Document 2: Solutions. Minerva University.
- **Related HCs:** [#fallacies](hc/fallacies.md)
- **Guide:** [open](https://docs.google.com/document/d/1POnVKFHVp6kZ3UIlNgCVMixcuVlp_4d4BuPgfOS-YeQ/edit)

### Estimation Strategies
- **Citation:** Wilkins, J. F. (2021, Sept). Estimation Strategies. Minerva University.
- **Related HCs:** [#estimation](hc/estimation.md)
- **Guide:** [open](https://docs.google.com/document/d/1AbEGM6RYrtlZW8h_Dz3le3Oc75M2E-T8PzA4_i-fi3s/edit)

### Variables
- **Citation:** Flora, T., Koloskov, N., Terrana, A., & Hadavand, A. (2023, Sept 19). Variables. Minerva University.
- **Related HCs:** [#variables](hc/variables.md)
- **Guide:** [open](https://docs.google.com/document/d/1gb9luIly9JycgLutyZ7XMDqlCn6I4i-OOssk9V2J3Sk/edit)

### Interpreting Probabilities
- **Citation:** Wilkins, J. (2020, Oct). Interpreting Probabilities. Minerva University.
- **Related HCs:** [#probability](hc/probability.md)
- **Guide:** [open](https://docs.google.com/document/d/1ikOunBGOK_D8rGUOcC2b1q4AJ8r6X58cK8UwZDdB_I4/edit)

### What is Statistical Inference?
- **Citation:** Terrana, A. (2024, Oct). What is Statistical Inference? Minerva University.
- **Related HCs:** [#distributions](hc/distributions.md), [#significance](hc/significance.md), [#confidenceintervals](hc/confidenceintervals.md)
- **Guide:** [open](https://docs.google.com/document/d/1-WZpMTLNOerZpfi4o9kNgmANrf7IpbsdxwfacUx84pE/edit)

### Inference for the Population Slope in Linear Regression
- **Citation:** Terrana, A. (2023, Dec). Inference for the Population Slope in Linear Regression. Minerva University.
- **Related HCs:** [#regression](hc/regression.md), [#significance](hc/significance.md), [#confidenceintervals](hc/confidenceintervals.md)
- **Guide:** [open](https://docs.google.com/document/d/1dXvCZ0X5Z4ScIZ9Z_GzbfkJxDcfvOMc_lq1hvvv9PaQ/edit)

### Optimization Cornerstone Guide
- **Citation:** Shafkat, I. & Terrana, A. (2025, Jan 23). Optimization Cornerstone Guide. Minerva University.
- **Related HCs:** [#optimization](hc/optimization.md), [#algorithms](hc/algorithms.md)
- **Guide:** [open](https://docs.google.com/document/d/1A0_k3bHmnp9rDRpPgTnEm0EFJg4gyBJbnnuv9iKvR0o/edit)

### Utility, Expected Utility, and Risk
- **Citation:** Terrana, A & Wilkins, J. (2025, Feb). Utility, Expected Utility, and Risk. Minerva University.
- **Related HCs:** [#utility](hc/utility.md)
- **Guide:** [open](https://docs.google.com/document/d/1z5cqDEGsg4tsmIo9slRz8M_Sm32Q6NDl49oeRzWG33o/edit)

### Delay Discounting
- **Citation:** Wilkins, J. (2021, Feb 27). Delay Discounting. Minerva University.
- **Related HCs:** [#utility](hc/utility.md)
- **Guide:** [open](https://docs.google.com/document/d/1APdwWQ7hEY2474lcCz20TpJsG-wVTTpWqOhXLkkELY8/edit)

### Decision Tree Strategies
- **Citation:** Flora, T., Antonovych, D., & Terrana, A. (2026, Mar). Decision Tree Strategies. Minerva University.
- **Related HCs:** [#decisiontrees](hc/decisiontrees.md)
- **Guide:** [open](https://docs.google.com/document/d/1uFaDkib-Ff-sbJaVYHDy1mbnTAJhFT3v3WrlztMxOy8/edit)

## Empirical Analyses (9)

### Common Learning Techniques: Using #scienceoflearning to Make the Most of Your Study Time
- **Citation:** Dosmann, A. and Stein, G. (2019). "Common Learning Techniques: Using #scienceoflearning to Make the Most of Your Study Time." Minerva University.
- **Related HCs:** [#scienceoflearning](hc/scienceoflearning.md)
- **Guide:** [open](https://docs.google.com/document/d/1gDJ8DMbIgKNzb_xK71i3WsnPMF7hbsfBBnn4LPiBnLk/edit)

### Using #rightproblem to characterize complex problems
- **Citation:** Dosmann, A. (2019). "Using #rightproblem to characterize complex problems." Minerva University.
- **Related HCs:** [#rightproblem](hc/rightproblem.md)
- **Guide:** [open](https://docs.google.com/document/d/1hoiSKEGZ_zTg3I9mObblCq1rAq1zcu2cZYBuNnvq708/edit)

### Identifying components of complex problems: #breakitdown
- **Citation:** Dosmann, A. (2023). "Identifying components of complex problems: #breakitdown." Minerva University.
- **Related HCs:** [#breakitdown](hc/breakitdown.md)
- **Guide:** [open](https://docs.google.com/document/d/1mOjUHvGCLH6H3ZA2Ahd9Gng5voILSEzSRZESz-TPXug/edit)

### Breaking down problems: Fishbone Diagrams and Outlines
- **Citation:** Ahuja, A. (2015). "Breaking down problems: Fishbone Diagrams and Outlines." Minerva University.
- **Related HCs:** [#breakitdown](hc/breakitdown.md)
- **Guide:** [open](https://docs.google.com/document/d/1WX3h--rtWzDfuFqav97IjVncf9E3iKEycucFYr3rJlc/edit)

### Gap analysis
- **Citation:** Gahl, M. K. (2018). "Gap analysis". Minerva University.
- **Related HCs:** [#gapanalysis](hc/gapanalysis.md)
- **Guide:** [open](https://docs.google.com/document/d/1X8cpDalqsna-do1S1IkZfNwUKtjqwjnZngtdsBJdrho/edit)

### A brief guide to different categories of heuristics
- **Citation:** Dosmann, A. (2020). "A brief guide to different categories of heuristics." Minerva University.
- **Related HCs:** [#heuristics](hc/heuristics.md)
- **Guide:** [open](https://docs.google.com/document/d/1FsL2FVFa1t_UD8KeQNqRTQ39EwuadjGM5kgSL-zK0nw/edit)

### Creative heuristics for novel solutions
- **Citation:** Dosmann, A. (2019). "Creative heuristics for novel solutions." Minerva University.
- **Related HCs:** [#heuristics](hc/heuristics.md)
- **Guide:** [open](https://docs.google.com/document/d/1mFfTyY-VZEtfrTWNJc0pZsMSws-wqf7atdaFgt7Dw9s/edit)

### Developing hypotheses and determining their testability and plausibility
- **Citation:** Zoogman, P. (2020). Developing hypotheses and determining their testability and plausibility. Minerva University.
- **Related HCs:** [#hypothesisdevelopment](hc/hypothesisdevelopment.md), [#testability](hc/testability.md), [#plausibility](hc/plausibility.md)
- **Guide:** [open](https://docs.google.com/document/d/1xEqs2OkagDNfeAvzVgzsI5H3EZJSTTMBsra_ITeuJ50/edit)

### Defining Case Studies as a Research Method
- **Citation:** Donnelly, K. (2022). Defining Case Studies as a Research Method. Minerva University.
- **Related HCs:** [#casestudy](hc/casestudy.md)
- **Guide:** [open](https://docs.google.com/document/d/1_z7-4x65UBKOrIomyFcFfE1yNsk8nH8cOVpR0B2A9zE/edit)

## Complex Systems (16)

### Characteristics of Complex Systems – a Brief Introduction
- **Citation:** Sheskin, M. (2021). Characteristics of Complex Systems – a Brief Introduction. Minerva Guide 3.
- **Related HCs:** [#systemmapping](hc/systemmapping.md), [#levelsofanalysis](hc/levelsofanalysis.md), [#emergentproperties](hc/emergentproperties.md), [#complexcausality](hc/complexcausality.md), [#networks](hc/networks.md), [#systemdynamics](hc/systemdynamics.md)
- **Guide:** [open](https://docs.google.com/document/d/1cxCp8FqZB_bN_AaMTUgAnv36gu0bDEHpRwMgkEI5VX8/edit)

### Organizational Structure in Complex Systems
- **Citation:** McAllister, K. (2019). Organizational Structure in Complex Systems. Minerva Guide 10.
- **Related HCs:** [#systemmapping](hc/systemmapping.md), #orgstructure
- **Guide:** [open](https://docs.google.com/document/d/1zv1RS5KRTSYlMC2LnOpi1jnNlarCQYLqKaRt2gdKIZM/edit)

### Levels of Analysis for Evaluating Complex Systems
- **Citation:** McAllister, K. (2018, August). Levels of Analysis for Evaluating Complex Systems. Minerva Guide 7.
- **Related HCs:** [#levelsofanalysis](hc/levelsofanalysis.md)
- **Guide:** [open](https://docs.google.com/document/d/1x2-iCWle8LPHG2_wuTLDmqOGNf26v8Cm23huUm-looE/edit)

### Network Analysis
- **Citation:** McAllister, K. and Wilkins, J. F. (2020, August). Network Analysis. Minerva Guide 2 v3.0.
- **Related HCs:** [#networks](hc/networks.md)
- **Guide:** [open](https://docs.google.com/document/d/1h_dpjb_UhDEw8Trwk-JqDS8M-wK3P1E-uGtX4FEJVH0/edit)

### System dynamics
- **Citation:** Sheskin, M. (2021) System Dynamics. (Perry, T.J. Ed.) Minerva Guide 4 v1.0.
- **Related HCs:** [#systemdynamics](hc/systemdynamics.md)
- **Guide:** [open](https://docs.google.com/document/d/19GrL26OrUNVtHj-zO745TBegVB5S3nvKKUKWMdhtKBc/edit)

### Psychological explanation: Analyzing agent behavior in a complex system
- **Citation:** McAllister, K., Niv, S., Ivanov, D. & Fourie, K. (2022). Psychological explanation: Analyzing and predicting the behavior of complex agents. Minerva Guide.
- **Related HCs:** [#psychologicalexplanation](hc/psychologicalexplanation.md)
- **Guide:** [open](https://docs.google.com/document/d/1w2i7me_VsZU4MX5Pfc2gzywFM3Ak0XQ6cqzHoWJfAc8/edit)

### Introducing individual #differences
- **Citation:** McAllister, K. & Niv, S. (2022). Introducing individual #differences. Minerva Guide.
- **Related HCs:** [#psychologicalexplanation](hc/psychologicalexplanation.md), [#differences](hc/differences.md)
- **Guide:** [open](https://docs.google.com/document/d/1lJ-hLaZyCfWY4RsvZZWiBsa5T2WXyl-aZPsZn7iG1Rk/edit)

### Deception in Complex Social Systems
- **Citation:** McAllister, K. (2020). Deception in Complex Social Systems. Minerva Guide 6 v1.1
- **Related HCs:** [#psychologicalexplanation](hc/psychologicalexplanation.md)
- **Guide:** [open](https://docs.google.com/document/d/1js0AWiJUW8P9y2j7WWzpJ6cvYwY3Y_DGTw6Sa5QOgMY/edit)

### Utility – Modeling Complex Social Systems with Rational Choice Theory
- **Citation:** Perry, T. & Morgan, R. (2023). Utility - Modeling Complex Social Systems with Rational Choice Theory. Minerva Guide.
- **Related HCs:** [#utility](hc/utility.md)
- **Guide:** [open](https://docs.google.com/document/d/1gtPRmht-TVBRMVuYYJdPUdNWi7MY560iYO4UMgdt3mU/edit)

### Ethics and Justice in Complex Systems
- **Citation:** Wisor, S. & Perry, T.J. (2022). Ethics and Justice in Complex Systems. Minerva Guide v2.5.
- **Related HCs:** [#ethicalconsiderations](hc/ethicalconsiderations.md), [#ethicaljudgment](hc/ethicaljudgment.md)
- **Guide:** [open](https://docs.google.com/document/d/17S9I_ct0FuVqZWC3W42R4EqUW7vCklA0M-rSbgzgbX4/edit)

### Ethical Courage
- **Citation:** Sheskin, M. & Perry, T.J. (2022). Ethical Courage. Minerva Guide
- **Related HCs:** [#ethicalcourage](hc/ethicalcourage.md), [#ethicalconsiderations](hc/ethicalconsiderations.md), [#ethicaljudgment](hc/ethicaljudgment.md)
- **Guide:** [open](https://docs.google.com/document/d/1wA8ybnTXoAabp-AqsTR5p9cPr0EyMdyVLrhqe9nQfkE/edit)

### Thinking Strategically
- **Citation:** Kenney, N. (2022). Thinking Strategically. Minerva Guide.
- **Related HCs:** [#strategize](hc/strategize.md)
- **Guide:** [open](https://docs.google.com/document/d/1bQ74TpYcnzl9YMBY3j3b6j8ZHXtZC9FEvLs6EQ0wAxo/edit)

### Nudge: A subtle tool for shaping behavior
- **Citation:** McAllister, K. & Morgan, R. (2023). Nudge: A subtle tool for shaping behavior. Minerva Guide.
- **Related HCs:** [#shapingbehavior](hc/shapingbehavior.md)
- **Guide:** [open](https://docs.google.com/document/d/1leQc29b8RpOL7K4mUw5Vx_v--OkSD6tSv18Mey9MkzQ/edit)

### Leadership in Complex Systems
- **Citation:** Powers, J. & Wilkins, J. (2022). Leadership in Complex Systems (Perry, T.J. Ed.). Minerva Guide.
- **Related HCs:** [#leadprinciples](hc/leadprinciples.md)
- **Guide:** [open](https://docs.google.com/document/d/1Qsbe89vuPIfv_F3CwbwK4HTpa2julqVo9WZnnztIP9k/edit)

### Leadership Case Study - The Four Horsepersons
- **Citation:** Powers, J. (2022). Leadership Case Study - The Four Horsepersons. Minerva Guide.
- **Related HCs:** [#leadprinciples](hc/leadprinciples.md)
- **Guide:** [open](https://docs.google.com/document/d/1dZObvfvjt3to3rx7-trlGtOXOv0OtuP_6RmliEGDU7M/edit)

### Common Ground
- **Citation:** Kenney, N., McAllister, K. et al (2019). Understanding Common Ground in Negotiation.
- **Related HCs:** [#negotiate](hc/negotiate.md)
- **Guide:** [open](https://docs.google.com/document/d/1m7g5Oez8JeIKG-7MNNdXHX5rMC-EWFq9SBpYZ6dXcGM/edit)

## Multimodal Communications (3)

### A brief guide to persuasion
- **Citation:** Yang, M. and Carter, C. (2023). A brief guide to persuasion. Minerva University.
- **Related HCs:** [#persuasion](hc/persuasion.md)
- **Guide:** [open](https://docs.google.com/document/d/1KnrDuBmptY7SC4-AonDuJ2B2uYv4Bg3fNqFpNKlf-Z8/edit)

### A #Medium Analysis with Prof Lawry
- **Citation:** Zhi Zhi Chia, Prof Lawry, and Prof Carter. (2023, August 3). Dancing in the Street: A #Medium Analysis with Prof Lawry. [Video]. YouTube.
- **Related HCs:** [#medium](hc/medium.md)
- **Guide:** [open](https://www.youtube.com/watch?v=NWPiXSlxWS0)

### Cornerstone Summer Preparation Writing Resources
- **Citation:** 
- **Related HCs:** 
- **Notes:** The Cornerstone preparation materials contain a variety of custom resources to assist with writing, including guides on analyzing texts, formatting, organization, and thesis.
- **Guide:** [open](http://my.minerva.edu/academics/curriculum/foundation-year/cornerstone-summer-preparation/resources-2026/writing-resources-2026/)

## Other Custom Guides (5)

### Science of Learning Resources
- **Citation:** 
- **Related HCs:** 
- **Notes:** Four different resources under Academics → Learning Resources → Science of Learning, which can help boost learning in and out of class via science-founded strategies and habits.
- **Guide:** [open](http://my.minerva.edu/academics/learning-resources/science-learning/)

### Additional HC Guides, Checklists, Videos, and More
- **Citation:** 
- **Related HCs:** 
- **Notes:** A variety of useful guides, videos, checklists, and other resources to help apply HCs effectively.
- **Guide:** [open](http://my.minerva.edu/academics/hc-resources/additional-resources/)

### Addressing HCs in Your Work
- **Citation:** 
- **Related HCs:** 
- **Notes:** Listed on the Additional HC Resources page.
- **Guide:** [open](https://docs.google.com/document/d/1s7yOVOtMIaHQdKLeRmZbq1gRqwJKfezBsfru9Q6PcHw/edit)

### HC Guide for Visuals
- **Citation:** 
- **Related HCs:** 
- **Notes:** Listed on the Additional HC Resources page.
- **Guide:** [open](https://docs.google.com/document/d/1EHG_5zT2kOF0RTFoC1jMMaCVmi60Q_RG7VfqvGUWYn0/edit)

### Academic Foundations Series
- **Citation:** 
- **Related HCs:** 
- **Notes:** Video series listed on the Additional HC Resources page.
- **Guide:** [open](https://youtube.com/playlist?list=PL-V70w67FyfJSQNtQXJpzUqNtrts2Xv79)

> Aliases normalized: #systemmaping → #systemmapping, #ethicaljudgement → #ethicaljudgment, #nudge → #shapingbehavior. #orgstructure is a legacy name retained as plain text (no page in this set).
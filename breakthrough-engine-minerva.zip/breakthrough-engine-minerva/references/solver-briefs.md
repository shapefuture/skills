# Solver, red-team and synthesis briefs (DEEP mode)

Use these as the prompts for parallel subagents. Each solver gets **only**:

- the dossier
- the chosen reframes
- the diagnosed stuck-types
- its own brief

Never pass one solver's output to another before synthesis. The value of DEEP mode comes entirely from independent contexts.

**Shared return schema (append to every solver brief):**

> Return up to 3 attacks. For each:
> 1. **Mechanism**: one causal sentence. No adjectives; say what causes what.
> 2. **Cracks**: which stuck-point it removes, and how.
> 3. **Must be true**: 1–3 load-bearing assumptions.
> 4. **Fails if**: the most likely failure mode.
> 5. **First test**: the cheapest action that would show whether it works.
> 6. **Claims**: each factual claim tagged `verified` (with source or computation), `derived`, `plausible` or `speculative`.
>
> Use web search and code execution where they would materially sharpen the answer, and cite what you used. Be specific and committal; a hedge on every line is a non-answer. If your lens truly yields nothing here, say so in one line. That is useful information.

## Lens briefs

**Assumption-killer.** List the 5 assumptions that every current approach shares. Pick the most load-bearing one and design a solution that only works if it is false. Then show evidence that it might be false. Banned: the stock contrarian move "the obvious answer is secretly right", and plain negation with no mechanism.

**Far-transfer researcher.**
1. Restate the problem as a field-neutral causal structure.
2. Search for fields that have handled this structure for decades: biology, logistics, finance, epidemiology, the military, games, physics or law.
3. For your best 1–2 candidates, map every component: source element, target element, and the relation between them.
4. Run the reverse test: what would the target teach the source?
5. Drop anything that fails.

Prefer moderate distance between fields. Very distant analogies sound brilliant and rarely map.

**Mechanism designer.** Model each actor as rational under the current rules, and name their payoff. Find the rule, price, information flow, ownership or default that makes the bad outcome rational. Redesign it so the desired behaviour becomes each actor's best response, and check that the result can't be gamed.

**Contradiction engineer.**
1. State "improving A worsens B".
2. Reduce it to the single parameter that needs opposite values.
3. Try separation in space, time, condition and part/whole, then an ideal final result using resources already present.
4. Report which separation works and the physical or organisational realisation of it.

**Systems mapper.** Sketch the stocks, flows, delays and reinforcing and balancing loops behind the persistence. Name the leverage level of each past intervention. Propose an intervention at a higher level, and predict how the system will respond to it.

**Hardened expert.** Give the best current practice, researched, with real benchmarks. Say how a top practitioner would execute it, and what "properly tried" means, because many "we tried it" claims weren't. This is the baseline every other attack must beat. Don't make it weak.

**First-principles outsider.** Ignore industry habits. Decompose the problem into physical, economic and behavioural primitives. Ask what the theoretical limit is, and how far the current approach is from it. Design toward ten times better or a tenth of the cost, and name which primitive makes that possible.

**Backcaster.** Write a short history, dated ten years from now, in which this problem was solved. Work backward step by step. Each step must be plausible given the one before it. Return the first two steps as actions available today.

## Red-team brief (fresh context; give it only the candidates and the claim ledger)

> You did not write these. Your job is to break them. For each candidate:
> (1) **Pre-mortem**: it failed in 18 months; give the most likely story.
> (2) **Losers and saboteurs**: who loses if it works, and how they will stop it.
> (3) **System response**: what adapts to cancel it out.
> (4) **"Why hasn't this been done?"** Find prior attempts (search). Either name the barrier that killed them, or confirm a specific reason it was missed.
> (5) **Numbers**: recompute every load-bearing figure. Flag any number whose two "sources" share an origin.
> (6) **Ledger audit**: downgrade any tag the evidence doesn't support.
> (7) **Legitimacy and harm**: who bears the cost, who wasn't consulted, and how it could be misused.
>
> Verdict per candidate: KILL, REPAIR (say exactly how), or SURVIVES (state the strongest remaining doubt). Don't soften verdicts.

## Synthesis brief (the main agent, after red team)

1. Merge attacks that share a causal pathway.
2. Cross-breed the survivors: does A fix B's failure mode?
3. Apply the 90/10 rule.
4. Assign portfolio roles: core bet, hedges and probes.
5. Order decisive tests by information gained per unit of cost.
6. Write the output contract (SKILL.md §8).
7. If nothing survives, report the frontier: what was eliminated, which reframe looks most promising, and what single fact would unlock it.

## Cost control

- DEEP with 4 solvers and 1 red team is about 5 subagent runs. Default to 3–5 lenses chosen by stuck-type, not all 8.
- Skip DEEP when ENGINE produced a survivor that the user can test cheaply.
- If no subagent tool is available, run the same briefs sequentially in one context with a seeds table, and say the checks were done within the same context.

# Worked runs (for calibration; don't copy surface content)

## A. Wicked, with a maintaining force: "No company will develop new antibiotics"

**Route:** DEEP. Global stakes; decades of failed fixes.

**Dossier highlights:**
- **Goal ladder:** new antibiotics → available when resistant infections strike → fewer deaths from resistance.
- **Failure autopsy:** push funding (grants for early research) produced candidates, but companies still went bankrupt after approval.
- **Actors:** health systems want new drugs held in reserve and rarely used, which is stewardship. Firms earn revenue per dose.

**Diagnosis:** S5, maintaining force (`verified` mechanism). Revenue is tied to volume, but stewardship requires low volume, so success at stewardship destroys the market. Plus S8, the clash between public health and the private payer. Wicked features are present, but the core is a broken payment mechanism.

**Reframes (top 3 of 9):**
1. Change the objective: pay for *availability*, not doses. This is the winner.
2. Change the actor: the state as an insurer buying an option on future cures.
3. Change time: an advance commitment before approval.

**Attacks:**
- **Mechanism designer:** a subscription contract with a fixed annual fee for access, independent of volume.
- **Far-transfer:** insurance premiums and fire-department funding, where you pay for readiness rather than for fires.
- **Hardened expert:** larger push grants. This is the baseline, and the autopsy shows it doesn't fix the post-approval collapse.

**Red team:**
- "Why hasn't this been done?" Budgets are siloed and the value is hard to set. Repair: value the drug on health-economic grounds, including its value in reducing resistance.
- Saboteur risk: other countries free-ride on one country's payments. Repair: international coordination as a signpost.

**Outcome check (`verified`):** this is close to what NHS England and NICE actually did. A subscription model with fixed payments delinked from volume started in 2022 with two antimicrobials and was expanded in 2024 with roughly £100m a year. The engine's path (find the maintaining force, change what is paid for, then attack the legitimacy and coordination risks) reproduces a real breakthrough. That is the bar.

## B. Contradiction, plus a hidden requirement: "The enclosure must be lighter but keeps failing the drop test"

**Route:** ENGINE, with the commitment protocol because tooling money is at stake.

**Failure autopsy:** three cost-reduction passes made the walls thinner, and each failed the drop test.

**Goal ladder:** "a stiff, thick shell" → "survive the drop" → **"the device still works after the drop."** This is the hidden requirement (S3/S12): the *contents* must survive, not necessarily the shell.

**Diagnosis:**
- S4, a physical contradiction: the wall must be thick (for impact) and thin (for weight).
- S3: the spec protects the wrong object. Confidence `plausible`, pending the actual test standard.

**Reframes:**
- Separate by condition: the thickness is only needed *during an impact*, and only *at the corners and edges* where impact lands.
- Change the boundary: protect the electronics, not the shell.

**Attacks:**
1. Thin shell plus elastomer corner bumpers that are cheap and replaceable (separation in space).
2. Mount the internals in elastomer isolators so the shell can flex (change of boundary).
3. Ribbed, locally thickened walls placed with topology optimisation (the hardened baseline).

**Red team:** isolators add sway space, so check the internal clearance. Bumpers may violate an industrial-design constraint, so ask whether that is a convention or a real requirement.

**Decisive tests, cheapest first:**
1. Read the actual drop-test clause. Does it judge shell damage or function? This costs zero.
2. Run an explicit or quasi-static FEA estimate of the corner G-load with and without bumpers. This is hours of work.
3. Drop-test foam-corner prototypes. This is a day.

**Kill criterion:** the spec requires the shell to be undamaged *and* the corner G-load exceeds the board rating even with isolators.

**Note on a rejected candidate:** "woodpecker-skull lattice" was dropped. Its biological premise is contested (2022 evidence shows the skull isn't a shock absorber), and it failed "why hasn't this been done?" against existing sandwich-panel practice.

## C. A real wall: "We need a voting system for our co-op that's fair by every criterion"

**Diagnosis:** S10 (Arrow's theorem) plus S12, because "fair by every criterion" is ill-posed.

**Premises of the wall:** ranked ballots, 3+ options, any preference profile allowed, Pareto, independence of irrelevant alternatives, no dictator.

**Ways through:**
- Approval or score voting removes the rank-only premise. The trade-off is that strategic voting is still possible.
- Structure decisions along one dimension so preferences become single-peaked, and the median option wins coherently.
- Reduce each vote to two options using a deliberated agenda. With two options, majority rule is fine.

**Recommendation:** approval voting for elections, and a binary-agenda process for policy votes.

**What to tell the user plainly:** no ranked system can meet all of those criteria at once. That has been proven, so stop searching for one. Pick which criterion to give up, deliberately.

## D. DIRECT: "Give me 5 unexpected taglines for my coffee shop"

Just write five good, varied taglines. No diagnosis, no labels, no tags. The engine's job here is to stay out of the way.

## E. Plain mode: "Don't overdo it with frameworks, just think with me"

Run the full discipline internally. Write it like a sharp colleague would:

> "I think the real issue isn't the pitch, it's who pays. Every donor goes quiet at the same moment — when they hear it's an ongoing cost with no end date. Two ways to change that: …, and the quickest way to find out which is right is …"

No stuck-type codes, no lens names, no tags. The uncertainty is expressed in ordinary words ("I'm fairly sure…", "this part is a guess").

# Minerva HC Bridge for Breakthrough Engine

This guide connects the Breakthrough Engine's existing process to the official Habits of Mind (HoM) and Foundational Concepts (FC) in `hc/`. HCs are a **quality-control and reasoning layer**, not replacement crack moves, brainstorming prompts, or decorative labels.

## Quick selection rules

1. State the work to be done in ordinary language before selecting an HC.
2. Read the master [HC index](hc/INDEX.md), then open only the few relevant pages. Most runs need 3–6 HCs; some need none.
3. Use each page's **“Is it this HC?”** diagnostics. If fit is weak, consult its related-HC table and choose a better fit.
4. Apply the HC's distinctions, questions, or method to the actual case. Name the causal mechanism or evidence; don't substitute a hashtag for reasoning.
5. Keep labels out of DIRECT, CRISIS, and plain-mode answers unless the user wants them. Do not turn every insight into a Minerva citation.
6. The handbook pages are Minerva material; the Breakthrough Engine's original protocols and lenses are a separate coaching method. Never attribute the latter to Minerva.

## Routing by engine step

### 1. Dossier: define the right problem
- [#rightproblem](hc/rightproblem.md): specify initial state, goal state, obstacles, and scale; use when solution attempts may be targeting the wrong issue.
- [#purpose](hc/purpose.md): clarify why the requested outcome matters and distinguish means from ends.
- [#constraints](hc/constraints.md): identify what is genuinely fixed, what is an obstacle, and how a proposed action fits within limits.
- [#variables](hc/variables.md): make relevant factors explicit; useful when a problem statement hides uncontrolled or conflated variables.
- [#audience](hc/audience.md): determine who evaluates success, who receives consequences, and whose interpretation matters.

### 2. Diagnose why it persists
- [#breakitdown](hc/breakitdown.md): decompose the challenge without confusing subproblems with root causes.
- [#systemmapping](hc/systemmapping.md): characterize elements and relations; useful for actors, dependencies, and boundaries.
- [#complexcausality](hc/complexcausality.md): examine interacting causes, feedback, and non-linear pathways.
- [#systemdynamics](hc/systemdynamics.md): reason about behavior over time, accumulations, delays, and tipping points.
- [#levelsofanalysis](hc/levelsofanalysis.md): compare individual, organizational, institutional, and other explanatory levels.
- [#biasidentification](hc/biasidentification.md) and [#biasmitigation](hc/biasmitigation.md): inspect whether a favored diagnosis is driven by anchoring, confirmation, or other biases; add a concrete disconfirmation step.

### 3–4. Reframe and generate attacks
- [#modeling](hc/modeling.md): represent alternative framings explicitly; compare what each model explains and omits.
- [#hypothesisdevelopment](hc/hypothesisdevelopment.md): state rival explanations in a way that produces different predictions.
- [#designthinking](hc/designthinking.md): explore human needs and prototype options when the challenge is an experience or service-design problem.
- [#differences](hc/differences.md): account for different stakeholders, contexts, or perspectives when changing the actor or boundary.
- [#shapingbehavior](hc/shapingbehavior.md): inspect incentives, disincentives, and choice architecture when behavior is central. Do not reduce a political or ethical issue to behavior design.

### 5–7. Compare, red-team, and test
- [#decisiontrees](hc/decisiontrees.md): make alternatives and consequences explicit.
- [#utility](hc/utility.md): represent preferences and trade-offs; do not assume stakeholders share one utility function.
- [#optimization](hc/optimization.md): use only after the objective and feasible set are explicit.
- [#probability](hc/probability.md) and [#estimation](hc/estimation.md): calibrate uncertainty and bound unknown quantities; do not turn guesses into precise-looking numbers.
- [#evidencebased](hc/evidencebased.md) and [#sourcequality](hc/sourcequality.md): check the basis for factual claims and whether sources can support the inference being made.
- [#interventionalstudy](hc/interventionalstudy.md): design a probe that changes something and can distinguish explanations.
- [#comparisongroups](hc/comparisongroups.md): check whether a comparison offers a credible counterfactual.

### Wicked and strategic problems
- [#audience](hc/audience.md), [#differences](hc/differences.md): map different definitions of success and lived contexts.
- [#responsibility](hc/responsibility.md): make duties, accountability, foreseeable harms, and decision rights explicit.
- [#emotionaliq](hc/emotionaliq.md): use where emotional information or interpersonal interaction changes the situation; it does not replace stakeholder participation.
- [#gametheory](hc/gametheory.md): model strategic interdependence where actors respond to one another's choices; don't use it as a synonym for all interaction.

## What the HC layer changes

| Without the HC check | With a well-fit HC |
|---|---|
| “We need to fix onboarding.” | #rightproblem asks what state needs to change, for whom, at what scale, and what evidence defines success. |
| “The policy keeps failing.” | #systemmapping / #systemdynamics asks which actors, feedback loops, delays, and incentives recreate the outcome. |
| “The new policy caused the drop.” | #evidencebased asks what evidence supports causality; #comparisongroups or #interventionalstudy helps specify a discriminating test. |
| “We need to optimize.” | #utility and #constraints require explicit preferences, objective, and feasible set before optimization. |
| “Stakeholders disagree.” | #audience / #differences clarifies what each group protects; #responsibility surfaces who decides and who bears risk. |

## Attribution and integrity

The bundled pages under [`hc/`](hc/INDEX.md) are adapted for navigation from Minerva University's Cornerstones HC Handbook; each page preserves its handbook source URL and content attribution. They are not an endorsement of this skill. The Breakthrough Engine's names, protocols, and non-HC frameworks remain distinct from Minerva's official material.

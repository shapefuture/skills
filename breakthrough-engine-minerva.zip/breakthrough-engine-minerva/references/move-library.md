# Move library

Every entry is one line: **name** (type) — application. Types tell you how to run it:
**Move** = do it once; **Method** = follow the steps in order; **Model** = map the situation onto the structure and read off the implication; **Metric** = compute the number; **Mindset** = a stance that colours other moves, never a step; **Institution** = needs real people or structures (name the gap if you can't provide them); **Artifact** = produce the object; **Reference** = look it up, don't recall it.

Load the sections the diagnosis points to. Walk the diagnosis tree first; don't browse.

---

## A. Generating divergence (use with SKILL.md §3–4)

- **Verbalise-then-select** (Move) — write 6–8 candidate answers, each with your probability that it would be your first instinct. Select the *lowest-probability* candidate that still fully meets the real requirement. The most surprising one that works, not the most surprising one. Evidence: recovers much of the diversity that alignment training suppresses.
- **Name the typical answers, then exclude them** (Move) — list the 3–5 most predictable answers a generic model or person would give. Each proposal must be measurably different from all of them. Stronger than asking for "creative" ideas, which returns the same mode.
- **Elimination reframe** (Move) — "What are the 5 most predictable answers I should NOT give? What is left once they are off the table?" Externalising the attractor works better than generating away from an unstated one.
- **Defixation cues** (Move) — pair explicit surprise words ("unconventional", "even absurd") with an explicit instruction to avoid the frequently used category. Adjectives alone do little; the named exclusion does the work.
- **Stratify by direction** (Move) — before generating, name 4–6 *structurally* different directions (not variations on a theme), then one candidate per direction. Beats N independent samples.
- **Constraint generators** (Method) — force search into new territory with one of: a hard formal rule that has nothing to do with content (length, must-include); inversion (state the most probable answer, then require its structural opposite on a named axis); resource removal (solve as if a key resource is unavailable, then list what's left); borrowed structure (impose an organising pattern from another field as a template to fill).
- **Bisociative retrieval** (Method) — *search, don't recall.* Find 2–3 real sources from fields with no obvious link to the problem. State the connection before proposing. If no genuine connection appears, say so; don't force one. Retrieved material brings information the model didn't already weight; recalled analogies don't.
- **White-space mapping** (Method) — for inventive or patent-like problems: map the existing solutions and note where coverage is sparse. Sparse regions are where a real contribution is more likely to be new and non-obvious.
- **Adjacent-step calibration** (Move) — if an idea is rejected as too safe, find the one step outside current practice that became reachable because something recently changed. If rejected as ungrounded, find the nearest step still reachable from here, not the safest one. Over-correction in either direction is a distance problem, not a creativity problem.
- **Novelty-first detour** (Method) — when repeated attempts keep converging on the same answer, run one or two rounds judged only on being different from everything tried so far. Then return to quality checks. Use only for deceptive landscapes; it is a detour, not a default.
- **Convergent audit** (Method) — before delivering, check: (1) does it solve the stated problem, and the real goal from the goal ladder? (2) would a domain expert see a genuine option, or something technically different and unusable? (3) was the obvious answer discarded for a real reason, or only because it ranked first? (4) is it mostly conventional with one real intrusion of novelty, rather than novel everywhere? (5) does every real constraint still hold, so the surprise is calibrated and not just unconstrained weirdness?
- **Subtraction prompt** (Move) — before finalising, ask what could be removed. People default to adding even when subtracting wins.
- **Via negativa** (Move) — ask what to remove, not add.
- **Ladder of abstraction** (Move) — restate at five levels: mechanism → function → intent → value → identity. The stuck level is usually not the one you're working on.
- **Placement shifting** (Model) — is this a sign, thing, interaction or system problem? Breakthroughs often come from changing the order.
- **Umwelt reframing** (Move) — solve through the bandwidth of an actor inside the system: the sensor, the rate-limiter, the least powerful stakeholder. What does the problem look like from there?
- **Genre swap** (Move) — restate it as a game, negotiation, biology or legal dispute, and see what the new genre makes obvious.
- **Literalisation** (Move) — take a metaphor literally ("bottleneck" as a physical constraint) and check what changes.
- **Definitional audit** (Move) — interrogate the key nouns. Which definition is doing the work, and whose is it?
- **Metaphor audit** (Move) — find the metaphor running the discussion (battle, pipeline) and swap it (ecosystem, garden). Check what the swap reveals.
- **Figure-ground reversal** (Move) — treat the background as the subject. What if the room is the display and the object is just a modulator?
- **Phenomenological bracketing** (Move) — describe the problem using only raw physical or observable properties, with no domain labels.

## B. Stuck-type S1 — wrong representation

- **Notation swap** (Move) — redraw as a graph, market, queue, game, flow network, control loop, evolving population or constraint problem. Each brings its own toolbox.
- **Inventor's paradox** (Move) — the harder, more general version is often easier; it exposes structure the special case hides.
- **Isomorph search** (Method) — find a solved problem with the same causal structure and map it component by component.
- **Structural isomorphism mapping** (Method) — map components 1:1. If you can't name what plays each role in the target, it's a metaphor. Drop it.
- **Category-theoretic homomorphic mapping** (Method) — stricter form: every operation and relation in the source has a corresponding one in the target. Use it when the answer depends on the transfer holding.
- **Reverse-transfer validation** (Move) — after importing a mechanism, check whether it teaches anything back to the source field. One-way mappings are analogies.
- **Domain-scanning heuristic** (Move) — ask who has solved this exact structural problem for decades in another field: biology for structural efficiency, air-traffic control for scheduling under uncertainty, epidemiology for anything that spreads.
- **Biomimicry (4-step)** (Method) — state the function in domain-neutral terms; find biological analogues of that function; extract the transferable principle, not the organism; apply it in the target. Check the biology claim against the literature, since popular examples are often wrong.
- **Convergent evolution as optimality signal** (Move) — if unrelated fields independently reached the same structure, treat it as near a physical or mathematical optimum.
- **Extremophile transfer** (Move) — who operates successfully under conditions that would destroy your system, and what is their specific mechanism?
- **Topological transfer** (Move) — import structure rather than mechanism, e.g. "open to the interior, closed to the boundary". Ask the specific structural question.
- **Ackoff's idealised design** (Move) — redesign from scratch as if starting today with no legacy, then work back to the smallest bridge from here.
- **Soft Systems Methodology (CATWOE)** (Method) — for any proposed intervention name Customers, Actors, Transformation, Worldview, Owner, Environmental constraints. Surfaces whose worldview the obvious framing smuggles in.
- **Critical Systems Heuristics** (Method) — ask who is the beneficiary, who should be, who is excluded, what success is, and what it ought to be.

## C. Stuck-type S2 — false constraint

- **Physics vs. engineering** (Model) — would it bind with unlimited budget and any process? Yes = physics. No = negotiable.
- **Constraint provenance** (Move) — who wrote the rule, why, and does the reason still hold? Most constraints are historical residue.
- **Constraint-inversion sweep** (Method) — negate each constraint; classify the outcome as collapsed, softened or unchanged. Collapsed = never real.
- **Chesterton's fence** (Move) — write the strongest reason the constraint exists before removing it. Can't write one: remove it. Can: that reason is the real constraint.
- **Flip the anchor** (Move) — assume the impossible constraint is gone; design backward; then check what it would take to actually remove it.
- **Constraint-relaxation cost ledger** (Metric) — when relaxing a constraint partway, put a number on what it costs and what it buys. Makes partial relaxations visible.
- **Constraint-satisfaction reformulation** (Method) — write variables and constraints explicitly and check that a solution satisfying all of them exists. Often shows that stated requirements are jointly unsatisfiable. That is a finding, not a failed search.
- **Lock-in audit** (Move) — what is enforced only by switching cost, not merit? QWERTY-type cases.
- **Curie's symmetry breaking** (Move) — if a tradeoff seems fundamental because the situation is symmetric, introduce deliberate asymmetry.

## D. Stuck-type S3 — hidden constraint or requirement

- **Failure autopsy** (Method) — list every failed attempt and the exact point where it failed. The shared point is the hidden constraint.
- **Interface audit** (Method) — at each handoff, list what each side assumes about units, definitions, formats and success criteria. The Mars Climate Orbiter was lost at exactly such a seam.
- **Need vs. solution** (Move) — "we need an app" is a solution. If that solution were banned, what need would remain?
- **Stater vs. judge** (Move) — is the person stating the requirement the person who will judge success? Often they are different people.
- **Measurability** (Move) — every adjective doing real work ("robust", "user-friendly", "scalable") needs a number and a measurement method.
- **Goal ladder** (Move) — ask "in order to…?" repeatedly. The real goal is often two rungs up.
- **Named-actor + specific-gain requirement** (Move) — "industry inertia" is not an explanation. Name who gains what concretely from the status quo.
- **Repeated identical failure point** (Model) — when varied pitches, tactics or products all fail at the *same* step, the cause is structural (incentives, the ask, the cost signal), not messaging or effort. This is diagnostic.

## E. Stuck-type S4 — contradiction

- **Technical vs. physical contradiction** (Model) — technical: two parameters conflict, so look for a trade or substitution. Physical: one parameter needs two opposite values, so separate it. Diagnose which before choosing a move.
- **Separation principles** (Method) — separate the opposing requirements in **space** (different parts), **time** (different moments), **condition** (different operating regimes), or **system level** (the part versus the whole).
- **Intermediary** (Move) — can a third element absorb the cost so neither side has to give ground? Buffers, brokers, bridging components.
- **Ideal final result** (Move) — state the result as delivered with no system present. Work back to the closest real version; it shows which parts are dead weight.
- **Anticipatory failure determination** (Move) — ask how you would deliberately engineer exactly this failure. Working backward bypasses the "that could never happen" filter.
- **Contradiction matrix** (Reference) — for a named technical contradiction, the classic 39×39 TRIZ matrix suggests principles that resolved the same pairing before. Look it up; don't recall it.
- **Yin-Yang polarity** (Mindset) — some tensions are permanent. Manage them by oscillating on purpose rather than solving them once. Diagnostic: if every "solution" recreates the tension, you have a polarity. Mutual containment (every strength carries its weakness) and mutual transformation (at an extreme, a trend turns into its opposite) sharpen the diagnosis.
- **Resource-closed world** (Move) — solve using only elements already in the system or its surroundings: waste, idle time, fields, byproducts.

## F. Stuck-type S5 — maintaining force

- **Reinforcing/balancing loop map** (Artifact) — draw the loops keeping the problem stuck. Find the delay that makes them oscillate.
- **Meadows' leverage points** (Model) — from weakest to strongest: parameters, buffers, stock/flow structure, delays, balancing loops, reinforcing loops, information flows, rules, self-organisation, goals, paradigm. Failed fixes usually aim at parameters.
- **Senge's system archetypes** (Model) — fixes that fail; shifting the burden; limits to growth; tragedy of the commons; escalation; success to the successful; growth and underinvestment; accidental adversaries. Pattern-match the loop to one of these.
- **Mechanism design** (Method) — redesign rules so the desired behaviour is each actor's dominant strategy. Assume the actors are rational under the current rules.
- **Goodhart / perverse-incentive audit** (Move) — compare the stated goal with what is measured and rewarded. The system optimises the measured version.
- **Baptists and bootleggers** (Move) — find the moral argument and the economic interest that jointly defend the status quo.
- **Autocatalytic set** (Move) — find the components that sustain each other. Insert a breaker rather than attacking any single member.
- **Iron law of institutions** (Model) — people protect their role over the stated mission. Mission rhetoric won't overcome role-protection incentives.
- **Jevons check** (Move) — what new demand will absorb an efficiency gain?
- **Institutional authority from persistence** (Move) — ask which institutions gain legitimacy or budget from the problem continuing. Often the maintaining force (see Foucault, §J).
- **Discount-rate interrogation** (Move) — "impossible" or "too slow" is often an unstated discount rate. Make it an explicit number people can argue with.

## G. Stuck-type S6 — knowledge gap and measurement

- **Cheapest decisive test ladder** (Method) — compute → bound → neutralise → research → ask an expert → small probe → physical test. Stop at the first rung that settles it.
- **Simulability triage** (Method) — before accepting that something needs a measurement: can it be computed from data in hand? bounded? neutralised so it stops mattering? Only then is a physical test the closer. Writing "needs a rig" without trying a calculation hasn't earned that step.
- **Bound, don't solve** (Move) — a result with a 25× margin settles a question even if the model is off by 10×. Aim for a margin, not precision.
- **Tagged Fermi chain** (Method) — build the estimate from factors tagged cited, assumed or derived. An untagged estimate is a guess dressed as a number.
- **Order-of-magnitude triage** (Move) — get the order right before refining. A wrong order makes precise digits misleading.
- **Sensitivity / weakest link** (Move) — find the shakiest assumption, halve it, see whether the conclusion survives.
- **Break-even inversion** (Move) — ask what the unknown would have to be for the decision to flip. Checking a threshold is easier than estimating a point.
- **Power-law / long-tail check** (Move) — if the distribution is roughly straight on log-log axes, the mean misleads and normal-distribution estimates badly miss the tail.
- **Regression-to-the-mean flag** (Move) — an extreme observation used as the anchor for a forecast will likely be less extreme next time regardless of intervention.
- **Simpson's paradox check** (Move) — does the aggregate conclusion hold within each relevant subgroup?
- **Little's law** (Model) — L = λW. Work-in-progress equals arrival rate times time in system. To cut WIP, start fewer or finish faster.
- **Kelly fraction** (Metric) — the bet size that maximises long-run growth is edge divided by odds. A principled alternative to gut-feel sizing.
- **Value of information (EVPI)** (Metric) — before commissioning research, estimate what perfect information would be worth. If that's below its cost, skip it.
- **Confidence-interval honesty** (Move) — give a range for anything genuinely uncertain. A false point estimate hides exactly what a decision-maker needs.
- **Fragility via premise perturbation** (Move) — name the single most load-bearing unverified premise, vary it to an extreme, and report: "sensitive to X: flipping it changes A to B" or "robust to X".
- **Primary-source reconstruction** (Move) — trace a load-bearing fact to its origin, not the nearest citation. Claims mutate as they get re-cited.
- **Garden of forking paths** (Move) — if the analysis wasn't specified in advance, report the defensible alternatives and show whether the conclusion is robust across them.
- **Hardware-in-the-loop falsification** (Method) — if one variable can be isolated and tested cheaply, do that rather than building a full simulation that might lie about boundaries.
- **Conservation-law accounting** (Metric) — energy, mass, money and budgets must balance. Any unexplained flux rejects the claim.

## H. Stuck-type S7 — capability or resource gap

- **Exaptation / spandrels scan** (Move) — inventory every byproduct, waste stream and side effect. What could each serve that it wasn't built for? Most "obvious in hindsight" innovations came this way.
- **Adjacent possible** (Method) — list combinations of existing elements that are now feasible but untried. That is the reachable next step.
- **Frugal reframe (jugaad)** (Move) — what is the version costing a tenth, built from parts already at hand?
- **Constraint as spring** (Move) — hold a constraint long enough that its release becomes available. Some capabilities mature in the wait.
- **Asymmetric bypass** (Move) — satisfy the constraint in perception rather than in reality, by matching the design to the limit that actually matters.
- **Archimedes point search** (Move) — if you could change only one thing for under a set budget, what would have the largest effect?
- **Sequencing by risk** (Method) — prove the hardest control or feasibility question first, then add power. The glide-before-power pattern.
- **Asynchronous maturity gating** (Method) — design interfaces that accept placeholder components today and better ones later, so the slowest part doesn't gate everything.

## I. Stuck-type S8 — values and legitimacy

- **Four rationalities** (Model) — individualist (market, freedom), hierarchist (rules, expertise), egalitarian (solidarity, equality), fatalist (distrust, resignation). A solution built within one rationality will provoke the other three.
- **Clumsy solutions** (Move) — a deliberately messy settlement with recognisable elements for each rationality. It satisfies no one fully, and survives longer than an elegant one-faction answer.
- **Incompletely theorised agreement** (Move) — agree on the action and leave the reasons open.
- **Constructive controversy** (Method) — (1) prepare the strongest case; (2) advocate it; (3) rebut and be rebutted; (4) reverse roles and argue the other side sincerely; (5) synthesise. Step 4 does the work. **[humans]** Solo substitute: write the steelman of each side, and note it lacks a real advocate.
- **Pre-consultation (nemawashi)** (Institution) — private one-to-one conversations before a public proposal, so objections surface without loss of face. **[humans]**
- **Ringi-style circulation** (Institution) — a proposal circulates to every affected party, who each sign or comment before it can complete. The explicit paper trail of reasoning and the slowness are deliberate. **[humans]**
- **Hoshin catchball** (Method) — refine a plan through repeated two-way passes between those who set direction and those who must execute it, until both can live with it.
- **Veil of ignorance** (Move) — would you endorse this without knowing which stakeholder you would be?
- **Capability approach** (Model) — judge a proposal by which human capabilities it expands or shrinks (health, voice, mobility, security), not only aggregate benefit. Averages hide losses to specific groups.
- **Design justice check** (Move) — who framed it, who benefits, who bears the cost. Treat the answer as a design constraint on par with budget.
- **Epistemic injustice audit** (Move) — whose testimony is discounted because of who they are? Does any affected group lack the vocabulary to name what's happening to them?
- **Precautionary vs. proactionary** (Move) — say which default you're operating from: "don't act until proven safe" or "don't block until proven harmful". Neither is universally right; leaving it implicit smuggles a value judgement in.
- **Moral triangulation** (Method) — run the leading candidate through consequences, duties and character ("what kind of actor does this make us?"). Disagreement between the lenses shows where the real objection will come from.
- **Dual-use / misuse red-team** (Move) — how would a bad-faith actor abuse this? Anything powerful enough to matter is powerful enough to misuse.
- **Second-order harm scan** (Move) — who is harmed by this idea *succeeding*? Enthusiasm suppresses this question.
- **Structural violence verdict** (Model) — sometimes the harm is embedded in the structure with no single culprit. "The structure" is a legitimate answer.
- **Dirty hands** (Mindset) — some problems have no clean option. Ask which path carries the least unacceptable cost, and be honest that a cost is being paid.
- **Seven generations** (Mindset) — would people several generations out thank us or curse us for this?
- **Relational success metric** (Move) — add "were relationships strengthened or damaged?" as an explicit criterion. Damaged relationships sabotage technically correct fixes.

## J. Wicked problems (S11)

- **Rittel–Webber ten characteristics** (Model) — no definitive formulation; no stopping rule; good-or-bad, not true-or-false; no immediate test; every attempt is one-shot; no enumerable solution set; each case unique; each is a symptom of another; the explanation chosen determines the solution; the planner has no right to be wrong. Use these to confirm wickedness rather than pattern-matching on "hard".
- **Weber and Khademian's three tests** (Model) — unstructured (causes don't isolate, no agreed definition), cross-cutting (many stakeholders, unavoidable value tradeoffs), relentless (no finish line, it persists regardless of intervention).
- **Roberts' three strategies** (Model) — check which one you are doing. *Authoritative/taming* (experts decide top-down) produces elegant failures. *Competitive* (factions fight for power) risks imposition. *Collaborative* is slower and less satisfying but is what actually makes progress on wicked problems.
- **Heifetz: technical vs. adaptive** (Model) — technical problems can be solved by authority; adaptive ones require stakeholders to change what they value or do. Misdiagnosing adaptive as technical is the most common wicked failure. More expertise won't fix an adaptive problem.
- **Reframe as "improve", not "solve"** (Mindset) — wicked problems have no stopping rule, only better and worse outcomes. Set that expectation first.
- **Understanding and solving co-evolve** (Mindset) — you don't understand the problem until a solution reveals a new facet. Ship a small intervention whose main purpose is to learn.
- **IBIS / dialogue mapping** (Method) — structure the disagreement itself: issues (questions), positions (answers), arguments (pro/con). It is built to make disagreement legible, not to force consensus. **[humans]** for live groups; a solo map is still useful.
- **Post-normal science and extended peer community** (Model) — when facts are uncertain, values disputed, stakes high and decisions urgent, the people with local knowledge and a real stake count as reviewers, not just credentialed experts.
- **Transition design** (Method) — frame across large spatial and temporal scales; co-create the future with stakeholders, not just consult them; build shared long-term visions; favour an ecology of coordinated small interventions over one fix.
- **Foucault's problematisation** (Method) — before solving: trace how the issue became a problem (archaeology); ask what is treated as normal or deviant and who decided (genealogy of normalcy); test whether persistence generates authority or budget for those positioned as solvers. That is a checkable hypothesis.
- **Root-and-branch (TCM)** (Method) — treat the presenting symptom for relief and the underlying pattern for lasting change at the same time. Don't let the root fix leave present suffering unaddressed.
- **Pattern differentiation (TCM)** (Method) — before treating, identify the underlying pattern. The same symptom can come from different patterns that need different fixes, so "same problem" in two places may need different solutions.
- **Holistic view (TCM)** (Mindset) — never solve a sub-problem in isolation from its connections to the whole.
- **Combined treatment** (Move) — apply coordinated modalities at once rather than hunting for the single correct intervention.
- **Two-eyed seeing** (Mindset) — hold two knowledge systems as parallel, equally valid lenses rather than ranking one above the other.
- **Ubuntu** (Mindset) — "I am because we are". Success includes whether relationships are stronger afterwards.
- **Phronesis** (Mindset) — knowing which technique fits this unrepeatable situation. It is built through practice and error. No list substitutes for it, so say so when it's the real limit.
- **Ma (negative space)** (Mindset) — leave deliberate gaps. The best thinking often happens when no technique is being applied.
- **Wabi-sabi** (Mindset) — accept degradation as permanent and design maintenance loops, rather than chasing a permanent fix to something that won't hold still.
- **Sun Tzu's zheng and qi** (Move) — fund a conventional, visible stream and an unconventional, hidden stream at the same time. An unconventional approach used alone becomes the new baseline and loses its surprise. Today's unorthodox becomes tomorrow's orthodox.
- **Hansei** (Method) — review after every outcome, success included, asking what could have been better. Success without review calcifies.
- **After-action review** (Method) — what did we intend, what happened, why the gap, what to sustain or change. Run it after successes too, because they can be lucky.
- **Deliberate technique rotation** (Move) — if a technique isn't working after a real attempt, switch to a structurally different one. Pushing harder is not progress.
- **Shu-ha-ri** (Mindset) — follow the forms exactly until you understand why they exist; only then break them. Improvising at the beginner stage gives confident-looking chaos.

- **Tacit knowledge (Polanyi)** (Mindset) — "we know more than we can tell". When verbal analysis stalls on something physical or skilled, build, sketch or manipulate something instead of writing more prose.
- **Dreyfus skill levels** (Model) — novices benefit from explicit rules; experts reason by pattern, and imposed analysis can make them worse. Ask which level the people doing the work are at before adding process.
- **Extended mind** (Mindset) — manipulating an external representation (a model, a whiteboard, a mockup) changes what can be discovered. A problem that keeps being re-described but never redrawn is itself diagnostic.
- **Affordance gap** (Move) — ask what the object or interface invites people to do, not what it can technically do. Most user failures live in that gap.
- **Minimum-risk physical test** (Method) — identify the single most uncertain physical assumption and design the cheapest test that isolates just that variable. Specify it; don't pretend analysis replaces it.

## K. Strategic and other-minds (S9)

- **Game-type diagnosis** (Model) — name the game: prisoner's dilemma (mutual defection is individually rational), stag hunt (coordination pays if trust holds), chicken (whoever swerves loses face), battle of the sexes (both want to coordinate; they disagree on which option). The right move depends on the type.
- **Focal points** (Move) — pick the option that is salient because both sides can see it is salient.
- **Costly signalling** (Move) — make the commitment one that is only affordable if the claimed quality is real.
- **BATNA / walk-away pricing** (Move) — before any negotiation move, price your best alternative. Improving it is often the highest-leverage move.
- **Two-level games** (Model) — every counterpart plays an external table and an internal one. Design for both.
- **Three faces of power** (Model) — who decides, who keeps issues off the agenda, and whose preferences have been shaped so they no longer want what would threaten the status quo.
- **Agenda and policy-window timing** (Model) — problems, solutions and politics couple only when a window opens. A correct proposal at the wrong moment sits unused. Timing is part of the content.
- **Mechanism redesign under repeated play** (Method) — a one-shot defection becomes unattractive when the relationship repeats. Change the game's length, not only its payoffs.

## L. Decisions, sequencing and commitment

- **Two-way vs. one-way door** (Model) — reversible decisions get light gates and fast moves. Irreversible ones get heavy analysis. Most slowness comes from applying one-way scrutiny to two-way decisions.
- **Kill criteria, pre-committed** (Move) — state the falsifiable condition that would stop the direction, before you are invested, ideally named by someone other than the person who wants it to succeed.
- **Sunk-cost zeroing** (Move) — if deciding today with zero prior investment, would you choose this path?
- **Real options** (Mindset) — a high-uncertainty exploratory step can be worth funding for the option it buys even if its expected value is low.
- **Reversibility-first sequencing** (Move) — among valid next steps, do the cheapest-to-undo one first.
- **Fail-fast ordering** (Move) — test the riskiest, most plan-killing assumption first.
- **Critical path** (Move) — only work on the critical path changes the timeline. Other optimisation is often effort that looks like progress.
- **Set-based concurrent engineering** (Method) — keep several feasible designs alive longer than feels comfortable. Narrow by data, not by decree.
- **Backcasting** (Move) — specify the success state first and work backward: what must be true one step before that, and before that?
- **Punctuated equilibrium** (Model) — expect long stasis broken by sudden reconfiguration. Ask what would trigger the next break and whether you're positioned for it.
- **Phase transitions / apparent plateaus** (Model) — a system can absorb effort with no visible change and then cross a threshold. An effort that looks stalled may be close to one. Ask what the threshold variable is and how close you are.
- **Assumption-based planning with signposts** (Method) — for each load-bearing assumption, name the observable sign that it's failing and the pre-committed response.
- **Info-gap robustness** (Model) — under deep uncertainty, ask what performs adequately across the widest range of futures, not what is optimal under one forecast.
- **Lindy effect** (Model) — for a durable thing, expected remaining life is roughly proportional to its age. Use it to test whether a "durable" assumption is durable.
- **Information-action check** (Move) — what decision, file or purchase changed because of this analysis? If none, it hasn't happened yet.
- **Pareto frontier mapping** (Model) — when objectives trade off, map the non-dominated options before choosing a point, and say which axis you sacrifice.
- **Design of experiments / Taguchi** (Method) — when each test is expensive, use a structured design that learns about several variables and their interactions in few runs. Taguchi adds: optimise for robustness to noise you can't control.
- **Marginal cost of the next unit** (Move) — for scaling questions, ask what the next unit costs, not the average. High fixed cost with near-zero marginal cost needs a different plan.
- **Sensitivity-ranked allocation** (Move) — put effort and budget where the outcome is most sensitive, not where the estimate is most exciting.
- **Genetic-style variation and selection** (Method) — represent candidates as recombinable parts, generate variants, select against an explicit fitness criterion stated in advance.
- **Beam search** (Method) — keep the top-k candidates at each stage. Avoid both single-candidate tunnel vision and unaffordable breadth.

## M. Communicating and adopting the result

- **Sensemaking** (Mindset) — people act on the story that makes the situation sensible enough to act on, not on raw analysis. Build that story deliberately.
- **Narrative transportation** (Move) — for a disruptive proposal, give one concrete scenario of it already having succeeded. Abstract argument alone under-motivates.
- **Ethos, pathos and logos** (Move) — design credibility (why should they trust this source) and stakes (why does it matter to them) alongside the logic.
- **Speech-act awareness** (Move) — separate descriptions ("this is faster"), commitments ("we will ship by Q3") and declarations ("this project is now Phase 2"). Mixing them causes real confusion about what's being decided.
- **Euphemism audit** (Move) — replace every softened phrase with its plain equivalent. If the plain version is uncomfortable, the soft one hid the tradeoff.
- **Subtraction before presenting** (Move) — see §A.

## N. Verification and anti-bluffing (cross-cutting)

- **Epistemic tagging** (Move) — `verified` (checked against a source or computation), `derived` (follows from tagged premises), `plausible` (consistent, not checked), `speculative` (a guess). Decide the tag before writing the sentence.
- **Tool-free ladder** (Method) — without tools, climb by: a genuinely different re-derivation; an invariant or boundary test; consistency with established results. Each climbs reasoning only. Empirical premises keep their tags.
- **Adversarial red-team** (Method) — actively try to break your strongest claim. No attack found is weaker evidence than a claim that survived one.
- **Steelman-then-attack** (Method) — build the strongest version of the competing explanation before attacking your own. If you only win against a weak alternative, you don't know it's better.
- **Known-error injection** (Move) — plant a deliberate error and confirm your check catches it. Otherwise your verification may be theatre.
- **Gell-Mann amnesia check** (Move) — have you caught this source being wrong about something you understand well? If so, discount everything else from it.
- **Circle of competence** (Mindset) — is this a domain where you have an edge? "No edge" is useful information, so lower your confidence.
- **Technical Johari window** (Model) — the most serious failures usually sit in unknown-unknowns. Ask what you haven't thought to ask.
- **Known-plaintext / crib** (Move) — one verified anchor fact collapses the search space more than many unverified guesses. Verification is also a search-space reduction tool.
- **Novelty is not correctness** (Mindset) — tag both. A claim that sounds disruptive is not thereby evidence.

## O. Far-transfer bank (pre-mapped; every entry still needs its own component mapping)

- **Epidemic threshold (SIR)** — spread only persists above a reproduction threshold. Use for referral growth, advocacy or norm adoption.
- **Critical mass (chain reaction)** — value exists only above a participation threshold. Use for marketplaces and protocols.
- **Red Queen coevolution** — matching a rival only restores relative position. Change the dimension you compete on.
- **Asymmetric warfare** — an incumbent's scale becomes a liability in segments it can't profitably serve. Find that segment.
- **Keystone structure** — importance comes from structural position, not size. Find the component whose loss cascades.
- **Annealing** — converging too fast freezes in a poor solution. Pace exploration before commitment.
- **Bet-hedging / portfolio** — under unpredictable futures, variety beats the single best guess.
- **Crib-based cryptanalysis** — one verified anchor narrows the search.
- **Market making / clearing house** — counterparty risk blocks trade; an intermediary that absorbs the risk unblocks it.
- **Immune memory** — rehearsing against weakened threats builds lasting defence. Use for red-team drills and chaos testing.
- **Mycorrhizal exchange** — resources flow through an intermediary that takes a cut. Use for platform and ecosystem design.
- **Pull incentives / advance market commitment** — invest when future demand is guaranteed, not speculative. Use for public goods and stewardship goods.
- **Insurance pooling** — individually catastrophic risks become collectively affordable.
- **Queueing (Little's law)** — links throughput, delay and work-in-progress. Use for any backlog.
- **Control with delay** — overreaction to delayed signals causes oscillation. Use for bullwhip effects, hiring cycles and inventory.
- **Error-correcting codes** — reliable output from unreliable parts through redundancy and structure.

## P. Named cross-disciplinary references (look up, don't recall)

- **Buchanan's four orders of design**, **Kauffman's adjacent possible**, **Kermack–McKendrick**, **Lakatos research programmes** (progressive: novel confirmed predictions; degenerating: only patches), **Semmelweis reflex** (is this rejected because it's wrong, or because accepting it means admitting a long error?), **Feynman's "you are the easiest person to fool"** (what am I most motivated to believe?), **Kuhn's incommensurability** (are we disagreeing about facts, or about what counts as a fact?), **Quine–Duhem** (a failed prediction doesn't say which assumption failed; list the auxiliaries), **Popper's bold conjectures and severe tests**, **Taleb's convexity** (a negative-expected-value test can be worth it if the downside is capped and the upside is large), **Goldratt's critical chain** (remove task padding, pool it into a project buffer), **Liberating Structures** (micro-structures for inclusive discussion), **Robust decision making** (RAND ensemble-of-futures approach).

---

## Limits (say these plainly when they apply)

- Institution-type techniques (nemawashi, ringi, DSMB, skunkworks, liberating structures, constructive controversy's role reversal) need real people. Name the gap; offer a solo substitute and say what it loses.
- Physical testing, building, and implementation are outside this skill. It can say what test isolates which variable.
- The skill structures how to search for non-obvious angles. It doesn't replace domain expertise about what is true in chemistry, law or engineering.
- Combinatorial candidates from the operators in `crack-moves.md` are new and unvalidated. Label them as freshly generated and tag them no higher than `derived` on the reasoning.

# #complexcausality — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/complexcausality/](https://my.minerva.edu/academics/hc-resources/hc-handbook/complexcausality/)
> **Foundational Concept** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Interacting with complex systems
> Taught in: Complex Systems | Semester One · Unit: Characteristics of Complex Systems
> Big Question: How should the world be governed?

## Definition

**#complexcausality** — Identify ways that multiple causes interact to produce complex effects.

> **Pitch:** Simple causal relationships are fine, unless you care about the real world.

To unpack the causes of behavior of complex systems, one has to identify multiple causes and the ways they interact to produce secondary, tertiary and higher-order effects. ‘Higher order’ here means further downstream in the causal chain - the effect of the cause we are studying. In some cases, only a combination of particular causes lead downstream to a specific higher-order effect. A detailed analysis of the complexity of causal interactions notes that some causes are necessary to produce a particular effect, whereas others may be jointly sufficient for the effect but not required. A particularly important case of complex causality is ‘feedback loops,’ which refer to situations where a particular trigger causes, downstream, an increase or decrease in the very quantity or behavior that caused the original trigger, thus either enhancing itself in a ‘snowballing’ effect in a “reinforcing” (positive) feedback loop, or directing the system to an equilibrium in a “balancing” (negative) feedback loop.

## Worked example

You are considering how to solve the issue of homelessness in San Francisco. You realize you need to first understand what causes homelessness in order to approach ending it. You identify three main causes: drug addiction, mental health issues, and lack of access to financial opportunities. You consider how these might interact and perhaps lead to or reinforce one another. Drugs may worsen, or cause, mental illness. These, in turn, can cause financial challenges. However, drugs can also be the direct cause of financial struggles, even if mental illness is not involved. You realize there is no single necessary cause for homelessness you could target, but rather a number of separate causes (some of which may be on their own sufficient, or more realistically make it very likely one would end up homeless). This means the best way to approach the problem would be to evaluate these causes and find the ones that most bear on homelessness. You realize that because drugs and mental health issues can cause financial struggles to a larger extent than the opposite, it might be more useful to start by tackling them first. Tackling financial struggles would require you to also tackle drugs and mental health issues since they are higher-order causes. You therefore propose to the city government to start drug addiction recovery services for the homeless, hoping that this would improve the mental health and financial conditions of the homeless.

> **Footnote:** Several causes are identified as necessary or sufficient, utilizing this classification to guide the analysis. The way that causes interact is explored and levels of influence are attributed to different causes, choosing to target the most influential cause to prevent the undesirable effect.

## Is it this HC?

Is #complexcausality the right HC? If the answer to the following questions is yes, #complexcausality could be useful:

- Does the explanatory challenge involve multiple variables/causes that are interacting in a complex manner (e.g. feedback loops and causal chains)?

- Do you need to analyze the structure of causal relations?

Depending on the work product, there might be other HCs to consider. ….

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#emergentproperties](emergentproperties.md) | Focuses on an outcome (higher-order effect) without analyzing how lower-level causes lead to the outcome. In contrast, #complexcausality is more interested in the causal interactions leading to the outcome. |
| [#systemdynamics](systemdynamics.md) | Looks at how a system changes over time given the values of the dimensions. The system phase is often determined by feedback loops (e.g., balancing feedback loops when the system is in equilibrium). Focuses on the places in the phase space where the system moves from one basin to another, as opposed to analyzing the triggering causes of the transition. |
| [#networks](networks.md) | Explores a phenomenon that emerges due to the specific structure of the connections between the agents. Involves a diagram where the nodes are agents and edges are connections between the agents (not to be confused with a causal diagram). |
| [#levelsofanalysis](levelsofanalysis.md) | Analyzes the interactions between multiple levels, including looking at causes on one level and effects on another. |
| [#communicationdesign](communicationdesign.md) | Applies principles of perception and cognition to communicate effectively. It may be used to create comprehensive causal diagrams. |

## Self-study Q&A (4 questions)

**Q1. What are some properties of reinforcing vs. balancing feedback loops? How can you distinguish them in the diagram?**

Reinforcing (positive) loop is a type of feedback loop where an initial change leads to a further change in the same direction, and as a result, the system is pushed further away from the initial state. Exponential growth/decay can be an indicator of reinforcing feedback loops. For example, during labor, pushes from a baby initiates oxytocin release, which stimulates contractions. These contractions, in turn, amplify the oxytocin level.

In contrast, the balancing (negative) loops act against the initial change to maintain the system in a dynamic equilibrium. For example, according to the law of demand, when a price of a product goes down, the demand will go up. Increased demand will result in higher prices which means that the price will fluctuate within certain boundaries. 

There are multiple ways of representing reinforcing and balancing loops in a causal diagram. You can distinguish them using “+” and “-” signs, colors, or the type of arrows. You can also vary the thickness of the arrows to indicate the importance of causal factors. It is important to keep the format consistent and mention the meaning of each indicator.

**Q2. Define the following phrases and provide an example: Necessary, but not sufficient; Sufficient, but not necessary; Both necessary and sufficient; Neither necessary nor sufficient.**

Necessary, but not sufficient is a cause that is required, however, it alone is not enough for the outcome. 

Sufficient, but not necessary is a cause that can lead to an outcome without the contribution of other factors, however, there are other ways to achieve the outcome. 

Both necessary and sufficient is a cause that can lead to an outcome by itself, and it is also a requirement for that outcome. 

Neither necessary nor sufficient cause does not play a significant role, however, it may be causally salient, meaning it can be an indirect contributor.

**Q3. What are some typical mistakes in causal reasoning?**

There are multiple causal fallacies, for example, mistaking correlation as causation which is when we assume a causal relationship just because two variables are associated with each other. Another example is the fallacy of the single cause which happens when the causal interactions are oversimplified by wrongly presupposing that an event has a single cause.

**Q4. What is the distinction between triggering and standing causes? Explain using an example.**

A triggering cause is a cause that sets into motion a chain of events that leads to an effect. A standing (structural) cause is a static condition already present in the environment, which, combined with the trigger cause, leads to the effect. For example, a riot against high unemployment rates was triggered by a sudden mass dismissal of workers from the public sector. The sudden mass dismissal was a triggering effect, but high unemployment rates were already present in the country, so they can be considered a standing cause that contributed to the riots. These concepts can be reviewed in the Causation tutorial by Lau & Chan, which is linked in the Key Resources section below.

## Guided reflection (proficiency checklist)

1. Have you analyzed the interactions between the causes?
2. Have you utilized causality terminology (e.g. sufficient/necessary, standing/triggering cause, higher/lower order causes)?
3. Have you identified subtle causes?
4. Does your application shed light on the explanatory challenge?
5. Have you integrated the analysis of causal structure into the overall argument?
6. Have you used an appropriate visual aid to aid your analysis?

## Common pitfalls

1. Simply lists multiple causes without analyzing their interactions.
2. Overlooks relevant causes or fails to identify subtle causes.
3. Does not provide a (full) explanation of the causal diagram.
4. Does not describe the entire feedback loop making the explanation for why variables form a loop less convincing.

## Applying the HC at Minerva

1. You may need to examine the marketplace using complex causality in Business college.
2. The HC can be used by Sustainability minors to develop sustainable practices by looking at the root causes of environmental issues.
3. In courses in the Cells and Organisms track, #complexcausality is common. Certain phenotypic traits are produced by complex interactions among alleles. Expression of an individual gene is typically regulated through interactions of multiple cis-acting and trans-acting factors. Biochemical pathways may have branching structures where multiple components interact, and these may be regulated by additional causal interactions.
4. #complexcausality is helpful for those doing Sustainability minor and Earth’s systems concentration to examine complex causal interactions in nature. For example, a rise in global temperatures cause permafrost to thaw. As a result, methane, a particularly potent greenhouse gas, is released leading to a further increase in global temperature. This is an example of a reinforcing feedback loop that will be studied in Earth’s systems classes.
5. #complexcausality is also relevant in political philosophy. For example, when analyzing the injustice of sweatshop labor, it can be tempting to boil this down to a simple string of causal interactions. Someone has a factory and sets wages; employees accept those wages. There are consumers (often in higher-income economies) who choose to buy sweatshop labor products to save money, increasing the incentives for multinational corporations to continue housing their factories in lower-wage economies. There are governments of developing countries that impose lower tariffs on MNCs to achieve certain macroeconomic goals, creating a conducive environment for sweatshop labor. Low cost, demand from consumers, and lower bureaucratic threshold lead to a higher-order effect of MNCs housing factories in lower-wage economies. Therefore, when analyzing the injustice of sweatshop labor, it would be overly simplistic to point to factory owners without recognizing the complex relationships across national boundaries.

## Applying the HC outside Minerva

1. You can use this HC when analyzing social systems since social phenomena are usually driven by multiple causes. For example, business consultants may need to look at the causal structure of the issue to understand the most important causes to provide an effective strategy.
2. The HC is applicable in genetics when trying to understand the causes of complex traits such as intelligence, or diseases such as schizophrenia. Such traits are determined by interactions between multiple genes and epigenetics which could be understood through a complex systems lens. You can learn more about the topic from Wagner’s paper linked in the Key Resources.
3. You notice that you tend to self-sabotage and want to understand the causes of such behavior. You identify multiple causes such as the fear of failure, perfectionism, fear of success, personal beliefs, the need of belonging, etc. You then mapped out interactions between the causes in a causal diagram. Lastly, you evaluated the significance of each cause which helped you to prioritize which causes to address.

## Key resources

1. Sheskin, M. (2021) Characteristics of Complex Systems – a Brief Introduction. https://docs.google.com/document/d/1cxCp8FqZB_bN_AaMTUgAnv36gu0bDEHpRwMgkEI5VX8/edit
- This is an overview of all the CX HCs. Visualizations for each HC can help you distinguish them and make sense of how they complement each other.
2. Lau, J. & Chan, J. (2015). Scientific methodology. Critical Thinking Web. https://philosophy.hku.hk/think/sci/index.php
- This is the landing page for relevant tutorials on Causation, Causal inferences, Causal diagrams, and Causal fallacies.
3. Thwink.org. (2014). Feedback loop. https://web.archive.org/web/20161104161114/http://www.thwink.org/sustain/glossary/FeedbackLoop.htm
- This page explains two types of feedback loops and the kind of patterns they lead to.
4. FitzGerald, M. and Schiman, K. (2014). Unit 5.1: Causal Reasoning -- Necessary and Sufficient Conditions. Khan Academy. https://www.youtube.com/watch?v=3R1W3jhtCY4
- The video explains the meaning of necessary and sufficient conditions.
5. Wagner, Andreas. “Causality in Complex Systems.” Biology & Philosophy, vol. 14, no. 1, Jan. 1999, pp. 83–101, www.santafe.edu/research/results/working-papers/causality-in-complex-systems
- This paper examines the notion of causality from the perspective of mathematical biology. It provides examples of causal inference in complex genetic systems.
6. ☕️☕️☕️ Neall-Johnston, C., Daskalova, T., & Gale, A. (2026). Episode 2: #complexcausality with Prof. Gale. HC Coffee Chats. Minerva University. https://drive.google.com/file/d/1vOT9kLLaTccLlRIckGmiVrDno8dzens6/view?usp=sharing 
- Learn more about #complexcausality as Prof. Gale shares how interconnected causes show up in earth science, leadership, and her own life. Tune in to hear how #complexcausality can reshape the way you see everything in the decisions you make every day.

## Custom HC guides

- [Characteristics of Complex Systems – a Brief Introduction](https://docs.google.com/document/d/1cxCp8FqZB_bN_AaMTUgAnv36gu0bDEHpRwMgkEI5VX8/edit)

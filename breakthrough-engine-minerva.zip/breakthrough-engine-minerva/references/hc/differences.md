# #differences — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/differences/](https://my.minerva.edu/academics/hc-resources/hc-handbook/differences/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Working with others
> Taught in: Complex Systems | Semester Two · Unit: Complex Agents
> Big Question: What does it mean to behave rationally?

## Definition

**#differences** — Identify and be responsive to people’s different skills, abilities, traits, attitudes, beliefs, and social position.

> **Pitch:** If you own a hammer, find a friend with a screwdriver.

People differ in their skills and abilities, their attitudes and beliefs, and their identity and social position. These various differences interact to shape how they experience and participate in group settings, such as cooperative projects. Careful consideration of individual differences is necessary for creating an environment in which diverse perspectives are valued and the potential for individual contribution is maximized. When groups respond appropriately to individual differences, group performance benefits from diverse perspectives and backgrounds, although it is also important to identify shared perspectives and values within groups.

## Worked example

You are trying to allocate work to two members of your team, Amar and Bo, as part of a major project to design a transportation Hub in your city from which all metro lines will leave. You understand the project needs to be completed before a major sports event to be held in your city, and involves a complex web of transit lines. From past projects, you know Amar is more organized and detail-oriented, but doesn’t do so well with interacting with coworkers. You assign them independent work where they need to focus on fitting all the lines together so as to not have any unintended overlap. This will be critical because of the complexity of the work, and Amar is the best fit due to their ability to think clearly and self-manage. Bo, in contrast, is more extroverted and better at decision making and communicating. Given the project's nature, you will need to coordinate with different transit operators. Because Bo is an effective communicator and good at interacting with others, you put them in charge of reaching out to all the different transport agencies and coordinating among them. Additionally, Amar and Bo have different experiences with public transport that stem from how their social position is recognized by others and how they have interacted with public transport. Therefore, you make sure that everyone is encouraged to share their perspectives on safety and accessibility. This will ensure the team is able to tackle the project with appropriate attention to detail as well as sufficient external communication, allowing you to focus on the overarching vision.

> **Footnote:** Observing the team-members’ behavior to identify personal characteristics and social position allows allocating roles wisely and enabling the sharing of perspectives. The individual differences between team members are relevant predictors to their potential response to a certain role, and thus Amar and Bo’s characteristics guide their assignment into roles.

## Is it this HC?

Is #differences the right HC? If the answer to the following questions is yes, #differences could be useful:

- Are you identifying differences between people, often in a team-work context?

- Are you acknowledging those differences and explaining how they can be respected, accommodated, or utilized?

- Are you addressing the implications of specific differences in a given context?

- Are you explaining how to create an environment in which differences are valued and welcomed?

Depending on the work product, there might be other HCs to consider…

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#psychologicalexplanation](psychologicalexplanation.md) | Uses theories of psychology to explain human behavior, identity, emotions, thought, etc. Often this HC generalizes psychology across individuals, but psychological theories can also explain how uniqueness manifests in individuals from external/internal factors. |
| [#selfawareness](selfawareness.md) and [#emotionaliq](emotionaliq.md) | Tries to understand yourself, using tools of metacognition or emotional intelligence. Personality tests are one example of concepts useful for these HCs as well as #differences, but note that #differences is always about interactions/co-working between people. |
| [#emergentproperties](emergentproperties.md) | Analyzes how low-level properties in a complex system lead to an emergent phenomenon on a higher level. In a team-work context, #differences can combine in a way that causes an emergent property, if the team outcome is something qualitatively distinct (like community). |
| [#conformity](conformity.md) | Analyzes how humans conform or go against social norms. Parts of our identities and differences are rooted in group identity, while conformity is at the same time context-dependent. Sometimes, differences are eliminated in group environments where factors amount to a strong pressure to conform. |
| [#audience](audience.md) | Analyzes how to tailor a message to an audience, considering their situation/interpretation. You could analyze how an oral/written work lands differently for different audience members. #differences is more about interactions between different people. |
| [#interpretivelens](interpretivelens.md) | Analyzes how one’s individual experiences/expectations/judgments affect interpretation. This might be an important HC too in a teamwork context, but is always focused on deeply analyzing the unique features of one person, rather than how multiple unique individuals interact or cooperate (#differences). |
| [#responsibility](responsibility.md) | Creating structures of accountability and proactivity to achieve goals (often as a team). It might be relevant to realize that accountability works differently for different team members, and some people might be better at acting out certain roles (i.e., motivator vs organizer) to create an accountable teamwork dynamic. |

## Self-study Q&A (6 questions)

**Q1. What kind of differences can you focus on?**

Skills - some people have certain specific skills that they can already put to use, for which others might need a learning environment or resources to acquire.

Abilities - some people simply aren’t able to do certain things, or need to be enabled in order to do so. This can go from physical to mental ability. Additionally, these abilities often overlap with other qualities. For example, people on the autism spectrum tend to be less able to deal with changes in structure or social complications, but at the same time, they are usually much more detail-oriented and often have high motivation and commitment to specific tasks, or topics.

(Personality or Teamwork) Traits - personality and teamwork style is relatively consistent throughout life. Using different personality/teamwork tests can help you improve your understanding of yourself and others, often they also suggest strategies to deal with weaknesses or utilize strengths. 

Attitudes Beliefs/Values - having different ideas can help teams evaluate different kinds of arguments when having to make difficult decisions. Additionally, different beliefs/attitudes can cause conflict. Making sure that understanding is fostered can help alleviate problems. Differences in core values may complicate the purpose or goal of a group activity or project.

Demographics (ADDRESSING) - Diversity in Gender identity, cultural background, race, age, socio-economic background, geographic background, and so on – is an important part of individual and group identity, and these elements may correlate with differences in other categories. Additionally, there are often also fundamental differences in people’s realities and past experiences when they belong to certain socially constructed groups that can limit or enable them to think in a certain way, or to empathize with their own and other groups. Having diversity in these categories is proven to improve teamwork and team output when they are appropriately valued and respected.

**Q2. Female Engineering graduates tend to improve team performance when on a team with mostly male colleagues. What could explain this (relating to #differences)?**

Engineering companies want to attract female engineers, since groups of male engineers tend to be quite homogenous (in more aspects than their gender), which can cause groupthink, a lack of new perspective, and less resilient performance. Additionally, collaboration among all team members tends to be easier when there are differences on a team. Engineering is a male-dominated field, which means companies often have large teams only consisting of men. Women often face barriers to entering the industry that have to do with social perceptions and education systems that do not always stimulate girls to choose fields of STEM. 
Of course, other dimensions of diversity are also important, including geography, age, etc. It must be noted that these are based on averages across many teams, and that in a specific case, differences are more complex, intersectional, and not necessarily directly based on gender/location/age.

**Q3. Why are differences emergent from factors rather than a simple addition of them?**

Merely listing social differences, like gender, race, or age, fails to account for ways that our differences combine in ways that make us more or less susceptible to discrimination or privilege based on the unique ways these differences interact. The concept of intersectionality describes ways our experiences as an individual depend on intersections of many different aspects of our social identities, advantages, and disadvantages. For example, someone who is subject to a higher risk of discrimination and social bias due to their gender identity could also be subject to social privileges due to their racial identity. Failing to account for the complexity of intersecting differences would result in a failure to account for ways societies use complex differences as placeholders for qualities, which would make it impossible to seek adequate forms of restitution and reparation. Paying attention to intersectionality encourages us to think about the complexity of differences and improve how we respond to this.

**Q4. You are considering two ways to divide tasks within a team:
- Divide tasks based on expertise - everyone does what they’re best at.

- Divide tasks based on Belbin’s team role strengths.

- Divide tasks to increase learning - people don’t necessarily work on what they’re good at, but are encouraged to challenge themselves and learn from each other.
What is the best option?**

Of course, there is no one best option!

You might choose:
- (+) It might lead to high performance/productivity in the short term, allowing you to accomplish your goals quickly and efficiently. It also can be motivating for people to feel valued in their strengths.
(-) In the long term, people are not growing as much in your company. Additionally, there might be conflicts arising when people have to collaborate on things together. They might be confused with each other’s input.

- (+) It might lead to smooth cooperation, and people understanding their place in a team. For example, people that are good at criticizing ideas are encouraged to do so in the teamwork structure/process, so it does not lead to frustration/delays, but is put to good use at the right time!
(-) Similarly to 1, it might reduce people’s growth within their role. It can also be based on a limited understanding of a person.

- (+) This option might be best for all members in the long-term, if growth is what they want. It can also foster an environment in which strengths and weaknesses are valued because people are accountable to help each other out with them, rather than being frustrated about differences, they become an asset.
(-) In the short term, you might see lower productivity, and challenges can also drain employees.

**Q5. Many people say that once they do a certain teamwork personality test, that their collaboration improves, even if nothing in the teamwork structure or role division changes. Can you explain why this might happen?**

Although GI Joe fallacy – thinking that by being aware of a bias, one already took away most of the negative effects of that bias – can be of influence, people might simply change their response when differences cause friction in a team. For example, there are tests that show different ways people respond to stressful situations. One person might immediately seek out solutions, others might focus on continued harmony or balance in a team and careful evaluation. When people are made aware of their different tendencies, they are not frustrated anymore with each other, or might even start to appreciate each other’s different approaches in conjunction. A person usually focusing on solutions might now mention to their colleague: “I know I tend to go full solution-mode, so I was wondering if you have any concerns about our teamwork before we discuss the ones I came up with?” Gestures like this can greatly improve the functioning of a team. The essence of #differences is about understanding differences, and analyzing either that understanding and appreciation can alter interactions. You might also apply strategies to improve teamwork with a certain goal in mind (like increased learning or performance, or less conflict), for which this understanding provides the foundation.

**Q6. How can the ADDRESSING model help us explain human behavior and what are its limitations?**

The ADDRESSING model of identity provides a starting framework for systematically thinking about how various #differences might affect an individual’s psychology. The model allows us to look at the components of identity, Age, Developmental and acquired Disabilities, Religion, Ethnicity, Socioeconomic status, Sexual orientation, Indigenous heritage, National origin, and Gender. The model acknowledges that certain aspects of identity are associated with power imbalance and privilege, which could influence people’s dignity and individual psychology. 
However, this model is limited, and should be applied with caution. It is important to be aware of the ways that categorical thinking can erase fine-scale differences and may reinforce stereotypes. It is also important to consider the role of intersectional effects, where multiple aspects of identity combine to produce experiences and outcomes that are not reducible to the individual identity elements (think #differences plus #complexcausality).

## Guided reflection (proficiency checklist)

1. Have you identified and defined what kind of differences are important to consider?
2. Have you explained the conditions necessary for differences to be respected?
3. Have you explained how differences can cause conflict or foster cooperation in a team?
4. Have you outlined strategies or approaches to utilize differences to achieve some kind of goal?
5. Have you explained the kind of group dynamic that can arise from differences or structures that utilize differences?

## Common pitfalls

1. Just describing (cultural) differences is a superficial application of differences without an analysis of how they might conflict or synergize.
2. Showing that diversity leads to higher performance without addressing what specific aspects of differences result in the higher performance.
3. Sticking to analysis on an individual level, without explaining how differences alter group dynamics.
4. Assigning roles to people based on a superficial understanding of compatibility, without considering alternate approaches like those that bring people out of their comfort zone.

## Applying the HC at Minerva

1. Business: When trying to understand a business, teamwork is central, and diverse perspectives can be crucial to building a resilient business. However, simply achieving diversity in business is not what #differences is about. Be sure to evaluate what kind of differences are specifically important to consider in a given context and what can help you utilize those differences. For example, you might analyze a company that centers innovation. They require different teamwork structures and composition to bring about innovation, such as diversity in ideas, but also a structure that empowers those naturally able to generate, refine, or crowdsource ideas.
2. Science: Within scientific teams, appreciating differences can greatly improve scientific discovery. At various stages of research, it helps to include a variety of perspectives and acknowledge the strengths, weaknesses that different researchers bring to the table. For example, when doing research on a group of gender-queer participants, it would be beneficial to have intersectional perspectives on how those participants would respond to the proposed research, and have background knowledge from different angles (a black trans woman might see other points of improvement than a neurodivergent non-binary person). Differences are also essential to generate creative and groundbreaking hypotheses.
3. Civic Projects (and group assignments): Sometimes, doing some team building through understanding each other’s differences can set you up for success in longer projects! It might give clarity on what everyone is good at, so that you know who to count on for what when the time comes. It will also help you understand how people respond differently to any challenging situation that might arise. You can understand how to make teamwork work for different styles of work!
4. Law: When studying laws against discrimination it’s important to study the histories and context of discrimination against individuals and groups on the basis of their social position or identities. For example, you might apply #differences when challenging the adequacy of a ruling that found no discrimination present in a case where discrimination appears when multiple identities intersect, as law professor Kimberlé Crenshaw did when she criticized a ruling against five Black women who sued General Motors for discrimination against them as Black women in particular.
5. Neurodiversity: Applying this HC can lead to improved educational experiences by recognizing neurodiversity as a dimension of difference. You might come across this when studying theories of learning in psychology courses at Minerva, but it's applicable to educational design more broadly. The #differences HC helps us acknowledge that there is a wide spectrum of neurodiversity. There are natural differences in how students’ brains function, encompassing variations in sensory processing, executive function, motor abilities, and preferred ways of communication. With this in mind, students and educators can follow universal design principles to create environments and practices that benefit all participants, not just specific groups. For educators, there are many examples of good pedagogical practices that support diverse cognitive strengths and preferences. For example, courses with options for autonomy and varying challenge levels benefit all students by acknowledging their unique motivations and capabilities. See this paper for more: Compassionate pedagogy for neurodiversity in higher education. Students can also enhance their own collective learning experiences by moving away from framing 'differences' as deviations from a norm, and instead embracing neurodiversity with compassion and encouraging participation from all students.

## Applying the HC outside Minerva

1. Understanding your interactions with others in daily life: Understanding what sets you apart from others can actually help you connect better with them. The first part of this is really understanding how you work yourself , for example by doing a personality test, or from feedback of others (very much related to #selfawareness too!). You will see that you respond differently to certain types of people and events. The second part of understanding interactions comes from understanding what different people exist. Being prepared for different ways that other people think can increase understanding over confusement when interacting with a person you don’t know as well yet. Even within your family, you might find that you have different ways to solve problems, which is totally fine, although it might have led to conflict in the past.
2. Amplifying and including perspectives of others: By being aware of the possible differences that exist in our societies, we can recognize at what points – in our work, or daily life – certain perspectives can be beneficial or important to consider. Educating oneself on the different experiences of people can help us empathize and understand how we might get something out of hearing a perspective that hasn’t been infused yet in what we are about to do or think.

## Key resources

1. McAllister, K. & Niv, S. (2022, August 2022) Introducing individual #differences https://docs.google.com/document/d/1lJ-hLaZyCfWY4RsvZZWiBsa5T2WXyl-aZPsZn7iG1Rk/edit#
- This guide explains facets of personality and identity (by introducing the ADDRESSING model) as part of differences. It also discusses how collective intelligence arises (#emergentproperties) in groups and the conditions for it.
2. Page, S. (2007) Making the difference: applying a logic of diversity. Academy of Management Perspectives,21, 6-20. https://www.engineering.pitt.edu/contentassets/0192c0e1473b41a08c125c46e2a5dd51/making-the-difference--applying-a-logic-of-diversity.pdf
- This resource specifically focuses on how differences are helpful in improving team performance in relation to problem solving and prediction. It is an expansion on what is described in the first resource as collective intelligence or “Diversity Trumps Ability”. It especially highlights the need for an environment in which differences interact and build on each other.
3. Cherry, C. & Gans, S. (2018 December 12) Theories and Terminology of Personality Psychology. https://course-resources.minerva.edu/uploaded_files/mke/00164120-1002/personality-psychology-study-guide-ss51-spring-2020.pdf
- Fundamental background and guidance on the different ways to classify and understand personality. It also suggests some general rules that apply to personality in psychology.
4. Erdheim, J., Wang, M., Zickar, M.J. (2006) “Linking the Big Five personality constructs to organizational commitment.” Personality and Individual Differences. (41)5: 959-970. https://www.sciencedirect.com/science/article/abs/pii/S0191886906001516?via%3Dihub
- An example of how the most reliable personality test (the Big Five or OCEAN test) can help analyze some characteristics of people in teamwork settings. In this case, it discusses “affective commitment”: the level of commitment one has towards the organization. For a refresher on the Big Five, read Woodward, W. (2011 March 7) “Why Personality Matters in the Workplace.” — [link](https://www.foxbusiness.com/features/why-personality-matters-in-the-workplace)

## Custom HC guides

- [Introducing individual #differences](https://docs.google.com/document/d/1lJ-hLaZyCfWY4RsvZZWiBsa5T2WXyl-aZPsZn7iG1Rk/edit)

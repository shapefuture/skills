# #comparisongroups — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/comparisongroups/](https://my.minerva.edu/academics/hc-resources/hc-handbook/comparisongroups/)
> **Foundational Concept** · Cornerstone course: Empirical Analyses · Competency: Thinking Creatively → Applying research methods
> Taught in:  Empirical Analyses | Semester Two · Unit: Research Design
> Big Question: How do humans impact evolution?

## Definition

**#comparisongroups** — Identify and evaluate appropriate comparison groups for empirical study designs.

> **Pitch:** Without proper comparison groups, you might be comparing apples to oranges.

In empirical research, comparison groups are used to test alternative conditions or control for extraneous variables. These groups provide a comparison case for a result, giving the researcher more confidence that the independent variable of interest is having a measurable effect (or not) on the dependent variable. In most cases, one or more of the comparison groups should be a control group. Control groups are not subject to the independent variable or treatment of interest and are instead used as a baseline comparison and to identify the effect of extraneous variables (e.g., placebo treatment in a drug trial). Without an appropriate control group, results may be misleading or incomplete. Many studies use alternative comparison groups in addition to control groups. Comparison groups are also used when it is not possible to have a true control group. Alternative comparison groups test the effect of the independent variable in different ways (e.g., different doses of the same drug for one group of subjects vs. another or different levels of acidity in one part of the ocean compared to another). Choosing appropriate comparison groups can be difficult, therefore one must be able to identify the limitations of a particular comparison group and interpret the results accordingly. The goal is to create comparisons that evaluate the hypothesis while eliminating alternative interpretations.

## Worked example

You are designing a study to test a new teaching method in a middle school science class. The class is currently taught as a lecture with the teacher presenting new content to students using slides. Students can raise their hands to ask questions but are otherwise silent during lectures. You want to test the effect of active learning on students’ test scores. For one group you design a fully active class where students are engaged in discussion and practice with only a ten minute introductory lecture from the teacher. You also design a comparison group where there are 3-4 activities structured into the traditional lecture. Finally, you have to decide if you should have a control group that uses the traditional lecture format. Since many articles have been published showing that active learning improves student performance in class, you decide that the control group with no active learning may disadvantage students. You instead choose to use the test scores from the previous year’s lecture class as your control group and use the same test for your treatment groups.

> **Footnote:** Comparison groups were set up to compare the effect of different levels of active learning (independent variable) on student test scores (dependent variable). A historical control group with no active learning was chosen instead of a concurrent control group since evidence pointed to a potentially negative effect on students.

## Is it this HC?

Is #comparisongroups the right HC? If the answer to the following questions is yes, #comparisongroups could be useful:

- Are you constructing comparison groups after identifying independent, dependent, and/or confounding variables?

- Are you using the predictions from the comparison groups to rule out alternative hypotheses?

- Are you critiquing comparison groups from existing studies?

Depending on the work product, there might be other HCs to consider:

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#interventionalstudy](interventionalstudy.md), [#observationalstudy](observationalstudy.md) | Designs an interventional study. Comparison groups are an essential element of a research design. |
| [#sampling](sampling.md) | Describes the sampling methods, which are used in creating comparison groups. |
| [#variables](variables.md) | Identifies potential confounding variables, which is critical when constructing comparison groups. |

## Self-study Q&A (3 questions)

**Q1. What are the differences between a control (or a control group), and a control variable (or controlling)?**

A control group serves as the baseline that we can compare against the treatment group. For example, consider a simple experiment about the effects of a new fertilzer on plant growth rate. The control group plants have no fertilizer, while the treatment group plants are given fertilizer twice per week. After a few weeks, we observe that the treatment group plants are taller than the control group plants. We can then make inferences and conclusions about the fertilizer because we have the control group as a baseline comparison. 

A control variable is a variable that is fixed or eliminated, such that we can isolate the relationship between an independent variable and a dependent variable. Going back to the plant experiment, we only want to identify the influence of a new brand of fertilizer on green plants- all other variables should be controlled. For example, we should be sure that soil type, levels of water, and light are similar for all plants.

**Q2. What is the difference a negative control and a positive control?**

In a negative control, the control group is exposed to all experimental conditions except the treatment. In a positive control, the control group is exposed to all experimental conditions and an alternative treatment, usually with known effects on the dependent variable. 

For example, suppose there is a clinical study on the effect of a newfound drug on pain reduction. The treatment group receives pills that contain the drug of interest; the negative control group will only receive placebo pills (pills that resemble the treatment pills, but without the drug); the positive control group will have well-known painkillers (e.g., paracetamol). Note that a research study does not necessarily need both negative and positive control groups, depending on the aim of the study.

**Q3. What are comparison groups?**

In many cases, a “true control” group is not needed and instead the hypothesis requires different comparison groups to explore the effect of an independent variable. For example, scientists might like to explore the effect of pH on coral shell thickness. In this case, there is no need for a “control group”; instead, more interesting would be to perform an observational study on ocean regions spanning a range of pH. You might collect data on three groups: a low pH (e.g. 4-6), “normal pH”, and high pH group and compare the results. You would want to be careful to control for other variables like water temperature and salinity if possible to isolate the effects of pH. The key with comparison groups is to try to ensure that all variables other than the independent variable are reasonably constant/comparable. Whether or not it’s a true “control group” or not is dependent on the particulars of the hypothesis in question.

## Guided reflection (proficiency checklist)

1. Have you identified all relevant comparison groups?
2. Have you clearly explained how confounding variables are controlled using comparison groups?
3. Have you used alternative comparison groups to rule out alternative hypotheses?

## Common pitfalls

1. The application misses including a comparison group that would address an important alternative explanation of the results and does not explain why it was excluded.
2. The application has relevant comparison groups but does not control one or more obvious confounding variables.
3. The comparison groups that are established are only superficially described.
4. The application does not relate alternative comparison groups to the hypothesis of interest.

## Applying the HC at Minerva

1. Comparison groups used in medical studies are featured in Empirical Analyses. For example, if we are interested in the effect of a new drug on patients, the control group will receive placebo treatment (meaning taking pills that don’t have the drug), rather than not receiving anything at all. The placebo effect happens when a patient feels better about their health when receiving treatment, even though the treatment may have no positive effect.
2. Comparison groups are also used in social studies. For example, suppose we want to study the effect of exercise on mental health. It would be unreasonable to compare an 18-year-old with an 80-year-old. Hence, considering age as a potential confounding variable, we can create comparison groups based on age. Then, we can compare the control (without exercise) and treatment (with exercise) groups of the same age intervals to mitigate this confounding effect. Of course, we would also have to carefully define what “counts” as exercise, etc. This is the creativity required in scientific research!

## Applying the HC outside Minerva

1. The idea of comparison groups is useful day-to-day! Often there can be an instinct to compare one group to another without fully considering potential confounding variables. A shop owner might inadvertently think that a new marketing strategy was “effective” because their sales are higher. That said, for this to be true it would be critical to control for potential confounding variables. What if sales are higher simply because the economy is booming and people have more money to spend?
2. Comparison groups are commonly used in academic research. For example, in evolutionary biology, when we examine human influences on the evolution of dogs’ brain sizes, we would have a group of dogs in the past (e.g. 50 years ago) and a group of dogs present. Further, we may want to split dogs based on their breeds (subspecies) as alternative comparison groups. Hence, if humans do influence dogs’ brain sizes, we expect similar changes across all subspecies. However, if there is one particular group that does not conform to the general trend (e.g., all subspecies have their brain sizes increasing, but Huskies’ brain sizes decline after 50 years), we may need to reconsider the original hypothesis.

## Key resources

1. McDonald, J.H. (2014). Handbook of biological statistics (3rd ed.). Baltimore, MD: Sparky House Publishing. http://www.biostathandbook.com/confounding.html
- This short article introduces confounding variables and ways to control them.
2. Carpi, A., and Egger, A.E. (2009). Controlling variables. Visionlearning POS-2 (3), 2009. https://www.visionlearning.com/en/library/Process-of-Science/49/Controlling-Variables/163
- This short article discusses the process of controlling variables. Note that controlling variables is different from a control group.
3. Carpi, A., and Egger, A.E. (2008). Experimentation in scientific research. Visionlearning POS-1 (7), 2008. https://www.visionlearning.com/en/library/Process-of-Science/49/Experimentation-in-Scientific-Research/150
- This article introduces scientific experimentation, including positive and negative control groups. Focus only on the section 'Controls: Negative, positive, and placebos' for this HC.


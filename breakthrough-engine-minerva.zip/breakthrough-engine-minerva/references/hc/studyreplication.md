# #studyreplication — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/studyreplication/](https://my.minerva.edu/academics/hc-resources/hc-handbook/studyreplication/)
> **Foundational Concept** · Cornerstone course: Empirical Analyses · Competency: Thinking Creatively → Applying research methods
> Taught in:  Empirical Analyses | Semester Two · Unit: Scientific Method
> Big Question: How do humans impact evolution?

## Definition

**#studyreplication** — Evaluate and incorporate replicability in empirical study designs.

> **Pitch:** Battling the ongoing replication crisis.

For scientific results to be accepted as well-established they must be reproducible. To determine how broadly applicable the conclusions are, one can replicate the study in a variety of contexts (e.g., different experimental subjects, different scales, different researchers). When the results of an empirical study cannot be replicated, this can indicate that the conclusions drawn are incorrect, that the methods of testing are insufficient, or that an attempted replication may have not accurately replicated the study (e.g., may have conceptually, but not technically replicated the methodology of the study).

## Worked example

You read a summary of a recent research study that concluded that coffee is bad for our health. In another magazine, you read a summary that indicates that coffee is good for our health. You decide to look closely at both studies to see why they came to such different conclusions. The first study found a correlation between coffee drinkers and increased heart disease. This study was done with elderly working-class people in the UK. The second study found a connection between coffee drinking and decreased heart disease. This study was done with medical professionals in Denmark. You conclude that these are not necessarily contradictory, because they are not exact replications of each other. Understanding the potential confounds of using these two restricted samples, you decide to investigate the findings further by replicating the study through an interventional experiment, which would constitute a conceptual replication. You extract from these studies the hypothesis that coffee may be a contributor to heart disease, and a conceptual replication study will help you investigate this claim. You decide to run an RCT in which an intervention group drinks coffee, a placebo group drinks hot water, and a natural history group drinks none of the two (all three groups maintain all other health related habits constant). You find that, on the one hand, the increased metabolism rate due to coffee leads the intervention group to be more active and thereby perform more “cardio” exercise, improving their heart-health. At the same time, coffee seems to increase blood pressure, which poses a risk to older individuals with poor circulation. These findings may provide resolution to the discrepancy between the original studies, and they indicate that your hypothesis must be refined to accommodate the nuance. Nonetheless, because the replication was conducted in a rather homogenous population, you realize there may be problems with generalizing these results more broadly, and you decide that more studies have to be conducted in other populations.

> **Footnote:** After presenting two seemingly conflicting answers to the question “is coffee bad for your health”, a replication study is suggested to test a more specific hypothesis “is coffee bad for your heart”. The value of such replication is justified, and the results are evaluated in the light of obstacles to generalization, which suggests future replications (conceptual or otherwise) would be required for an adequate exploration of the hypothesis.

## Is it this HC?

Is #studyreplication the right HC? If the answer to the following questions is yes, #studyreplication could be useful:

- Are you designing a study replication to assess the original study’s validity and generalizability?

- Are you evaluating an existing study replication and proposing further improvements to the study design?

Depending on the work product, there might be other HCs to consider:

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#interventionalstudy](interventionalstudy.md) | Designs a study with an intervention/treatment, possibly indicating future research directions (potential replications). #studyreplication usually comes after a complete analysis of the original study. |
| [#observationalstudy](observationalstudy.md) | Designs a study without an intervention/treatment, possibly indicating future research directions (potential replications). #studyreplication usually comes after a complete analysis of the original study. |
| [#hypothesisdevelopment](hypothesisdevelopment.md) | Depending on the type of study replication, the exact hypothesis from the original study may or may not be used. In the case where a replication fails to reproduce results from an original study, alternative hypotheses may be generated. |
| [#sampling](sampling.md) | Modifies a single- or multi-stage sampling method during a partial replication. |
| [#comparisongroups](comparisongroups.md) | Modifies the comparison groups from an original study during a partial replication. |
| [#induction](induction.md) | Discusses the generalizability of a study’s findings (in different populations/ timescales), which may include the conclusions of a study replication. |

## Self-study Q&A (4 questions)

**Q1. What is the difference between “replicating” and “reproducing” a study?**

When we replicate a study, we repeat the procedure  or test the same hypothesis, depending on the replication type. Reproducing a study refers to the outcome; if a study is replicated and  identical results as the original study are obtained, we say the results have been reproduced. 

Note that study replications that are not exact do not necessarily aim to get identical results. If we get different results, it may point us to discoveries beyond the original study.

**Q2. How do validity and generalizability connect to study replications?**

- Validity: how likely the replication yields results of prior studies

- Generalizability: how likely the findings of the original study hold in different populations/ timescales

The closer the replication methods are to the original study, the more validity is being assessed. Thus, exact or partial replications are better at assessing validity. The more the replication extends outside of the original domain, the more generalizability is being assessed. This is the case for conceptual (different study design to test the same hypothesis) and quasi-replications (expanded scope beyond original domain).

**Q3. How can we interpret a study replication that contradicts the results of the original study?**

The intuitive thought would be either the original study or the replication has flawed methods. However, it’s also possible that both studies are correct in their own contexts. Note that one replication is usually insufficient to claim that the original study is right or wrong. Science builds knowledge through multiple replications that support (or refute) a particular hypothesis.

**Q4. Why are exact replications hard?**

Exact replications are challenging in many fields, usually due to the complexity of the field (e.g., genetic interactions) and logistical obstacles (e.g., slight differences in machinery or chemicals or research techniques). However, that does not mean that exact replications are impossible. For example, if you’re studying the reaction rate of chemical compounds within a lab-controlled environment, it’s feasible to follow the pre-determined methods rigorously.

## Guided reflection (proficiency checklist)

1. Have you explained how the replication adds value to the original study?
2. Have you justified your type of study replication (e.g., why partial replication over exact replication)?
3. Have you identified the limitations of the current studies to demonstrate the need for a study replication?
4. For partial replications, have you explained which aspects of the original study that are kept/modified?
5. Have you discussed the validity and generalizability of your study replication?
6. Are there any potential limitations of your study replication?

## Common pitfalls

1. The application identifies a limitation in an original study and suggests that a replication could be useful, but does not present a study replication design. Remember that #studyreplication is a study design HC.
2. The application does not explain the relationship between the replication and the original study, including why the type of replication was chosen (i.e., what is the 'value add' of this replication)?
3. The application does not consider the validity and/or generalizability of the study replication.
4. The application has a major flaw in the study replication design (e.g., doing an exact replication when a partial replication is more suitable).
5. The application mistakes a repeating step from a study method as a study replication (e.g., measuring the same variable before and after treatment in an interventional study is NOT a study replication).

## Applying the HC at Minerva

1. Natural sciences often use study replication to test the validity of studies. For example, in Empirical Analyses, we discussed Blondlot’s N-rays, a new type of radiation that was claimed to be discovered in 1903 (Trentkoff, 2007). Despite the widespread belief that N-rays have medical properties, other physicists have replicated the study and failed to reproduce Blondlot’s results. The replications showed that Blondlot’s claims are false, making the N-rays a form of pseudoscience. Science builds knowledge through study replications.
2. The replication crisis is the failure to reproduce the results of many prominent psychological studies (e.g., smiling will make you happier). Thus, when critiquing a paper in psychological courses, it’s important to evaluate its replicability (clarity of study methods) and reproducibility (how likely we would observe the same results).

## Applying the HC outside Minerva

1. The Collaborative Replication & Education Project (CREP) is an open project to encourage study replications in psychological studies, while also addressing the need to replicate highly-cited studies. Collaborators can select one of the listed studies and collect data individually based on the given methods. The collected data will then be analyzed to see if the findings of the dataset agree with each other, which will increase the validity of the existing studies.
2. The foundation of science is study replications. Most scientists are engaged in some sort of study replication to confirm and/or extend previous findings.

## Key resources

1. Nakagawa, S., & Parker, T. H. (2015). Replicating research in ecology and evolution: feasibility, incentives, and the cost-benefit conundrum. BMC biology, 13(1), 88. Retrieved May 11, 2016 from http://www.ncbi.nlm.nih.gov/pmc/articles/PMC4624660/
- This article is the main reading for this HC. It introduces the concepts of validity and generality, along with the types of study replications within ecology and evolution.
2. Singal, J. (2018, December 18). Psychology research is still fixated on a tiny fraction of humans - here’s how to fix that. The British Psychology Society. https://www.bps.org.uk/research-digest/psychology-research-still-fixated-tiny-fraction-humans-heres-how-fix
- This short article explains the importance of study replications in human-subject studies (e.g., psychology), because they only sample from the WEIRD population (Western, educated, industrialized, rich, democratic).


# #organization — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/organization/](https://my.minerva.edu/academics/hc-resources/hc-handbook/organization/)
> **Habit of Mind** · Cornerstone course: Multimodal Communications · Competency: Communicating Effectively → Using language
> Taught in: Multimodal Communications | Semester One · Unit: Writing as a Craft
> Big Question: What might a perfect society look like?

## Definition

**#organization** — Effectively organize communications.

> **Pitch:** An idea that could change the world might get derailed by how it is structured.

Written, spoken, and visual communication should be organized in a way that will be easy for the intended audience to understand and remember. Organization is helpful at every step of the creation process: from outlining original ideas to reverse outlining the final product. The organization should reflect the purpose of the document or presentation and accentuate what is most important for a given audience and context. A thorough application of organization streamlines the creative process and ensures all main points are highlighted and structured to be navigated effectively by the audience.

## Worked example

You are writing an article about changes in the world of football and the pitfalls of compensating individual success over team performance. You organize your pre-writing process by creating a draft outline of your preliminary ideas and the structure of your argument. You emphasize how personal success became more important than the team's success because of the rise of individual pay. You utilize supporting evidence from various teams in appropriate locations. You organize the information so that it’s clear why you are writing the article, how each section connects to the next one, why football fans should care, and end with a clear “call to action” — namely, to elevate amateur teams by rewarding the entire team for their collective success. You then create a reverse outline of your work to ensure that all your main points come across clearly.

> **Footnote:** Several aspects of clear organization were employed to structure a written piece such that it communicates a message effectively, including highlighting the purpose of the paper and the suggested actionable steps and linking the various pieces of evidence to walk the reader through the author's reasoning.

## Is it this HC?

Is #organization the right HC? If the answer to the following questions is yes, #organization could be helpful:

- Are you intentionally structuring your essay, argument, presentation, or other communication for your audience?

- Have you thought about the best sequence or location for certain elements of your communication?

- Are you considering multiple alternative organizational structures for your work?

- Have you intentionally used effective introduction, body, and conclusion sections in your communication?

- Are you critiquing the organizational structure of another communication?

However, depending on the focus of your work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#evidencebased](evidencebased.md) | focuses on how evidence has been chosen and structured to best support an argument. |
| [#thesis](thesis.md) | focuses on the content of the thesis statement. The placement of the thesis statement and how it guides the organization of an essay requires #organization principles, however the content of the thesis statement falls under #thesis. |
| [#professionalism](professionalism.md) | deliberately formatted and presented itself to align with discipline-specific conventions. |
| [#audience](audience.md) | consideration of the audience has meaningfully informed the organizational structure of your message. |
| [#communicationdesign](communicationdesign.md) | evaluates how the order of elements aligns with cognitive principles on how humans organize and interpret what they see and hear. |
| [#breakitdown](breakitdown.md) | organizes problems into tractable components to design solutions. |
| [#responsibility](responsibility.md) | focuses on following through, accountability, and proactivity, which can be helpful for organizing your work on a big project, especially organizing group collaboration on an assignment. |
| [#negotiate](negotiate.md), [#persuasion](persuasion.md), [#algorithms](algorithms.md), [#deduction](deduction.md), [#induction](induction.md) | uses these HCs along with #organization to strengthen an argument and improve communication. |

## Self-study Q&A (5 questions)

**Q1. What are three organizational strategies? For which type of scenarios would you prioritize one organizational strategy over another?**

(Note that the examples of scenarios provided are not exhaustive)

- Chronological Order: Organizing a research paper chronologically involves presenting the information in the order in which it occurred. This strategy is suitable for papers that describe a process, a series of events, or the historical development of a topic.

- Topical Order: Organizing a research paper topically involves grouping related information together, regardless of the order in which it occurred. This strategy is suitable for papers that examine a topic from multiple angles or explore various aspects of a complex issue.

- Problem-Solution Order: Organizing a research paper using a problem-solution structure involves identifying a problem or issue and presenting solutions. This strategy is suitable for papers that propose solutions to real-world problems or highlight challenges a particular industry or sector faces.

**Q2. What are some common ways people organize ineffectively?**

(Note that this list is not exhaustive)

- Lack of a clear thesis statement: A thesis statement is the main idea or argument of the essay and provides direction and focus to the paper. Without a clear thesis statement, the essay may lack organization and coherence.

- Poor Paragraph Structure: An essay should be organized into well-structured paragraphs that address a specific point or idea. Poor paragraph structure, such as paragraphs that are too long or contain multiple ideas, can lead to a lack of clarity and organization.

- Random or Haphazard Organization: Sometimes writers organize their essays randomly or haphazardly, with no clear order or structure. This can make the essay difficult to follow and confuse the reader.

- Failure to use Transitions: Transitions are words or phrases that connect one idea to another and help the essay flow smoothly. Without proper use of transitions, an essay may feel disjointed and disorganized.

- Inconsistent Point of View: It is important to maintain a consistent point of view throughout the essay, whether first-person, second-person, or third-person. Inconsistent points of view can be confusing and distract the reader from the essay's main points.

- Lack of logical flow: A well-organized essay should have a logical flow, with each point building upon the previous one. A lack of logical flow can make the essay feel disjointed and can confuse the reader.

**Q3. How is an organization structure different from an organization strategy?**

An organization structure refers to how the content is arranged, while an organization strategy refers to the overall direction guiding the writer's decision-making and writing process.

**Q4. How does the organization of a report change depending on its length?**

(Note that this list is not exhaustive)

- For shorter reports, such as one or two pages, the organization may be straightforward, with a clear introduction, body, and conclusion. The introduction should provide a brief overview of the report's purpose and key points, while the body should present the main findings or recommendations, and the conclusion should summarize the key points and provide any necessary follow-up actions.

- For longer reports, such as those that are several pages or more, a more complex organization may be necessary. These reports may require a table of contents, executive summary, introduction, background information, methodology, findings or results, discussion and analysis, recommendations, conclusion, and appendices. The table of contents helps the reader navigate the report, while the executive summary provides a high-level overview of the report's key points.

- For extremely long reports, such as those that are over 50 pages, the organization may need to be even more complex, with chapters, subheadings, and a detailed table of contents.

**Q5. What are the different organization techniques writers employ to build mood?**

(Note that this list is not exhaustive)

- Chronological order: Organizing events in the order they occur can help build a sense of tension or suspense. This technique is often used in mystery or suspense writing.

- Flashbacks: Flashbacks create a sense of nostalgia, regret, or longing. They can reveal important backstories or character details relevant to the story's mood.

- Foreshadowing: Hinting at future events can create a sense of anticipation or dread. This technique is often used in horror or thriller writing.

- Non-linear storytelling: Jumping back and forth in time or using multiple perspectives can create a sense of disorientation or confusion, which builds tension and uncertainty.

- Repetition: Repeating certain words, phrases, or motifs can create a sense of unity or emphasis. This technique is often used in poetry or lyrical writing.

## Guided reflection (proficiency checklist)

1. Does your introduction provide an effective roadmap of the rest of your work, previewing what is to follow?
2. Have you ensured your introduction outlines the context of your problem, your thesis, and the importance of your argument?
3. Have you ensured each paragraph has a topic sentence?
4. Have you made deliberate choices for the sequence of your communication? What comes first, what comes next, what comes last?
5. Have you incorporated transition sentences to clarify your organizational structure within the text?
6. Have you ensured your conclusion relates to your thesis and the arguments outlined in the work while leaving room to reflect on your argument’s implications?
7. Would your work be improved by including subheadings and a table of contents?
8. Do your title, headings, and/or subheadings add to the organizational flow of your work?
9. Have you contrasted the organizational structure with alternative structures and considered the tradeoffs of other organizational strategies?
10. Have you provided justification and support for your critique and suggested non-trivial improvements if critiquing organizational choices in communications from others?
11. Have you included a substantive footnote that justifies (a) how your organization ensures the target audience will understand and remember the message, (b) highlight specific, interesting choices, (c) describe how the sequence in which you present information supports the communicative intent, and (d) briefly discuss a viable alternative that wasn't chosen?

## Common pitfalls

1. The application does not provide an effective roadmap to the paper in the introduction, especially with longer essays.
2. The application discusses ideas or material before the necessary background information has been introduced or defined in the paper.
3. The application neglects topic sentences for each paragraph.
4. The application does not adequately consider the experience of readers navigating the communication.
5. The application includes figures, tables, and/or appendices, but the main text does not effectively reference these elements.
6. The application does not demonstrate consideration of alternative approaches.
7. The application neglects to include a substantive footnote/endnote to justify the organizational approach and demonstrate thoughtful engagement with this HC.
8. The application confuses #organization with project management, describing how they organized the collaboration on a group assignment. In reality, #organization applies only to communication pieces - assignments, documents, speeches, etc.

## Applying the HC at Minerva

1. Classes in which you produce written work involve utilizing different organizational strategies. For example, when writing a statistical analysis report, you may use a topical order to discuss each analysis with its relevant findings. On the other hand, when writing a paper on your country's historical development, chronological order may provide the best structure. This HC is relevant for all assignments, and you should use the organizational structure you think will best orient your audience and illustrate your message.
2. When writing a short story, plot structure plays a significant role in determining how engaging and clear your narrative is. While this doesn’t mean there’s only one effective structure, it does mean that organization should be intentionally adopted, like word choice, to support your writing goals.
3. Giving an oral presentation/talk requires careful consideration of #organization. Organizational strategies will depend on the presentation's length and the audience's attention span, but some general techniques help improve clarity. For example, from the start, the audience should understand the presentation's main goal so that they can follow along. It's also helpful to reinforce your main take-home points through regular repetition in the talk.
4. Structuring your senior tutorials and Manifest classes also involve applications of #organization. Active learning classes require careful consideration of the flow and organization of the activities and material. Developing a clear and realistic class outline involves setting priorities and incorporating planned segments that you can expand and cut in the live class context. Class design requires carefully organizing your lesson to ensure students achieve their goals.

## Applying the HC outside Minerva

1. Deliverable example: Blog Posts / Medium Articles
Considerations example: Outlining a blog post might be the perfect time to practice applying #organization. When half your audience skims your post, the post’s organization might be the key to answering your readers' questions: What are the sections of the article? Are there some sections that appeal more to me? What is each paragraph talking about?
Further resources example: How to Structure a Perfect Blog Post (With Examples) (Link: https://syedbalkhi.com/how-to-structure-a-perfect-blog-post-with-examples/)
2. Deliverable example: Research Papers
Considerations example: You might get frustrated when you have to follow your research area’s writing conventions. But when you read other people’s research, how did the authors make it easier for you to build on top of their work by sticking to writing conventions?
Further resources example: Structure & cohesion - Academic writing: a practical guide (Link: https://subjectguides.york.ac.uk/academic-writing/structure)
3. Deliverable example: Software / Code Documentation
Considerations example: How do you structure the documentation for your code? What might happen if you did not properly organize the installation and debugging guides?
Further resources example: How to Write a Good Documentation: Home (Link: https://guides.lib.berkeley.edu/how-to-write-good-documentation)
4. Deliverable example: Writing Feedback
Considerations example: How can you strengthen a point delivered in two sentences? Are there different ways to structure feedback?
Further resources example: 3 Simple Frameworks to Give Effective Feedback | by QuercusApp (Link: https://stories.quercusapp.com/3-simple-frameworks-to-give-effective-feedback-6c8a60ce6e9b)
5. Deliverable example: Dialogue / Negotiations / Political Speeches
Considerations example: As with writing an essay, your speech’s intention determines its structure. You might structure your speech chronologically to highlight changes over time or draw attention to relationships between factors through a comparison.
Further resources example: Structuring the Speech | Department of Communication | University of Pittsburgh (Link: https://www.comm.pitt.edu/structuring-speech)

## Key resources

1. Minerva Acdemic Team. (2023). Organization. https://my.minerva.edu/academics/curriculum/foundation-year/cornerstone-summer-preparation/resources/writing-resources/
- You can find this Cornestone summer preperation guide on organization by clicking on the “Organization” tab in Minerva's Writing Resources.
2. Minerva Academic Team. (2023). Writing an Argumentative Essay. https://my.minerva.edu/academics/curriculum/foundation-year/cornerstone-summer-preparation/resources/writing-resources/
- You can find a guide on organizing an argumentative essay by clicking the “Writing An Argumentative Essay” tab in Minerva’s Cornestone Summer Prep Writing Resources.
3. Nelson, B. (2010, February 9). Table of contents -- Archbook: Architectures of the book. Digital Research Centre - University Library. https://drc.usask.ca/projects/archbook/tableofcontents.php
- Did you ever wonder about the history of a Table of Contents? Did you know that the Table of Contents appears at the end rather than the start of a text in French publications? Why do you think this is? And how does the table of contents change across mediums? From clay tablets to digital magazines, this source explains how people have adopted the table of contents to fit their goals.
4. Harvard College Writing Center. (2020, August 23). Do you know what a reverse outline is? . The Barker Underground. https://harvardwritingcenterblog.com/2013/03/08/do-you-know-what-a-reverse-outline-is/
- This is a short article on why and how you might do a reverse outline. A reverse outline is helpful in later phases of your writing. Test whether your ideas are structured logically!
5. Department of Communication. (2023). Structuring the Speech. University of Pittsburgh. https://www.comm.pitt.edu/structuring-speech
- This source explains how to organize a speech. What similarities do you notice between organizing a speech and organizing an essay? Could you apply the same structure for a one-minute elevator pitch?


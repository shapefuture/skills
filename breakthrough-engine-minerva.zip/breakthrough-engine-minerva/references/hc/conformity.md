# #conformity — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/conformity/](https://my.minerva.edu/academics/hc-resources/hc-handbook/conformity/)
> **Foundational Concept** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Working with others
> Taught in: Complex Systems | Semester One · Unit: Individuals in Society
> Big Question: How do we change society?

## Definition

**#conformity** — Identify and analyze social norms, their features, origins and development; evaluate the appropriateness of conformity and contrarianism and apply strategies of social change when applicable.

> **Pitch:** Find a balance between going with the flow (for harmony) and going against the current (for progress).

As individuals, humans have been described as having a “herd instinct,” leading each of us to want to do what others are doing or what we think is expected of us. Human societies tend to develop norms - broad patterns of behaviors that operate as taken-for-granted rules for behaviors, the violation of which is frowned upon and often punished by social means (such as ostracism or naming and shaming). Social norms play an important role in a functioning society, though there will be cultural variation between societies. Though social norms are human creation, existing in the minds of people as perception of prevalent or appropriate behavior, they are persistent and self-reinforcing as individual deviations are seen as violations to be reproached or exceptions that prove the rule. And yet, social norms are regularly challenged at the margins, and they evolve, change, and are overthrown over time. Norm entrepreneurs are constantly organizing to make their convictions accepted as taken-for-granted default behaviors and they apply a variety of long-term strategies that are often called “theories of change.” Social change requires organizing because individuals can’t unilaterally change norms. However, as individuals, we should identify and be aware of norms and make choices about the extent to which we follow them. Conformity to the behavior of others or to social norms has benefits and is sometimes appropriate but it could also undermine creativity and effective problem-solving. Much research indicates that a “contrarian” perspective (going against the herd) can be an effective method for identifying new solutions and achieving goals. Yet contrarianism can sometimes be disruptive to the point of undermining progress. Learning to identify situations that invite conformity and determining when a contrarian approach is appropriate can help balance the impulse to “go along to get along.”

## Worked example

Arriving at San Francisco for your first year at Minerva, you’re excited for the res hall kitchen as an avid cook that spent the last year of high school perfecting vegan recipes in preparation for life as an adulting college student. During the first few weeks, you diligently plan your meals, shop for groceries, and budget time to cook while also keeping up with all your school duties. However, to your disappointment, you find that cooking in the res hall kitchen has been taking twice as long as it did cooking at home, as you always have to start by cleaning all the dishes and cooking supplies you intend to use. Worse, as the weeks go by, it becomes more frequent that cooking supplies are lost, your groceries are opened or used by other students, and you find yourself less and less excited to cook and more inclined to buy expensive SF food. Talking to an upperclass student, you hear stories about similar experiences in years past and learn that there is a whole mythology of the res hall kitchen messiness and dirtiness. “It’s just the way it is,” the upperclass student tells you, “there’s no point in fighting it.” You realize that just like your friend, you’ve come to take the kitchen messiness for granted, as an unchangeable reality. Posting a quick survey at your class’s chat group quickly shows that most students would have loved it if the kitchen was cleaner and follow up by saying that “I don’t clean after myself because that’s what everyone else does.” Realizing that the problem is in the perceived ‘appropriate’ behavior in the context of your class’s social community, you gather a few friends from the cooking student initiative group and together you’re organizing a campaign to encourage people to clean after themselves. You’ve made a catchy video to share on social media, put up signs around the kitchen, and started sharing props to specific people that you’ve ‘caught’ cleaning after themselves. After two weeks of intensive effort, you see a significant improvement in the way the kitchen looks regularly and even note that people start asking why are you making such a big deal out of it given that the kitchen is pretty clean. You smile knowingly, noticing to yourself that they have started to take for granted the new norm you were pushing for.

> **Footnote:** A situation was analyzed to reveal that it was driven by a social norm, as people were behaving in a way they didn’t prefer because they took for granted that this is the ‘way things are around here.’ A strategy for change was articulated, relying on organizing and presenting an alternative norm. Having won over enough of the society’s members, the norm visibly changed and the new norm began taking hold as a ‘taken for granted’ default.

## Is it this HC?

Is #conformity the right HC? If the answer to the following questions is yes, #conformity could be useful:

- Are you analyzing how people conform to some examined social norms?

- Are you evaluating whether social norms are appropriate or should be resisted? 

- Are you considering practical strategies that challenge existing norms?

- Are you assessing the benefits or risks of contrarian/conforming action?

- Are you defending conformity as an appropriate response to social pressures?

Depending on the work product, there might be other HCs to consider.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#biasidentification](biasidentification.md) | Identifies biases that hinder rational thinking. Herd instinct is a bias that involves believing what everyone believes without good reason. This can be relevant in both informational and normative conformity. |
| [#evidencebased](evidencebased.md) | Presents appropriate evidence to support a claim. When analyzing social norms, one should carefully examine the evidence that shows the existence of those norms. |
| [#professionalism](professionalism.md) | Intentionally conforms to professional standards appropriate to the context. Professionalism can also be applied to cases where you consciously break context-based norms when carefully justified. |
| [#emotionaliq](emotionaliq.md) | Deals with recognizing, understanding, using, and managing emotions. Being “emotionally intelligent” is essential for contrarianism, which involves being sensitive and responsive to existing norms and able to express contrarianism constructively without causing a strong counter-reaction. |
| [#ethicalcourage](ethicalcourage.md) | Identifies the costs of ethical decisions and proposes ways to overcome them. Contrarianism can be ethically courageous when social norms are problematic. Similarly, conforming to social norms can be hard but morally right. |
| [#powerdynamics](powerdynamics.md) | Examines sources of power. Social norms can also be seen (or framed) as exercises of power by a dominant group. With this, analyzing the source of conformity can involve an application of #powerdynamics, while interpreting the social dynamics or dimensions of the conformity involves applying #conformity. |
| [#emergentproperties](emergentproperties.md), [#systemdynamics](systemdynamics.md), [#levelsofanalysis](levelsofanalysis.md) | Views social norms as system properties, analyzed at various levels, or analyzes changing norms as system dynamics. Conformity itself can be seen as an emergent property arising from various factors. |
| [#context](context.md), [#audience](audience.md), [#persuasion](persuasion.md) | Considers how people will respond to the breaking or adhering of norms. #context is especially important to understand social norms' full scope, origins, and stakes; #audience and #persuasion are crucial for adopting effective strategies that shift norms in a group or society for lasting social change! |

## Self-study Q&A (4 questions)

**Q1. What is an effective contrarian's key character trait/ability (related to another HC)?**

Emotional Intelligence (#emotionaliq). Contrarians must bring their counterpoints with a delicate sensitivity; otherwise, they might disturb a group's harmony too much. Emotional intelligence is the airbag that reduces the impact of contrarianism.

Another related HC is #audience – the ability to tailor a contrarian message and social criticism to a group.

**Q2. What is a crucial feature of a team that functions well with effective contrarianism?**

Having shared goals. If team members are set on coming up with the best solution, then critical feedback on iterations from a contrarian is welcome. However, contrarianism can lead to delays, arguments, and lower productivity when team members have different goals.

**Q3. What is the difference between informational and normative conformity?**

Informational conformity involves accepting facts that people around you accept. For example, that gravity exists. This is relevant in daily life to function with the same understanding of the world and in science, where shared models of reality are crucial for discourse.

Normative conformity involves conforming in action to what people around you think is good or normal. For example, when it is someone’s birthday, you wish them a happy birthday. But also, when you share a meal with others, you will probably ensure that everybody gets the same amount of food on their plates.

**Q4. How does conformity potentially play a positive role in human societies/interactions?**

It allows for easy transmission of skills, behaviors, and knowledge without needing a deeper understanding of the skills. In this way, society can move forward, even if only some members understand why they do what they do. We call this cumulative cultural transmission. See the first resource in the Key Resources section for more information.

## Guided reflection (proficiency checklist)

1. Have you identified the factors/conditions/interactions that lead to conformity?
2. Have you defined what norm or information people are conforming to?
3. Have you backed up your interpretations and analyses of social norms with evidence?
4. Have you compared whether conformity or contrarianism is a desired option?
5. Have you justified conformist or contrarian approaches in response to a particular problem?
6. If you suggest contrarianism, have you addressed possible adverse effects of that contrarianism with strategies/structures for effective contrarianism?

## Common pitfalls

1. Not explaining the mechanisms that cause conformity.
2. Relying on assumptions about social norms without carefully integrating evidence.
3. Arguing for contrarianism without examining what the requirements for effective contrarians are.
4. Overlooking why a particular behavior is a type of conformity and not something else.
5. Describing superficially the way humans conform without going into depth about the factors that affect how (much) we conform.

## Applying the HC at Minerva

1. Scientific theories or hypotheses: Science is an ever-changing landscape of ideas, paradigms, and sets of accepted facts. Scientific consensus does not simply represent a point in the progress of “objective knowledge.” Since people engage in scientific research, societal conditions, culture, and scientists' worldviews can all influence how it is done. Building on existing scientific paradigms (conforming) ensures the validity of scientific theories, but challenging them pushes science forward. Check the alternative science checklist in the Key Resources section for guidance on how existing scientific norms are effectively challenged!
2. Social Sciences: Social norms are under study in many areas of social sciences. We could examine conformity through a psychological lens, focusing on what external conditions cause conformity in individuals, the evolutionary explanation for conformity, how exactly our cognitive psychology contributes to conformity, and so on. We could also observe conformity’s effects and causes in sociological, political, cultural, and historical observations. Consider the conditions around conformity or contrarianism that led to the outcome in a given context. Questions about conformity you might encounter are: What role does conformity play in nation-building, political factions, and the changing ideas of politics? How do conformity and contrarianism differ across cultures and contexts? How can a historical event prompt social norms to change based on the changing conditions for conformity/contrarianism?
3. Business: Conformity is an important aspect of the human psyche; understanding it can be of value when thinking about marketing, for example. Additionally, conformity might be a relevant concept within a commercial organization, thinking about the social norms of a company, for example.

## Applying the HC outside Minerva

1. In consumption/marketing: Companies want you to conform to trends or norms about what to consume and how. For example, many influencers will promote skincare products, more commonly used now than 20 years ago. It might help you as a consumer to understand that we tend to buy things that others are consuming, but that doesn’t give those products inherent value. Similarly, understanding trends is something people do to fit in better.
2. Internalized social norms: In many ways, we are each a product of the social environment we grew up in. Our brain is meant to accumulate information from that environment and internalize the norms we observe around us. Understanding where you come from and what norms you were exposed to as a kid will help you understand how to have agency over the norms you want to follow and understand how your internalized norms might conflict with new environments that you encounter throughout your Minerva journey, when exploring different social and professional circles, or when deciding what norms you would like to set for others.

- For example, you can imagine internalized social norms having an impact in corporate settings. A company full of employees who are inclined to agree with prevailing opinions rather than propose new ideas will tend to result in a stagnation in innovation. Applying this HC is helpful in such situations because it could target the company’s culture instead of addressing workers one by one resulting in company-wide changes that will incentivize individuals to be more creative.

## Key resources

1. Legare, C. H. (2017). Cumulative cultural learning: development and diversity. Proceedings of the National Academy of Sciences of the United States of America, 114(30), 7877–7883. https://course-resources.minerva.edu/uploaded_files/mke/00219841-3245/cumulative-cultural-learning--development-and-diversity.pdf
- This paper describes how #conformity and contrarianism is an essential factor in how cultures are reinforced or changed over time. It is a foundational resource for those in psychology, sociology, anthropology, history, or even the arts. The linked resource has highlights from your Complex Systems class, but the whole reading is useful! Terms to look out for are 'Cumulative culture,' 'social learning,' and 'overimitation.'
2. Jhangiani, Dr. Rajiv, and Dr. Hammond Tarry. ‘6.3 Person, Gender, and Cultural Differences in Conformity’, 26 January 2022. https://opentextbc.ca/socialpsychology/chapter/person-gender-and-cultural-differences-in-conformity/
- The expectations and norms of society aren’t completely universal and should account for #differences. This resource discusses gender and culture as factors that shape the amount and types of expected conformity, influencing how you might respond with contrarianism. The bottom of the resource has Key takeaways and practice questions that are useful. — [link](https://my.minerva.edu/academics/hc-resources/hc-handbook/differences/)
3. MacBride, Elizabeth. ‘Do You Have a Contrarian on Your Team?’ Stanford Graduate School of Business, 13 November 2015. https://www.gsb.stanford.edu/insights/do-you-have-contrarian-your-team
- If you are looking for a shorter and less nuanced resource, check this out. It explains why and when having a contrarian can be helpful in a team.
4. Wingfield, A. H. (October 14, 2015). Being Black—but Not Too Black—in the Workplace. The Atlantic. https://www.theatlantic.com/business/archive/2015/10/being-black-work/409990/
- This resource is accessible with an Atlantic account. Similarly to the gender/culture reading above, it discusses how conformity operates and affects different people differently, in this case, in terms of being a (racial) minority.
5. Carroll, S. (2007, June 19). The alternative-science respectability checklist [Web blog post]. http://www.preposterousuniverse.com/blog/2007/06/19/the-alternative-science-respectability-checklist/
- When applying #conformity in a scientific context, this resource will help you. It outlines a path to successful contrarianism specific to science. Still, you might find it helpful to understand how scientific fields work with norms and respond to changing understandings in general. It is important to be aware of the paradigms dictating scientific practices in different fields.


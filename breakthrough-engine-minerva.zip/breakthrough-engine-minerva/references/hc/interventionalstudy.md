# #interventionalstudy — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/interventionalstudy/](https://my.minerva.edu/academics/hc-resources/hc-handbook/interventionalstudy/)
> **Foundational Concept** · Cornerstone course: Empirical Analyses · Competency: Thinking Creatively → Applying research methods
> Taught in: Empirical Analysis | Semester One · Unit: Scientific Method
> Big Question: How do we mitigate human-caused climate change?

## Definition

**#interventionalstudy** — Design and interpret experimental studies.

> **Pitch:** If you really want to connect cause and effect, sometimes you just have to do the experiment.

A true experiment has one or more independent variables, which are manipulated or selected independently, and one or more dependent variables, which are measures of the effects of variations of the independent variable or variables. An experiment relies on assigning samples to a treatment condition (an intervention) and tries to minimize (or, ideally, eliminate) the influences of extraneous variables. To determine that the treatment causes the outcome, experimenters must control extraneous variables and other factors that may impact the outcome. In contrast to observational studies, experiments always involve interventions.

## Worked example

You are a researcher studying bacterial resistance to antibiotics, and your job is to find out the best way to administer antibiotics in order to prevent resistance to antibiotics. Your hypothesis is that administering three different antibiotics simultaneously is more effective than administering the same three antibiotics cyclically (one after the other), which in turn is more effective than administering only your strongest antibiotic. To address this hypothesis, you consider enlisting the help of hospitals and having doctors prescribe one of the three methods you are investigating to patients. You consider that there are two important issues with this experiment design: first, since you already have good indication that simultaneous antibiotic delivery is much better for preventing bacterial resistance, it would be unethical to deny people the best treatment. Second, it would be very hard to control relevant variables like type of bacteria, location of infection, method of antibiotic application, and others. Whereas you recognize that testing antibiotics on humans will have to be done eventually, for now you decide to run lab-based experiments on bacterial cultures, using three different antibiotics. You decide to have three intervention groups: one in which bacteria are attacked only with your strongest antibiotic during 30 days, one in which bacteria are attacked with three antibiotics for 10 days each, and one in which bacteria are attacked throughout the 30 days with all 3 antibiotics simultaneously. To account for the possibility that the injection of liquid into a bacterial culture has an effect on bacterial survival, you add a “placebo” group to the experiment, wherein a harmless liquid will be applied to bacteria. Furthermore, you add a “natural history” group of bacteria who will suffer no treatment to serve as a comparison, a baseline against the placebo and intervention groups. Finally, you are sure to control for variables like availability of sustenance, incidence of sunlight, temperature, moisture, and chemicals the bacteria are exposed to. You keep your four bacteria groups inside a sterilized lab, in petri dishes, to control for these variables. Because of the tightly controlled design of your experiment, you recognize that there may be some issues with generalizability of your results. You also consider that bacteria inhabiting living beings may react very differently to treatment, and so you suggest that, for a future experiment, you should try to kill bacteria infecting mice rather than “infecting” petri dishes. However, you are confident that the experiment can potentially reveal causal relationships.

> **Footnote:** An interventional study design is proposed in order to test the suggested hypothesis. Alternative study designs are discussed, and arguments favoring the chosen experiment are presented. The study design is described, including what the treatment groups will be and what treatments they will receive. Controls are also mentioned. Finally, the constraints of this study design are mentioned and a further study is suggested.

## Is it this HC?

Is #interventionalstudy the right HC? If the answer to the following questions is yes, #interventionalstudy could be useful:
- Do you need to design a study that involves some kind of intervention (treatment) to then observe outcomes? 

- Are you critiquing someone else’s interventional study design?
Depending on the work product, there might be other HCs to consider.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#observationalstudy](observationalstudy.md) | designs or critiques a research study that does not involve researcher intervention. |
| [#casestudy](casestudy.md) | focuses on a single sample (or few) from the population. Case studies can use an interventional design approach. |
| [#hypothesisdevelopment](hypothesisdevelopment.md) | generates a testable hypothesis that explains the reasons or causal mechanisms for underlying patterns or observations. Hypothesis development is a step prior to designing a study. Depending on the specific research question, one might then design an interventional study. |
| [#sampling](sampling.md) | provides detailed explanation of a chosen sampling method and justifies the choice. Note that sampling is a key part of study design and #interventionalstudy may be more appropriate if you are referring to the holistic study design. |
| [#comparisongroups](comparisongroups.md) | provides more elaborate justification for the chosen comparison groups. Simply listing the control and alternative comparison groups as part of a study design falls under #interventionalstudy. |
| [#confidenceintervals](confidenceintervals.md), [#correlation](correlation.md), [#descriptivestats](descriptivestats.md), [#distributions](distributions.md), [#regression](regression.md), [#significance](significance.md), [#variables](variables.md) | Conducts statistical analyses on quantitative survey data. These HCs are usually used after data collection. |

## Self-study Q&A (3 questions)

**Q1. What is the difference between quasi-experimental and RCT studies and how can you decide which one to use?**

Quasi-experiments and RCT (Randomized Controlled Trials) are both interventional studies. However, unlike RCT, the treatment assignment is not random. While RCT is often the best at evaluating the outcome of an intervention, randomization to treatment is sometimes not possible or ethical. For example, when exploring the effect of hand-sanitizer usage in a hospital, it is not practical or reasonable to ask some nurses to not use hand sanitizer. Thus, a pre-post test design might be used instead. Note that there are multiple types of quasi-experiments that you can learn about from the quasi-experiment reading linked in the Key Resources.

**Q2. What are some measures you can take to minimize the effect of bias and confounding variables when designing an interventional study?**

You can mitigate bias (e.g., confirmation bias) associated with the researcher and participants by using double-blinding (all unaware of the treatment assignment). In the case of non-human subjects (e.g., rocks), you can still mitigate confirmation bias by blinding the researcher. Confounding variables can be kept the same for all groups (e.g., by using the exact same type of soil on study plots). You can also account for the confounding variables using matching, which involves pairing participants with similar characteristics from the treatment and control groups and comparing the effects of the treatment between similar participants.

**Q3. How can you ensure that your study design tests the hypothesis?**

Before you start designing a study, you need to make sure that your hypothesis is testable (review #testibility HC entry for more information) and generate multiple predictions among which you need to choose one (or even better, two) that would support/refute the hypothesis most convincingly. Next, you need to select variables that would allow you to observe the predictions. However, the research design process is not always linear and you may need to go back and forth between the design and the hypothesis to adjust it based on feasibility.

## Guided reflection (proficiency checklist)

1. Have you provided an in-depth explanation of why you chose an interventional study?
2. Have you provided a detailed description of the study and backed up the design choices with evidence (e.g., methods used in similar studies)?
3. Have you accounted for (or at least mentioned) extraneous variables and cognitive biases?
4. Have you evaluated the study design by outlining its strengths and limitations?

## Common pitfalls

1. The study type is inaccurately categorized.
2. The description of the study is superficial.
3. The study design would not effectively test the hypothesis.
4. The study design choices are not justified or explained clearly.

## Applying the HC at Minerva

1. You will use this HC in NS assignments where you are asked to write a research proposal or a critique of a primary paper.
2. You can also use #interventionalstudy in business assignments to test different marketing strategies and products on the consumers.

## Applying the HC outside Minerva

1. You can use this HC to critique research papers. For example, let’s say you want to evaluate the effectiveness of a fiscal policy proposed by the local government.  You found a research paper about the implementation of the policy as a pilot program, whereby two neighborhoods were compared. One neighborhood received the policy implementation, while the other served as a control group. The aim was to evaluate the impact and outcomes of the policy within the context of the local community. Your background in study design can help you assess whether the design choices were well justified (e.g., are the neighborhoods selected sufficiently similar?).
2. You have observed that your toddler's attitude towards chicken noodle soup varies, as there are days when they enjoy eating it, while on other occasions, they reject it. You suspected that it is because of a spice you are using in the recipe from time to time. In order to test your hypothesis, you plan to conduct an interventional study where you will control for all ingredients and add the spice as a treatment in your next batch of chicken noodle soup. Then you will observe the toddler’s reaction.

## Key resources

1. Lesh, M. (2015). Observational vs. experimental study. [Video]. YouTube. https://www.youtube.com/watch?v=71CZQZSrOy0
- This short video describes the key differences between observational and interventional (experimental) studies.
2. Lacey, M. (1997). Experimental design. Statistics 101-103: Summaries of topics. Yale University. http://www.stat.yale.edu/Courses/1997-98/101/expdes.htm
- This summary provides a succinct overview of experimental design and introduces the major aspects of design that should be considered when developing or critiquing an experiment.
3. Sibbald, B., & Roland, M. (1998). Understanding controlled trials: Why are randomised controlled trials important? British Medical Journal, 316(7126), 201. http://www.ncbi.nlm.nih.gov/pmc/articles/PMC2665449/pdf/9468688.pdf
- This brief, one-page reading provides an overview of the key elements of randomized controlled trials (RCTs), their appropriate use, and primary constraints.
4. Harris, A. D., Bradham, D. D., Baumgarten, M., Zuckerman, I. H., Fink, J. C., & Perencevich, E. N. (2004). The use and interpretation of quasi-experimental studies in infectious diseases. Clinical Infectious Diseases, 38(11), 1586-1591. https://academic.oup.com/cid/article/38/11/1586/285372
- This review provides an overview of quasi-experimental designs in clinical research.
5. Kosslyn, S. M., and Rosenberg, R. S. (2001). QALMRI instructions. Adapted from Psychology: The Brain, The Person, The World. Boston: Allyn & Bacon. https://www.cnlm.uci.edu/files/2015/01/QALMRI.pdf
- This reading suggests an approach to primary peer-reviewed literature - QALMRI.


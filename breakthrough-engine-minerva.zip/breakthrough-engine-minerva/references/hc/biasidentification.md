# #biasidentification — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/biasidentification/](https://my.minerva.edu/academics/hc-resources/hc-handbook/biasidentification/)
> **Foundational Concept** · Cornerstone course: Empirical Analyses · Competency: Thinking Critically → Analyzing decisions
> Taught in: Empirical Analyses | Semester Two · Unit: Complex People
> Big Question: What does it mean to behave rationally?

## Definition

**#biasidentification** — Identify and explain how cognitive biases result from psychological mechanisms or use of heuristics.

> **Pitch:** An awareness campaign for human cognitive tendencies.

Our understanding of the world depends on what we notice, focus on, and remember. Cognitive biases and emotional states can affect what we notice (or do not notice) and therefore influence our memories and decision making in various ways. For example, people have a tendency to filter out potentially useful information that does not correspond to their preconceived notions. In particular, we tend to seek out information that confirms or is consistent with our prior beliefs, disregard information that is contrary to them, and interpret equivocal information as supporting our beliefs. Heuristics—simple, efficient rules that can make problem solving and decision making faster and easier—can sometimes lead to biases and errors in judgment or reasoning and must be used with caution.

## Worked example

You have a relative who is very nervous about a doctor’s appointment, and asks you to go with him. Afterwards, he remembers what the doctor said as much more severe than you do. He was expecting to hear bad news, and thus kept thinking about everything that was even slightly negative, which distorted his memory. Furthermore, you noticed that your relative, instead of listening to the doctor, stared intently at a huge, gleaming syringe and needle that was placed over the counter and was thus subject to a top-down attention bias due to their emotional state. You realise that this attention bias made your relative filter out important, positive information and at the same time worsened their mood. You, on the other hand, took notes—and thus can correct his memory.

> **Footnote:** A memory bias, working synergistically with a top-down attention bias, resulting from the emotional distress prior to the doctor visit is identified and explained as the cause of the friend's overly-negative memory of the doctor's remarks.

## Is it this HC?

Is #biasidentification the right HC? If the answer to the following questions is yes, #biasidentification could be useful:

- Are you identifying biases to explain a psychological behavior/decision?

- Are you identifying the relationship between certain cognitive biases and heuristics?

- Are you reflecting on your own actions from the perspective of cognitive biases?

Depending on the focus of the work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#heuristics](heuristics.md) | Identifies uses or limitations of heuristics, possibly involving how a specific heuristic might be prone to bias. |
| [#biasmitigation](biasmitigation.md) | Explains methods to mitigate cognitive biases, after identifying these biases. |
| [#shapingbehavior](shapingbehavior.md) | Focuses on how incentives and disincentives, rewards and punishments, and/or choice architecture can be used to motivate a psychological behavior, possibly relying on common cognitive biases. |
| [#psychologicalexplanation](psychologicalexplanation.md) | Focuses on how psychological theories can explain a certain behavior or bias. |
| [#distributions](distributions.md) or [#sampling](sampling.md) | Focuses on sampling biases that result in a sample distribution that may not be representative of the population distribution (e.g., due to low sample size or lack of uniformity), but often do not stem from cognitive biases. |
| [#utility](utility.md) | Uses the concept of utility to represent preferences or analyze decisions, possibly including common cognitive biases that impact one’s utility function or expected utility (e.g., loss-aversion, probability distortion). |
| [#fallacies](fallacies.md) | Focuses on examining flawed reasoning in arguments, including issues with the argument’s content or structure, possibly influenced by cognitive biases. |
| [#interpretivelens](interpretivelens.md) | Focuses on how past experiences, expectations, or purposes affect our perspectives; in some cases, these prior experiences can lead individuals to develop cognitive biases which could then be evaluated using #biasidentification However, applying #interpretivelens to identify factors shaping one’s viewpoints does not always imply an associated cognitive bias. |

## Self-study Q&A (7 questions)

**Q1. What is a cognitive bias?**

A cognitive bias is a systematic error in psychological behavior. Usually, such biases lead one to make judgments that deviate from what would be considered desirable from the perspective of accepted norms, or correct in formal logic.

**Q2. What are the general types of cognitive biases?**

- Attentional bias

- Emotional bias

- Memory bias

- Confirmation bias

**Q3. What is the difference between bottom-up and top-down attentional biases?**

The bottom-up approach causes one to only focus on things that require immediate attention. For example, when a baseball is flying in your direction, you will unconsciously focus on the baseball, and the reflex action (behavioral response) is to block or dodge the baseball. 

As for the top-down approach, the perceiver moderates the power of stimuli to capture attention. For example, if your name is “Javier”, you will notice when people say “Javier” because it has meaning to you, whereas for other people it would likely blend into the background noise. .

**Q4. What is the difference between integral and incidental emotions?**

Integral emotions arise due to the judgment or choice at hand. For example, the fear of exams may induce anxiety in a student, leading them to think that they are underprepared for an exam. As a result, they reduce their confidence and consequently examination performance, even when they may be sufficiently prepared.
Incidental emotions arise due to emotions at the time of decision making that are irrelevant to the decision task at hand. Usually, such emotions come from other events before the decision event. For example, one may decide to buy more “comfort” food due to the anxiety of an upcoming examination. The examination is not related to buying food at all, but may influence the decision maker’s feelings at the time of buying food.

**Q5. When do memory biases occur?**

Memory biases occur when we interact with our memories, specifically during memory encoding and retrieval. The following infographic (Stein, 2021) explains how biases can influence one’s memory. It is important to note that simply forgetting is not a memory bias.

**Q6. Does this HC apply to all biases?**

#biasidentification focuses on identifying cognitive biases that influence decision making. Many non-cognitive biases exist that are not within the purview of #biasidentification. For example, a sampling bias related to convenience sampling that is unrelated to any cognitive bias is not an application of #biasidentification, but #sampling. Refer to “Is it this HC?” section for details.

**Q7. How to know when to apply #biasidentification, #biasmitigation, or #interpretivelens?**

These HCs are often interconnected. However, they serve different purposes. With #biasidentification, a specific instance of bias should be recognized, described, and explained, focusing on the cognitive blindness that bias caused and the impact of that blindness. With #biasmitigation, a particular bias should have already been identified, and a technique to mitigate the bias should be explained in detail and backed up with evidence that supports its effectiveness. With #interpretivelens, a bias may or may not be identified, but an instance of a certain interpretation will be recognized and connected back to a previous experience, expectation, or purpose, and the connection will be explained. Notice that it’s possible for cognitive biases (that can be evaluated with the bias HCs) to stem from one’s prior personal experiences or expectations. However, applying #interpretivelens to evaluate how one's past shapes their perspectives does not always imply an associated cognitive bias.

## Guided reflection (proficiency checklist)

1. Have you identified the relevant cognitive biases?
2. Have you identified potential interactions between biases, or between biases and heuristics?
3. Have you explained how biases lead to a specific decision/behavior?

## Common pitfalls

1. The application miscategorizes a type of bias or identifies an irrelevant bias for the context.
2. The application identifies a relevant bias but does not explain how that bias leads to a specific psychological behavior.
3. The application identifies multiple biases for a certain context but does not identify the interactions between these biases.
4. The application identifies a bias that is not a cognitive bias (e.g., sampling bias).

## Applying the HC at Minerva

1. In Integrated Learning courses (IL), this HC is classified under the ILOs “Interpersonal Engagement” and “Intercultural Competency.” Cognitive biases shape our everyday behaviors, which may or may not be perceived as rude as we engage with different people and cultures.
2. Within computational sciences, we see how decision-making algorithms can be powerful tools to both mitigate bias and promote bias. On the one hand, using an algorithm can reduce bias by providing an objective and systematic way to make decisions (e.g., using a machine learning algorithm to build a classification model to help with hiring decisions). On the other hand, algorithms like this can perpetuate cognitive bias, especially if the source training data is problematic. For example, this article discusses the controversy of racial biases in ChatGPT. Such biases reduce the model accuracy, thus it’s important to identify them.
3. In EA, you consider the ways in which cognitive biases affect (both positively and negatively) the efficacy of your study habits.

## Applying the HC outside Minerva

1. Recognizing cognitive biases is important in fields where critical decisions are made. The Innocence Project focuses on many cases in which accused persons have been  wrongly imprisoned due to cognitive biases at multiple stages from eyewitnesses to the police and forensic analysts.
2. For neurodivergent communities, this HC may be relevant in explaining higher-level behaviors. For example, the role of attentional bias in people with attention deficit hyperactivity disorder (ADHD), or the role of emotional bias in people with major depression disorder. Studying cognitive biases may explain how such neurodivergent people interact in societies. See Ruhe et al. (2019) for an academic study on how people with depression process stimuli with emotional biases.
3. The ability to recognize how incidental emotions might affect our decisions and behaviors is a critical “life skill” that can lead to healthier and deeper relationships both personally and professionally.

## Key resources

1. Behavioral Science Solutions. (n.d.). Behavioral Science Concepts. https://www.behavioraleconomics.com/resources/mini-encyclopedia-of-be/
- This webpage contains a list of short, introductory articles on heuristics and biases. Use Cmd+F to search for a specific term you want to learn more about.
2. Bennett, B. (2014, March 29). Confirmation bias [Video]. YouTube. https://www.youtube.com/watch?v=B_YkdMwEO5U
- This 5-minute video summarizes confirmation bias with some real-world examples.
3. Innocence Project. (2018, November 19). Human Factors in Wrongful Convictions: Memory Malleability [Video]. YouTube. https://www.youtube.com/watch?v=jCl66OWjXMM
- This 5-minute video introduces a research on memory biases and its consequences on eyewitness evidence.
4. Le Cunff, A. (n.d). Memory bias: how selective recall can impact your memories. Ness Labs. https://nesslabs.com/memory-bias
- This short article further breaks down the types of memory bias, while also discussing the positive aspects of memory bias.
5. Lerner, J. S., Li, Y., Valdesolo, P., & Kassam, K. S. (2015). Emotion and Decision Making. Annual Review of Psychology, 66(1), 799–823. http://www.annualreviews.org/eprint/vVKIPZU5r9dTCzbgdD3M/full/10.1146/annurev-psych-010213-115043
- This article discusses incidental and integral emotions, and the Appraisal Tendency Framework. The introduction and Themes 1-3 are sufficient for a deep understanding of emotional bias. Note that the term “valence” simply means categorizing emotions into positive or negative. The main idea of the paper is that two emotions of the same valence (e.g., fear and anger) have different behavioral effects.
6. Yue, C. (n.d.). Divided attention, selective attention, inattentional blindness, and change blindness [Video]. Khan Academy. https://www.khanacademy.org/science/health-and-medicine/executive-systems-of-the-brain/attention-language-lesson/v/divided-selective-attention-inattentional-change-blindness
- This short video introduces some key concepts of attentional bias.
7. Veritasium. (2025, November 12). Why people are so confident when they're wrong [Video]. YouTube. https://youtu.be/9M_QK4stCJU?si=J9UTB2y8wdbjuczG
- This video explains the overconfidence bias, the gap between how sure we feel and how often we are actually right.


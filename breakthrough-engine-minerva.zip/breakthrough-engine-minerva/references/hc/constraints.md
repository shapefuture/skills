# #constraints — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/constraints/](https://my.minerva.edu/academics/hc-resources/hc-handbook/constraints/)
> **Foundational Concept** · Cornerstone course: Empirical Analyses · Competency: Thinking Creatively → Solving problems
> Taught in: Empirical Analyses | Semester One · Unit: Problem Solving
> Big Question: How can we feed the world?

## Definition

**#constraints** — Identify and apply constraint satisfaction as a way to solve problems.

> **Pitch:** While constraints limit solutions, they can be catalysts for the solution-finding process.

A problem exists when one or more obstacles to a goal must be addressed. Obstacles often cannot be overcome easily, largely because there are constraints on what actions are possible or realistic. Constraints are requirements for the solution; they do not determine it but place boundaries on what is possible. Thus, part of solving a problem is identifying the constraints on what can be done. If the constraints are well-defined, problems can often be solved by devising ways to satisfy all of the constraints simultaneously. This approach to problem solving is known as “constraint satisfaction.”

## Worked example

You are moving into a new house and need to decide where to put the furniture in your bedroom. You have an old sofa that is missing a rear leg and sits on a telephone book, so you don’t want to put it in a location where it can be seen from behind. You realize, however, there is no place to put the sofa so that it is not seen from behind, and so you decide to treat this as an obstacle rather than a constraint and get the sofa fixed. You budget so that you spend less money on groceries this week so you have enough money to overcome the obstacle: in other words, fix the sofa. You also have an old bed, with a headboard that must lean against the wall. Fixing the headboard would cost way more than fixing the sofa, so it is not feasible, and you decide to keep it as a constraint to be satisfied. Additionally, you have two end tables, which must be set to either side of the headboard. And a large chair and reading lamp, which must be near each other. Once you pick a wall for the headboard (one of the constraints), the positions of the other pieces of furniture may be determined. There is only one other place where the wall can accommodate the headboard, and once it and the end tables are set up, there is only one other place large enough for the chair and lamp. Because you fixed the sofa, you can put it anywhere where space is left. The mere act of satisfying all of the constraints and overcoming obstacles simultaneously almost dictates the solution to the problem.

> **Footnote:** Upon facing numerous alternative choices to place furniture, the constraints that must be satisfied by a solution are identified and fulfilled sequentially to guide the furniture arrangement; in this case, satisfying all the constraints directly solved the problem.

## Is it this HC?

Is #constraints the right HC? If the answer to the following questions is yes, #constraints could be useful:
- Are you distinguishing between obstacles and constraints?

- Are you justifying parts of the main problem as obstacles/constraints?

- Are you applying constraint satisfaction as a means to identify solutions?

Depending on the focus of the work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#rightproblem](rightproblem.md) | Analyzes key obstacles (solvable), instead of constraints (not solvable). |
| [#breakitdown](breakitdown.md) | Organizes a larger problem into tractable subproblems; these subproblems often can be considered obstacles. Whether a subproblem is tractable or not often considers #constraints. |
| [#optimization](optimization.md) | Defines and solves an optimization problem, which requires specifying the objective function, decision variables, and constraints, as well as evaluating techniques to solve the problem. |
| [#gapanalysis](gapanalysis.md) | Analyzes whether existing solutions and/or modifications to existing solutions will satisfy constraints. Identifies that existing solutions will not satisfy the constraints, thus motivating the need for a creative solution. |
| [#heuristics](heuristics.md) | Ideates solutions using constraint-related heuristics (e.g. setting a variable to zero). Uses means-ends analysis to identify subgoals, not constraints. |

## Self-study Q&A (3 questions)

**Q1. What is the difference between an obstacle and a constraint?**

A key obstacle is solvable. A constraint is usually unsolvable, thus setting boundaries on the solutions. You have to solve the obstacles to reach the goal state, but you don’t have to solve constraints; you satisfy constraints by modifying your solution. 

What is a constraint vs. an obstacle all depends on the problem framing! For example, quite often budget is considered a constraint on possible solutions. That said, if you are able to write grants for extra funding, perhaps budget could then be considered an obstacle. The most important thing is to assess what is “fixed” in the problem space (constraint) vs. what you can work to solve/overcome (obstacle).

**Q2. What exactly is constraint satisfaction?**

Constraint satisfaction is one of the many ways to generate solutions. Instead of using #analogies or #heuristics, you directly attempt to satisfy multiple constraints simultaneously. Usually, multiple constraints will restrict the number of possible solutions, thus simplifying the solution ideation process, often with a clear solution emerging.

**Q3. What is the relationship between #gapanalysis and #constraints?**

#gapanalysis focuses on existing solutions. By analyzing the “gaps” of current solutions in the context of whether or not they meet constraints, we can understand their shortcomings. The final solution should address any identified shortcomings while still satisfying constraints. A direct application of #constraints focuses on the boundaries of the final solution; it would not involve analyzing existing solutions individually. 

Both HCs are under “solution analysis” within the problem solving framework. Applying these HCs does not necessarily produce a perfect solution, but it will certainly move you toward a potential solution.

## Guided reflection (proficiency checklist)

1. Have you identified and explained relevant constraints and obstacles for the problem at hand?
2. Have you made a sufficient distinction between obstacles and constraints in your problem?
3. Have you justified why a particular constraint is not an obstacle instead?
4. Have you extended beyond the one or two obvious constraints (e.g. time) to find more nuanced constraints?
5. Have you explained how constraint satisfaction can be used to find solutions?
6. Are there multiple possible solutions after constraint satisfaction? If so, how would you select the final solution?

## Common pitfalls

1. The application mistakes an obstacle as a constraint, or vice-versa.
2. The application only identifies a single constraint.
3. The application misses a key constraint that should not have been missed.
4. The application attempts a solution without satisfying the identified constraints.
5. The application identifies a constraint accurately, but does not describe or justify it.
6. The application fails to support a constraint with some evidence (e.g., claiming there is a limited budget without rationale).
7. The application uses the word 'constraints' in the colloquial sense, neglecting what it encompasses as a problem-solving HC.

## Applying the HC at Minerva

1. You’re a junior with an NS major. When you’re selecting courses for the lottery, you may impose several constraints, such as:
- One course must be an NS course related to your concentration.

- You didn’t finish all NS core courses in the sophomore year, so one course needs to be an NS core course.

- For the third course, you want an elective, but you don’t want to take any business courses. You want a more introductory-level course, so you want a core course (eliminates all NS and BZ courses, and concentration courses from other colleges).

- You’re a morning person, and you cannot think clearly after 6:00 pm (eliminates all evening classes)

- You signed up for a yoga class on Fridays and want to avoid WF classes.

Out of all the possible combinations of courses offered in the semester, you reduced many options just by trying to satisfy the constraints above. This method greatly simplified the decision making process.
2. In physics, there are physical laws that constrain the relationship between dynamical quantities. Using these laws as constraints helps one to characterize the motion of an object or system. For example, for an oscillating pendulum under simple harmonic motion, the law of conservation of energy guarantees that the total mechanical energy (kinetic energy + potential energy) is constant at all times. This conservation law can be translated into a mathematical equation that serves as a constraint on the system, specifying the relationship between mass, speed, and position. Using this constraint allows one to fully evaluate the motion of the pendulum. For example, its speed at a given position can be determined. There are other conservation laws too, such as the conservation of momentum and the conservation of linear momentum. Being able to recognize scenarios in which these laws apply can be a powerful problem solving tool!

## Applying the HC outside Minerva

Flight search engines, such as Google Flights, Skiplagged, and Skyscanner, are built on the principles of constrained optimization. For example, if you’re flying from Taipei to Buenos Aires (which is usually challenging, here’s a video explaining why), you can input several filters, such as:
- The budget range

- The maximum number of transits

- Airlines offering a carbon offset option

- The minimum baggage allowance

- Duration of flight(s)

- Date(s) of departure

These filters act as constraints, thus reducing the number of possible routes to travel from these two cities. The options listed for you are all viable solutions that satisfy your constraints.

## Key resources

1. Maurya, A. (2015, December 29). How to achieve breakthrough by embracing your constraints. Love the Problem. https://medium.com/lean-stack/how-to-achieve-breakthrough-by-embracing-constraints-c6382eeab5e9/
- This short article provides a few real-world examples of leveraging constraints as an advantage to problem solving.
2. Spradlin, D. (2012). Are you solving the right problem? Harvard Business Review. https://hbr.org/2012/09/are-you-solving-the-right-problem
- This detailed article uses constraints as a guideline to well define a problem (#rightproblem) and a solution (#gapanalysis). Note that there is an annotated version of the article here: https://docs.google.com/document/d/1ug-lpbq3CF2RqKhlP1E9JjSi5kstrSD8jIjlQEfntQA/edit# — [1](https://my.minerva.edu/academics/hc-resources/hc-handbook/rightproblem/) [2](https://my.minerva.edu/academics/hc-resources/hc-handbook/gapanalysis/)


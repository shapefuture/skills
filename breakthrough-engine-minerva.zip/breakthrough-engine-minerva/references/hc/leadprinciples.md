# #leadprinciples — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/leadprinciples/](https://my.minerva.edu/academics/hc-resources/hc-handbook/leadprinciples/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Working with others
> Taught in: Complex Systems | Semester Two · Unit: Prudence and Effective Interaction
> Big Question: How should power be used and distributed?

## Definition

**#leadprinciples** — Apply principles of effective leadership.

> **Pitch:** Great leaders do not demand a following; they inspire it.

Leadership involves intentionally influencing a group’s behavior, identity, or beliefs–which means that leadership always entails the exercise of power. Leaders are primarily judged on whether they are effective in realizing a group’s overarching goal, which requires both flexibility in the face of fluid conditions and tenacity when opportunities appear. Leaders are thus often required or expected to set aside adherence to general rules and norms that apply to group members. At the same time, leaders are also judged on how well they articulate and embody their group’s identity and core values. If they disregard these, they risk undermining the group’s cohesion and their own credibility. Importantly, history teaches that almost all of a leader’s shortcomings will be forgiven if they realize their group’s objectives. A central challenge of leadership thus consists in actually achieving a group’s goals, however ambitious, without undermining the group’s identity or values. Applications of effective leadership address this challenge by providing descriptors for leadership approaches, standards for evaluating leadership effectiveness, and broad guidelines for building leadership approaches in complex conditions.

## Worked example

In history class, you are analyzing a fascist figure’s approach to leadership to see what can be learned from it. Your research shows that the leader was charismatic, a great orator, and had an excellent grasp of his followers’ motivations. He helped his followers to connect with core values like loyalty, dedication to a greater cause, and pride in their heritage. He gave them a sense of identity and purpose, which fueled their intrinsic motivation to work and to fight. He also used his position to ensure that people had decent food, housing, and employment. Later leaders would model agricultural and housing subsidy programs on his. And he supported the cultivation of intellectual and artistic expertise, so long as they did not oppose his vision of national greatness. Again, later education and arts programs used his as templates. Although effective for most of the population, his jingoistic tactics violated several of his followers’ core values, such as tolerance and compassion, and his heavy-handed repression of political alternatives infringed on his followers’ freedom. His aggressive political invective spurred neighboring countries to strengthen their militaries. The leader’s actions thus sparked conflicts, both internal and external, that eventuated in his fall from power. On the one hand, the leader held power for some time, using it to support many of his followers and advance some of their core values. On the other hand, his callous repression of minorities and political alternatives, coupled with his threats of reckless military action, together sparked implacable resistance, which led to his fall and the tarnishing of his country’s reputation.

> **Footnote:** Describes a leader’s overall approach to deploying power. Evaluates the effectiveness and integrity of the leader’s approach, with a particular eye to the core values that the leader’s approach either supports or undermines. Considers the relative freedom of the leader’s followers. Traces the impact of certain of the leader’s initiatives even after his fall from power, examines the effects of his approach at multiple geographic scales, and considers the significance of resistance as an indicator of the abuse of power.

## Is it this HC?

Is #leadprinciples the right HC? If the answer to the following questions is yes, #leadprinciples could be useful:

- Are you examining how an individual in a position of power interacts with a group? Or, are you examining a network of leadership interactions in an organization or group?

- Are you describing a leadership style, analyzing its effectiveness, or designing/refining it using concepts of effective leadership?

- Are you thinking about the influence of personality and behavior from both the leader and group?

- Are you justifying courses of action that you think a leader should take? 

Since #leadprinciples is especially dependent on other abilities captured by HCs, you will find a lot of overlap when thinking about it.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#powerdynamics](powerdynamics.md) | analyzes how power sources operate. In #leadprinciples applications, you should focus on how power achieves leadership goals. At the same time, #powerdynamics concerns itself mostly with the nuances and conditions from which power stems in the first place. |
| [#purpose](purpose.md) | aligning an organization’s core values, guiding principles, and specific actions. Insofar as this is a leader’s main goal, they might use their leadership qualities to help a group work towards its #purpose. |
| [#emotionaliq](emotionaliq.md), [#differences](differences.md), [#psychologicalexplanation](psychologicalexplanation.md), [#audience](audience.md) | analyzes the human (group) identity, differences, emotions, and reception of communication. These might be essential to remember when analyzing a leader's inner world or those they’re leading. Creating group unity while recognizing a group's different qualities is a mark of a good leader. |
| [#conformity](conformity.md) | analyzes features of conformity and contrarianism to social norms. A leader might conform or break with the social expectations and goals of a group and vice versa. Effective contrarianism, as well as effective conformity, can be part of good leadership. |
| [#ethicalconsiderations](ethicalconsiderations.md), [#ethicaljudgment](ethicaljudgment.md), [#ethicalcourage](ethicalcourage.md) | makes ethical decisions based on careful reasoning. You might want to examine the ethical values a leader recognizes (#ethicalconsiderations), promotes, or disregards (#ethicaljudgment)! Additionally, they can incentivize ethical behavior by addressing barriers to ethical behavior for the group (#ethicalcourage). |
| [#responsibility](responsibility.md) | works responsibly to achieve goals. Great leaders inspire their followers to act, especially in professional settings. You might apply #responsibility if you analyze how a good leader can motivate, create commitment, and hold themselves and others accountable. |
| [#networks](networks.md), [#levelsofanalysis](levelsofanalysis.md), (and potentially other Complex Systems HCs) | uses complex systems theories to analyze and predict interactions. Leaders operate in complex systems of actors. Analyzing their position within a network or structure of this system might give you insight into how leadership will be effective. |

## Self-study Q&A (5 questions)

**Q1. We can place someone’s leadership style on some continuums. Fill in the blanks:

Formal vs. ___ (popularity/soft power)

Transactional vs. ___ (inspirational)

Bureaucratic vs. ___ (using social qualities)

Position vs. ___ (coming from knowledge/ability)

Expressive vs. ___ (setting goals and monitoring performance)

Note that there are more ways to define leadership styles across different fields that study leadership.**

Formal vs. Informal

Transactional vs. Transformational

Bureaucratic vs. Charismatic

Position vs. Expertise

Expressive vs. Instrumental

Note that there are more ways to define leadership styles across different fields that study leadership.

**Q2. Are transformational leaders necessarily better than transactional leaders? (when might transactional leadership be more effective?)**

Transformational leadership is the ability to change how an organization works and create lasting change (that outlasts the leader!). Transformational leadership makes social movements successful, businesses resilient, employees motivated, and creates group unity.
However, in a crisis, when a group has diverging motivations or when you already have a clear structure, transactional leadership can also be highly effective. In the long term, combining strategies from the two styles seems beneficial.

**Q3. Imagine 2 “leaders”:1 - someone who has absolute control over a group using threats (of violence).

2 - someone who only acts to keep themself in power.

Why are these not leaders with #leadprinciples?**

1 - the group members have no freedom. Even though leaders sometimes threaten with punishments or consequences, followers should, in theory, always have some freedom to either follow or not follow a leader. #leadprinciples should encourage following without forcing it.
2 - the leader works toward no goal beyond power itself. Although it is regularly the mark of a good leader that they manage to lead for a longer while, #leadprinciples are always employed to achieve something beyond this – a group's shared purpose most often. If a group’s values or principles are not recognized, respected, or honored, if power is purely selfish, we speak of despotism, not leadership.

**Q4. Why is it wise to include the led group in your analysis?**

Effective leaders are in tune with their following. They are likely to be empathetic and good listeners (#emotionaliq), and able to deal with various people (they understand #differences). Different groups will create other prerequisites for effective leadership based on their unique characteristics and interactions.
Another part of good leadership is understanding where a group is coming from. They might want to reverberate the goals and #purpose of those they’re leading and use the appropriate wording, narratives, ideas, and evidence as part of #audience.

**Q5. How should I apply #leadprinciples when defending a claim about “good” leadership?**

#leadprinciples focuses on a prudential understanding of goodness, determined by effectiveness. Applications of #leadprinciples should be tailored to considerations of effectiveness – often in terms of the ability to achieve some goal.“Good” leadership might also imply ethical expectations of leaders. Here, we would need to analyze the #ethicalconsiderations, and likely defend our view of what ethical leaders should or should not do (#ethicaljudgment). Applications of #leadprinciples do not require applications of ethics HCs, but drawing such connections may enrich the work when assignment and space parameters allow. For example, effective leadership also includes receptivity to the interests and values of a group being led, which might include an analysis of a group’s #ethicalconsiderations.

## Guided reflection (proficiency checklist)

1. Are you identifying a leader's leadership style based on the most salient interactions with a group (that you expressly point out)?
2. Are you explaining how a leader thinks of goals and values at various levels or scales?
3. Have you evaluated the compatibility/relevance of a given leadership style with the group’s current characteristics, dynamics, or context?
4. Have you backed up your interpretations and analyses with evidence?
5. Are you thinking about HCs such as #purpose and #powerdynamics (or others, from the “is it this HC” section) that underlie the leadership principles you discuss?
6. You don’t have to tag those HCs you think about, but you could if you go in-depth!
7. Have you justified any normative claims you’ve made about what a good leader should do in a circumstance? If so, have you investigated how to apply #ethicalconsiderations or #ethicaljudgment to support your argument?

## Common pitfalls

1. Solely analyzing how a leader keeps themself in power, without explaining how their leadership achieves some larger purpose.
2. Because leadership consists of many possible qualities and behaviors, a danger is to describe many of those superficially without going into depth about any of them.
3. Tagging too many potentially complementary HCs that you haven’t applied particularly well, perhaps given the constraints of the assignment.
4. Failing to back up interpretations with credible evidence, taking too much for granted.
5. Arguing against forms of ethically bad leadership without evaluating the effectiveness of that leadership style.

## Applying the HC at Minerva

1. Sociology (understanding leadership interactions with groups): A sociologist will look at leadership and focus on the characteristics and dynamics of the group being led (that also might have chosen the leader) and how the leader can influence this group. For example, to understand Hitler’s leadership as a sociologist, you’d want a solidly informed grasp of various parts of German society at the time and how it was changing.
2. History and Politics (analyzing examples of leaders and their choices): In many analyses of historical or current political events, we consider the influence of leaders. When studying these figures, try to focus on understanding the structures in which they operate and their interactions with their followers. Use various sources – from biographies and first-hand accounts to contextual sources like newspaper articles – to inform your analysis.
3. Business: Some business courses specifically focus on how to effectively lead a business. We celebrate successful leaders, and leadership is a whole area of expertise within various fields of business, whether it is about creating a brand, managing the internal structure of a business, or dealing with stakeholders. Make sure to understand that different types of companies will require different types of leadership. Managing a big bank is very different from creating a startup that comes up with the most innovative solutions and adapts to rapidly changing business environments.
4. Group Work (throughout Minerva): You might use #leadprinciples when deciding who should lead a group project when leading the group yourself or just to understand the dynamics in a group. When working in a group, leadership often emerges informally when people look to a particular person for guidance, whether because of their social confidence or their assumed expertise on the project they are working on.  For example, when applying #leadprinciples, you could explain how you observed the gaps in leadership throughout the project and what you did to improve them.

## Applying the HC outside Minerva

1. As a leader: You might end up in a manager or leadership role within your career at one point, but you are likely also applying leadership skills when interacting in spaces without a clear hierarchy. You don’t necessarily need a formal leadership position. You can make a change by setting an example or coming up with transformational ideas that strike a chord with those around you!
2. Navigating different types of superiors: Whether in an institution like a university or when working a job, you must report to and cooperate with different leaders. Some will be good, some not so much, but understanding their leadership style and qualities will help you encourage good leadership in those above you and give effective feedback on whatever is potentially problematic about a leadership style. Even if some leadership styles annoy you, it can help to see the bigger picture and consider why a particular leader might be acting the way they do.
3. Navigating different leadership structures: Sometimes, something in the structure of the organizations we work in stimulates certain kinds of leadership. Suppose an organization has to report on some sort of goals. In that case, it can pressure a leader to focus their leadership on those goals rather than on other purposes like creating group identity or shared learning. Consider addressing the factors that promote or discourage certain types of leadership.
4. Voting for or running for leadership positions: Understanding #leadprinciples helps us weigh alternative options for group leadership in political contexts, empowering us to understand their goals and strategies better. As members of political groups, we can also use #leadprinciples ourselves when advocating for policies or political platforms to help us focus our efforts on group-informed goals.

## Key resources

1. Powers, J. & Wilkins, J. (2022). Leadership in Complex Systems (Perry, T.J. Ed.). Minerva Guide. https://docs.google.com/document/d/1Qsbe89vuPIfv_F3CwbwK4HTpa2julqVo9WZnnztIP9k/edit#
- This resource walks you through the approaches to defining, analyzing, designing, and refining leadership approaches. It describes the main characteristics of leadership and the principal axes for evaluating leadership styles. It also lays out the difference between “effective leadership” (what we hope to understand with #leadprinciples) and ethically “good leadership” (for which we might need ethics HCs in addition to #leadprinciples). It also includes a great list of even more resources on leadership!
2. Powers, J. (2022). Leadership Case Study - The Four Horsepersons. Minerva Guide. https://docs.google.com/document/d/1dZObvfvjt3to3rx7-trlGtOXOv0OtuP_6RmliEGDU7M/edit#
- This case study is excellent for practicing applications of #leadprinciples in group work contexts, comparing leadership styles, and choosing leaders.
3. Scharlatt, H. (2011, January 3). How to influence when you don’t have authority. Forbes. https://www.forbes.com/2011/01/03/influence-persuasion-cooperation-leadership-managing-ccl.html?sh=78e7d1e34b9c
- This short article briefly mentions some strategies to influence people without being in a formal leadership position. It distinguishes between logical, emotional, and cooperative appeal. It has some overlap with #persuasion. — [link](https://my.minerva.edu/academics/hc-resources/hc-handbook/persuasion/)
4. Bal, Vidula, Michael Campbell, Judith Steed, and Kyle Meddings. ‘The Role of Power in Effective Leadership’, 1 January 2008. https://managementandthearts.com/5e/wp-content/uploads/2014/10/Role_of_Power_in_Leadership.pdf
- This report is a primary resource for #powerdynamics, laying out essential power uses in leadership. It discusses how to leverage power with colleagues or managers. It emphasizes the power of relationships as the most vital of the types discussed. Consider overlaps between these HCs and how leadership principles map onto types of power you could use. — [link](https://my.minerva.edu/academics/hc-resources/hc-handbook/powerdynamics/)

## Custom HC guides

- [Leadership in Complex Systems](https://docs.google.com/document/d/1Qsbe89vuPIfv_F3CwbwK4HTpa2julqVo9WZnnztIP9k/edit)
- [Leadership Case Study - The Four Horsepersons](https://docs.google.com/document/d/1dZObvfvjt3to3rx7-trlGtOXOv0OtuP_6RmliEGDU7M/edit)

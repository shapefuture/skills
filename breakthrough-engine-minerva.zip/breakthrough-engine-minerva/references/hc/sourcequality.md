# #sourcequality — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/sourcequality/](https://my.minerva.edu/academics/hc-resources/hc-handbook/sourcequality/)
> **Habit of Mind** · Cornerstone course: Multimodal Communications · Competency: Thinking Critically → Evaluating justifications
> Taught in: Multimodal Communication | Semester One · Unit: Close Reading
> Big Question: How does language represent reality?

## Definition

**#sourcequality** — Distinguish between categories and types of information to determine source quality.

> **Pitch:** You can’t build a house on shaky foundations, and you can’t support an argument with untrustworthy sources.

Sources of information can be scrutinized in terms of their currency, relevance, authority, accuracy, and purpose. One should be able to check how information is vetted and verified and whether there is a means to correct errors. Using this criterion, one can assess the overall credibility of a source and the degree to which it can be used as evidence in one’s work.

## Worked example

You are searching for information about how much sleep you need each night. You ask a friend who seems well-rested how much sleep they get each night, and they say 6 hours. You realize this friend is not a credible source because they have no expertise in sleep science. You then consult Wikipedia, which recommends you get 7-8 hours of sleep each night. You know that Wikipedia is an unreliable source because anyone can edit it. However, you utilize the references on this page and find a blog post from a professor with a Ph.D. in neuroscience specializing in sleep disorders. You check the date on the article, and it was published just a few months ago. The professor is sponsored by the university she works at. The blog post dives into why everyone needs at least 8 hours of sleep for a healthy circadian rhythm. You find this a bit surprising. The source seems credible, but blogs tend to be self-published, so you look into academic research journals for additional publications by this author. From your search, you find an article they published in the New England Journal of Medicine, a reputable peer-reviewed professional journal, and use that article as your primary source. This is a credible source for the information you are looking for, but you continue to look for corroborating sources and counterarguments to increase your confidence, especially if you aim to convince others or present this information in a work product.

> **Footnote:** You consider various sources - a friend, Wikipedia page, blog post, and peer-reviewed article - when researching how much sleep you need. You determine that the first two sources are unreliable, and although the blog post seems credible, it may be biased as a self-published work. After further searching, you find a peer-reviewed study written by the author and evaluate it based on CRAAP criteria. The article discusses sleep patterns, proving its relevance to your work. The information is current and accurate because the article was published just last year in a reputable peer-reviewed journal. The author has authority based on her credentials in the field, and her purpose is likely to advance knowledge in this field. Based on these factors, you deem the article a high-quality source.

## Is it this HC?

Is #sourcequality the right HC? If the answer to the following questions is yes, #sourcequality could be useful:

- Do any outside sources inform your work?

- Would high-quality, credible sources improve your work?

- Did you use AI tools to assist in writing or your source-gathering process?

Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#evidencebased](evidencebased.md) | focuses on how evidence has been chosen and structured to support the work best. sources are often vetted before they are integrated into the work, so #sourcequality is applied before #evidencebased. |
| [#context](context.md) | situates a work in its appropriate context for analysis or argumentation. |
| [#professionalism](professionalism.md) | deliberately formatted and presented to align with discipline-specific conventions. |
| [#audience](audience.md) | consideration of the audience should meaningfully inform the types of sources utilized. |

## Self-study Q&A (7 questions)

**Q1. What are the main elements of #sourcequality?**

CRAAP. Currency, relevance, accuracy, authority, and purpose.

**Q2. What does it mean for a source to meet CRAAP criteria?**

- Currency: The timeliness of the information.

- When was the information published, posted, revised, or updated?

- Are current sources required for your topic, or will older sources also work?

- Relevance: The importance of the information for your needs.

- Does the information relate to your topic or answer your question?

- Who is the intended audience for the information?

- What is an appropriate level of detail?

- Accuracy: The reliability, truthfulness, and correctness of the content.

- Does evidence support the information?

- Where does the information come from?

- Has the information been reviewed or revised?

- Is the tone and language unbiased?

- Authority: The source of the information has expertise on the topic.

- Who is the author, publisher, source, or sponsor?

- What are the author’s credentials or organizational affiliations?

- Is the author qualified to write on the topic?

- Is contact information for the author or other contributing parties available?

- Purpose: The reason the information exists.

- Is the information meant to inform, teach, sell, entertain, or persuade?

- Does the point of view appear to be objective and impartial?

- Are there political, religious, institutional, or personal biases present?

**Q3. Are all sources published in scholarly journals peer-reviewed sources?**

No. Scholarly journals also include book reviews, editorials, letters to the editor, and short news items, that are not peer-reviewed scholarly sources. Therefore, even when searching for sources within scholarly journals, CRAAP criteria must be utilized.

**Q4. Is Wikipedia a credible source?**

No. Anyone can edit Wikipedia, so it is not a credible source. However, it can still be a useful resource because the bibliographies of many Wikipedia pages feature high-quality sources that relate to the topic. These sources can be vetted under CRAAP criteria and utilized as evidence in your work. If you find a promising source but can not access it because it is behind a paywall or not included in Minerva’s library resources, then you can not use it. You should never make assumptions about the content of an inaccessible source or attempt to vet any source for credibility without full access to the source.

**Q5. How can AI-generated sources be vetted?**

AI can be a helpful tool to generate possible sources for your topic, but you must first ensure responsible AI use is in line with your course-specific instruction. AI-generated sources should NOT be accepted as credible sources without applying CRAAP criteria. You will need to track down and review any source generated by AI tools to ensure that they exist, are appropriately cited, and actually serve as appropriate evidence for the claims they intend to support. To streamline the vetting process, ask the AI tool differently framed questions about your topic, search for corroborating sources, and request counterarguments. Looking for sources that offer different positions than yours helps strengthen your endorsement or reliance on a particular source instead of another. AI can be a helpful tool in finding and vetting sources, but it can not be a source in and of itself.

**Q6. Can personal experience be a credible source?**

Sources come in many different forms: observations, news articles, official documents, interviews, surveys, experiments, and even personal anecdotes and experiences. Whether personal experience counts as a high-quality source depends on the context. It can be a valuable source when it is well-aligned with the argument and relates to the relevant aspects of the CRAAP criteria (most likely relevance, authority). However, it usually shouldn’t be your only form of evidence. You should still pair it with other sources (empirical data, scholarly research, official reports) that help corroborate it.

**Q7. You've found two seemingly credible sources for your paper: a NYT article about a new study on sleep and memory, and a page on a university website written by the researchers who ran the study. Both are reputable. How do you decide which one has stronger Authority for your claim?**

When both sources are credible, we need to look for which author has the right expertise for this specific claim. A quick way to check that using steps from the SIFT method: 
- Investigate the source. The journalist may be an experienced scientific reporter, but the researchers are experts in their field, so for a claim about what the study found, their expertise is more relevant.

- Trace it back to the original source.

## Guided reflection (proficiency checklist)

1. Have your sources been vetted for CRAAP criteria?
- Is the source current? How important is currency to your topic?

- Is the source relevant? How related to your topic is the source?

- Is the source accurate? Does strong evidence back it up?

- Does the source have authority? Is the author an expert on the topic?

- What is the source’s purpose? What is the source’s goal? Is it likely biased?
2. Have you identified which aspect of CRAAP is most important for your topic and justified why it is prioritized?
3. Have you identified corroborating sources?
4. Have you searched for counterarguments and opposing viewpoints?
5. Have you justified why your chosen sources are stronger than alternative sources?
6. Have you utilized databases and scholarly journals to find useful sources?
7. For AI-generated sources, have you tracked down and reviewed any sources suggested?
8. For personal forms of evidence, have you explained how they add depth or nuanced perspectives to your argument, and have you paired them with more well-established sources that contextualize them?

## Common pitfalls

1. The application has not vetted sources for CRAAP criteria.
2. The application does not meet part of the CRAAP criteria without explaining why that element was deemed unimportant, or why you diverted from these criteria.
3. The application uses AI as a source rather than a tool.
4. The application uses AI-generated sources without obtaining them or vetting them.
5. The application relies on sources generated by AI tools that are non-existent, inaccessible, or inappropriate.
6. The application does not look for opposing evidence or counterarguments.
7. The application uses a source with no corroborating sources.
8. The application dismisses personal forms of evidence, even though they may have nicely complemented their other sources.

## Applying the HC at Minerva

1. In a history class, you could apply #sourcequality to analyzing a significant historical event. For example, suppose you are researching how women were impacted by the Great Depression in the United States. In that case, you may utilize a journal written by a woman who lived through the Great Depression and documented her thoughts about the economic disaster. The source will not be current, but that is deliberate because you want to incorporate a direct source from the period. While this woman isn’t a researcher, she is authoritative over her personal experiences, which provides a perspective central to your research questions. Her purpose was to write for herself, and though you cannot check the accuracy of everything she writes, her insights advance your goal of digging deeper into the personal part of the Great Depression. Finally, the journal is relevant since it is a primary source of information from a woman who experienced the Great Depression. Therefore, this source is high-quality and credible for your purposes, even though it does not meet the CRAAP criteria perfectly. You decide you will use this source to back up your analysis. Now you look for sources that provide broader studies of this period and again vet them for source quality.
2. For your capstone project, you aim to research the connections between advancing the U.N. Sustainable Development Goals while promoting vegetarianism. You begin by reading a short post written by someone working for the U.N. to get their perspective, but you soon decide to branch out and get outside perspectives, especially since such prioritization could impact policies affecting people in a wide range of countries. You open up ChatGPT and ask it to generate a list of ten credible sources with notes explaining how each source addresses the potential compatibility of vegetarianism to sustainable development, and it generates a list of annotated sources. You begin to look for the sources online and find that six are behind paywalls and you can’t read them, two are accessible using our library systems, and two are non-existent sources. You focus on the two you can access and read and then evaluate the source quality and merits of the arguments in the two sources you can read, following up on promising footnotes you find in those articles to widen the basis of your judgment.

## Applying the HC outside Minerva

When participating in academic work, you will often utilize sources. Whether you are using sources to learn something new, support your argument, or brainstorm ideas, you must carefully vet those sources for credibility. However, in everyday life, #sourcequality can be helpful to ensure reliable sources support the information you are absorbing. For example, if you read an article that attempts to argue that vaccines are linked to autism, they will likely reference a dated and inaccurate study that falsely claimed to find such a link. Being a critical reader of potential sources, you check for debunking arguments and quickly come upon a wide range of articles published more recently in scholarly journals that carefully and clearly undermine the reliability of the initial report you found. Consciously applying #sourcequality will reveal that the article’s sources fail the CRAAP criteria and, therefore, the claims in the article are invalidated. This HC gives you the power to fight back against false claims in the media.

## Key resources

1. “Harvard Guide to Using Sources.” Usingsources.fas.harvard.edu, https://usingsources.fas.harvard.edu/sites/projects.iq.harvard.edu/files/sources/files/using_sources.pdf
- Harvard’s guide addresses all types of sources, not just those you will find online. It also addresses the question of Wikipedia and its usefulness as a resource. The information under the “Evaluating Sources” section from “Questions to Ask About All Sources” to “Making Decisions Based on Your Discipline” will be particularly useful.
2. Breger, M. (2022, November 30). Research Guides: Introduction to Rutgers University Libraries: Is it scholarly? Libguides.rutgers.edu. https://libguides.rutgers.edu/c.php?g=336662&p=2266858
- This short guide from Rutgers University includes a comparative chart that helps distinguish between popular, trade, and scholarly sources.
3. Minerva University. (2022). Minerva University. My.minerva.edu. https://my.minerva.edu/academics/learning-resources/minerva-university-library/
- Sign on using your Minerva Google account. Open Minerva Library Step-By-Step Directions and Videos and log in to and utilize these databases. The databases provide access to high-quality peer-reviewed sources you would otherwise have to pay for.
4. Think It Clear. (2016). Finding Scholarly Resources for Research Papers | Think It Clear. YouTube. https://www.youtube.com/watch?v=F-Mtg2HfkbY
- This video explains appropriate (or inappropriate) research and how to use different search engines and databases to locate research material.
5. AEUK. (2018, July 8). Evaluating Sources - the CRAAP Test / Academic Peer Review Process. Academic English UK. https://academic-englishuk.com/evaluating-sources/
- This resource breaks down CRAAP criteria.


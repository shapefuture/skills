# #communicationdesign — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/communicationdesign/](https://my.minerva.edu/academics/hc-resources/hc-handbook/communicationdesign/)
> **Habit of Mind** · Cornerstone course: Multimodal Communications · Competency: Communicating Effectively → Using nonverbal communication
> Taught in: Multimodal Communication | Semester Two · Unit: Interpretation
> Big Question: How do we interpret artistic communication?

## Definition

**#communicationdesign** — Apply principles of perception and cognition in oral and multimedia presentations and in design.

> **Pitch:** Powerpoints suck, but you don’t have to! Design your communication in a fun and engaging way.

A large body of research has documented many aspects of human perception and cognition, resulting in a set of principles that captures how humans organize and interpret what they see and hear. Illustrations—in published works as well as presentations and video—will communicate effectively only if they respect these principles. Similarly, objects that invite specific uses must be designed to communicate those uses clearly.

## Worked example

You attend a talk about conscious spending where the presenter uses a powerpoint presentation to complement his speech. You notice that his slides have very different fonts and jarringly contrasting colors, which confuses you because they talk about the same topic. You also find it hard to understand what is important in each slide because their texts are dense and font size small. The diagrams don’t display any of the information on the slides, but rather data that has to do with another part of the speech, making it hard to follow. You realize that his communications were ineffective and you are left confused by the end of their talk because their visual communications didn’t adhere to any of the cognitive principles of communication design.

> **Footnote:** There is too much information being displayed, violating the principle of limited capacity (states that humans have limited cognitive capacity for understanding information). The diagrams and numbers don’t complement the text, which violates the principle of compatibility and the lack of consistency and change in color/font does not indicate a change in content as humans normally expect, which violates the principle of informative change, rendering communications ineffective.

## Is it this HC?

Is #communicationdesign the right HC? If the answer to the following questions is yes, #communicationdesign could be useful:

- Are you trying to communicate an idea in bullet or graphic form?

- Are you presenting a slideshow that will be accompanied by spoken details?

- Are you attempting to communicate to an audience in an effective and efficient manner?

Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#multimedia](multimedia.md) | analyzes how multiple mediums work together or conflict with each other, or creates a work of multimedia. |
| [#persuasion](persuasion.md) | discusses the design and execution of an argument. considers different theories and effects at play, like the assimilation effect from social judgment theory. |
| [#medium](medium.md) | analyzes and utilizes a certain medium at the level of form and structure. |
| [#evidencebased](evidencebased.md) | identify and appropriately structure the information needed to support an argument effectively. |
| [#scienceoflearning](scienceoflearning.md) | identifies the ways humans are best able to learn and retain information. focuses more on how to learn information than how to share information. |

## Self-study Q&A (6 questions)

**Q1. What are the main principles of communication design?**

Discriminability, perceptual organization, salience, limited capacity, informative change, appropriate knowledge, compatibility, relevance.

**Q2. What do each of the main principles entail?**

- Discriminability

- Two properties cannot convey different information unless they differ by a large enough proportion to be easily distinguished.

- Perceptual Organization

- People automatically organize elements into groups, which they then attend to and remember.

- Salience

- Attention is drawn to large perceptible differences.

- Limited Capacity

- People have a limited capacity to retain and to process information and will not understand a message if too much information must be retained or processed.

- Informative Change

- People expect changes in perceptual properties to carry information, and expect every necessary piece of information to be conveyed by such a perceptible change.

- Appropriate Knowledge

- Communication requires prior knowledge of relevant concepts, jargon, and symbols.

- Compatibility

- A message is easiest to understand if its form is compatible with its meaning.

- Relevance

- Communication is most effective when neither too much nor too little information is presented.

**Q3. What is the maximum number of bullets you should put on a slide to adhere to the limited capacity principle?**

Four bullets or less adheres to this principle. More than four bullets often can not be fully processed by the audience and will either distract from the speaker or be ignored altogether.

**Q4. When is communication design most often used?**

In presentations that include illustrations, graphics, or bullets. This is especially common in slideshows. In these situations, the audience must focus both on the speaker and the slides, so the slides must be designed effectively to convey the message while not taking too much attention from the audience. Clear graphics and bullets are often utilized to get across the main points, while more detail is explained orally by the presenter.

**Q5. Kosslyn groups the #communicationdesign principles based on how we process and retain information, breaking them down into three stages: encoding, working memory, and accessing long-term memory. Where does each principle fit in with these stages, and how do they work together?**

By understanding encoding, working memory, and long-term memory, you can structure your communication in ways that help your audience absorb, process, and remember information more effectively.

- Encoding (First Impressions & What Stands Out)
When we first see a slide or piece of information, our brain quickly scans for key differences and patterns.
- Discriminability, Salience, and Informative Change help make sure that differences are noticeable, key elements stand out, and changes add meaning instead of confusion.

- Perceptual Organization helps us group related elements together, making the structure clearer at a glance.

- Working Memory (Making Sense of the Information)
As we process the content further (especially across multiple slides or sections), we try to understand its meaning.
- Appropriate Knowledge ensures the audience can use what they already know to interpret new information.

- Compatibility makes sure the symbols, labels, and layout match what the audience expects, so they don’t have to struggle to understand it.

- Accessing Long-Term Memory (Retention & Relevance)
Even if information is clear and well-structured, it won’t be useful unless it is memorable and relevant.
- Relevance ensures the information fits the audience’s needs and goals so they stay engaged.

- Limited Capacity reminds us that too much information at once overwhelms memory and makes it harder to retain key points.

**Q6. How can we distinguish between similar communication principles?**

Here are some examples of key differences between similar principles:

- Discriminability vs. Salience vs. Informative Change
Discriminability makes sure differences are clear, Salience highlights what grabs attention, and Informative Change ensures differences have meaning.

- Perceptual Organization vs. Compatibility
Perceptual Organization helps us group information, while Compatibility makes sure it aligns with expectations.

- Appropriate Knowledge vs. Compatibility
We need prior knowledge to understand new concepts, but even familiar ideas can be confusing if presented in an unexpected way.

- Limited Capacity vs. Relevance
Too much information at once overloads the audience, while Relevance makes sure only the most important information is presented.

## Guided reflection (proficiency checklist)

1. Have you adhered to the main principles of communication design?
2. Do your visuals enhance the communication, providing a value add to your work?
3. Have you explained how using #communicationdesign improved your ability to communicate effectively?
4. Are all graphics used clear and relevant to your message?
5. Are slide template or theme choices justified with explanation about how they aid your purpose?

## Common pitfalls

1. One or more of the main principles of communication design have been neglected without explanation.
2. Visuals do not distract from the communication, but they do not add anything either.
3. Visuals are blurry, unrelated, or watermarked.
4. A slide template was applied without critical analysis on its effectiveness for your purpose.

## Applying the HC at Minerva

1. In the natural science college, you can use #communicationdesign to explain your research findings to others through visuals and graphics. By using the principles of #communicationdesign you can hold your audience’s attention while adding to their understanding of your findings. For example, explaining how research in clean energy has expanded and impacted climate change since 2000 could be aided by incorporating important visuals, graphics, and timelines that adhere to #communicationdesign.
2. In the social science college, #communicationdesign could help you build slides to pitch your social-action idea to funders. By having visuals that will enhance your communication by illustrating the social issue and possible impact of your idea, you can capture your audience and ensure your idea becomes change.

## Applying the HC outside Minerva

1. When designing social media posts for your small business, #communicationdesign can be the difference between an active following and a failure to reach you audience. On social media these principles are particularly important because the audience tends to be impatient and disengaged. Therefore, stunning visuals with short but detailed bullets can draw possible customers in and help your business grow!
2. As with all HCs, the applicability of communication design principles may vary depending on #audience. The principles are useful and can open your eyes to communication nuances, but they are not universal and timeless. Adjust applications thoughtfully for different audience expectations. This could look like violating a principle on purpose to convey a particular meaning (for example, purposely cluttering a slide with content to convey a sense of “chaos” to make a salient point for the audience). Strong applications might also consider different perceptions across cultures. For example, some Asian countries prefer bright, information-dense slides, reflecting a holistic way of thinking and the importance of context, rather than the principles of limited capacity. In South Korea, presentations often include numerous facts, figures, and visuals, with overloaded slides delivered at a fast pace. Visit these links to learn more about design across different regions and presentations in South Korea. Even color can symbolize different things across different cultures. Blue is believed to be the safest and most commonly positively perceived color across cultures, although it could also stand for sadness. If this interests you, visit this article to learn about tips for presentations across cultures. These are just a couple of examples that illustrate how the applicability of the communication design principles can vary based on your #audience.

## Key resources

1. Kosslyn, S. M., Kievit, R. A., Russell, A. G., & Shephard, J. M. (2012, June 19). PowerPoint® Presentation Flaws and failures: A psychological analysis. Frontiers. https://www.frontiersin.org/articles/10.3389/fpsyg.2012.00230/full#h3
- This resource is a study on communication design and explains the key principles of communication design in detail.
2. Minerva Academic Team. (2021). HC Guide for Visuals. https://my.minerva.edu/academics/hc-resources/additional-resources/
- Check this out as an additional resource for successful application of #communicationdesign and other HCs related to visual communication.
3. Albinagorta, C. (2019, September 19). Bad powerpoint examples you should avoid at all costs. 24 Slides. https://24slides.com/presentbetter/bad-powerpoint-examples-you-should-avoid
- This fun resource gives examples of failures in communication design. Learn what NOT to do!


# #emotionaliq — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/emotionaliq/](https://my.minerva.edu/academics/hc-resources/hc-handbook/emotionaliq/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Working with others
> Taught in: Complex Systems | Semester One · Unit: Complex People
> Big Question: Why do people commit crimes?

## Definition

**#emotionaliq** — Use emotional intelligence to interact effectively.

> **Pitch:** Emotional intelligence is like GPS for social interactions.

Intelligence has many facets, one of which involves recognizing, understanding, using, and managing emotions. Successful interactions often hinge, at least in part, on our ability to control our anger or discern the emotional reaction of others to our actions. Emotional intelligence is the ability to be aware of and evaluate emotions (both one’s own and others), as well as control one’s own emotions. The four branches of emotional intelligence are perceiving emotions, understanding emotions, using emotions, and managing emotions. These emotional intelligence skills can be practiced and improved.

## Worked example

You realize that lately your team meetings have been tense and coworkers have been making pointed and aggressive comments to each other. These interactions are making meetings less effective. You notice it has been occurring more in the meetings scheduled later in the day than those that happen in the early morning. Your mother sends you an article about “hanger” and the effects that blood sugar can have on your emotions. You notice that the meetings where coworkers are most aggressive are farther from the last meal than those where they are calmer, and isolate hunger as a possible cause of people getting moody and upset, which in turn is having a negative impact on productivity. Because of this, you start bringing bowls of popcorn to team meetings. After a few weeks, you notice your team is much happier and cooperating better than before, having fewer fights and being more collaborative.

> **Footnote:** You were able to identify a clear difference in team emotional intelligence in different instances of the day, identify the cause of negative emotional states and their effect, and implement a strategy to regulate group emotions by targeting and regulating each individual’s emotions, leading to more effective interaction overall.

## Is it this HC?

Is #emotionaliq the right HC? If the answer to the following questions is yes, #emotionaliq could be useful:

- Are you explaining why certain emotions lead to different outcomes? 

- Are you aiming to self-regulate or interact effectively using the knowledge of emotions?

Depending on the work product, there might be other HCs to consider. ….

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#selfawareness](selfawareness.md) | Is focused on self, identifies our own strengths and weaknesses and aims to mitigate harmful behaviors. Self awareness is an essential quality of an emotionally intelligent person, however, emotional intelligence encompasses interpersonal abilities too. |
| [#psychologicalexplanation](psychologicalexplanation.md) | Utilizes psychological theories and considers psychological factors interacting at different levels of analysis to explain human behavior. This HC helps you identify the causes of your and others emotions allowing you to better understand and regulate them. |
| [#leadprinciples](leadprinciples.md) | Uses leadership principles to achieve a group’s objective. As a leader, you will need emotional intelligence to influence your team’s attitude and efficiency. |
| [#negotiate](negotiate.md) | Approaches negotiation with structure to achieve the desired objectives. Recognizing, and managing your and other negotiators emotions can help you reach the successful resolution. |
| [#emergentproperties](emergentproperties.md) | Analyzes and predicts emerging properties by looking at the system’s components and interactions between them. Team EQ is an example of an emergent property as it is not a sum of the individual EQ of the members (learn more in HBR article from Key Resources). |

## Self-study Q&A (5 questions)

**Q1. Describe the four-branch model of emotion intelligence and give an example for each.**

The four-branches, i.e. abilities, of emotional intelligence are: perceive, use, understand, and manage. Perceiving emotions is the most fundamental ability as other branches depend on having emotional information. Using emotions is the ability to identify what skills are enhanced while experiencing different emotions and harnessing them to achieve desired outcomes. Understanding emotions means recognizing slightly different emotions and how they evolve. Lastly, managing emotions is to alter and regulate emotions depending on the context. You can read about the examples and more elaborate explanations in Salovey, P. & Grewal, D. paper linked in the Key Resources.

**Q2. What are the characteristics of an emotionally intelligent team and what are some ways it can be fostered?**

An emotionally intelligent team sets norms that lead to trust among members, a sense of group identity and a sense of group efficacy. Having these qualities is what leads to complete engagement in tasks. Emotionally intelligent teams build trust by ensuring that all team members are able to share their opinions, including those who disagree with the majority. Teams should also establish norms that reinforce confrontation to avoid disruptive behavior from reoccurring. You can  learn more about other strategies in the HBR article linked in Key Resources.

**Q3. What can you do to become more emotionally intelligent?**

Emotional intelligence is not a fixed characteristic and can be improved using different techniques that involve introspection such as self-evaluation and observing how you react to other people. Learn other strategies in the Mind Tools website from the Key Resources.

**Q4. How can emotional intelligence be harmful?**

There is a fine line between using EQ to motivate people vs. to manipulate them. Recognizing others' emotions and their causes gives one the power to alter the emotions to achieve self-serving goals which can also be against the best interests of others. Furthermore, research on the relationship between EQ and job performance has not been uniform indicating that in jobs with lower emotional demands (e.g., data analysis)  the high EQ can do a disservice as it can distract the employee (See more in The Atlantic paper from the Key resources).

**Q5. Reflect on a recent challenging interaction you had, either personally or professionally. How did your emotional response influence the outcome? In hindsight, what aspects of emotional intelligence could you have applied more effectively to alter the outcome positively?**

Aspects of emotional intelligence that may be relevant to your answer include empathy, self-regulation, and understanding others' emotions. Of course, the answer to this question will depend on the interaction you choose and its specific characteristics. Make sure to reflect on how this HC can help you understand and better manage these kinds of situations.

## Guided reflection (proficiency checklist)

1. Have you explained how particular causes and effects result from emotions in sufficient detail?
2. Have you used the four-branch model to foster desired outcomes or mitigate potential challenges?
3. Have you identified non-obvious emotions or effects of emotions and explained their relevance?
4. Have you been precise in identifying and naming the relevant emotion?

## Common pitfalls

1. Does not provide sufficient details to explain causes and effects that result from emotions.
2. The relevance of emotions is not convincing.
3. Does not provide evidence for how the HC was applied.
4. Fails to (accurately) link emotional intelligence concepts (e.g., four-branch model of EQ).

## Applying the HC at Minerva

1. You can use this HC in GL assignments when you set goals or reflect on your interpersonal engagement and self-management & wellness throughout the semester.
2. Emotional intelligence is essential for frictionless group work during group assignments and civic projects.
3. You get a 2 on an LO in one of your concentration courses. You are angry, because you worked very hard on the assignment. Your initial impulse is to put in less effort on your next assignment, partly because you don’t think it will pay off, and partly to spite your professor. But then you recognize that you can actually use that anger to fuel your work on the next assignment. You think about the 2, using it to focus your energy, and you wind up getting a 4.

## Applying the HC outside Minerva

1. Emotional intelligence is essential to create meaningful and long-lasting relationships. For example, identifying the causes of your partner’s emotions and self-regulation can aid difficult conversations. EQ can be used to predict potential challenges in relationships and take action to prevent or mitigate them. For instance, you are expecting a big shift in your lifestyle in the upcoming months which gives the feeling of uncertainty. Based on your self-observation, you know that during times of uncertainty, you tend to isolate yourself which can create conflict in your relationship. Therefore, you decided to talk to your partner to warn them about the potential challenge and devise strategies to ensure that your partner feels connected while you meet your need of being alone.
2. The ability to recognize your own and your team members’ emotions and use this information to guide your actions is an important quality of leadership. The conceptual understanding of EQ can help you foster team EQ. As a leader, you will also be negotiating with stakeholders which requires one to be emotionally intelligent.

## Key resources

1. Mind Tools Content Team. (n.d.) Emotional intelligence: developing strong “people skills”. https://www.mindtools.com/pages/article/newCDV_59.htm
- This article explains what emotional intelligence is and what one can do to improve it. It identifies the key characteristics of emotional intelligence and the strategies that one can use to strengthen those characteristics.
2. Druskat, V. & Wolff, S. (2001). Building the emotional intelligence of groups. Harvard Business Review. https://hbr.org/2001/03/building-the-emotional-intelligence-of-groups
- This article focuses on emotional intelligence at the team level. Focus on how the emotional intelligence of groups can or cannot be predicted by the emotional intelligence of their members.
3. Salovey, P. & Grewal, D. (2005). The science of emotional intelligence. Current directions in psychological science, 14(6), 281-285. Found in EBSCO Academic Search Complete
- John Mayer and Peter Salovey were among the first to identify emotional intelligence as a distinct psychological function. This paper defines the four-branch model of emotional intelligence and discusses an approach to measure it.
4. Grant, A. (January 2, 2014). The dark side of emotional intelligence. The Atlantic. https://www.theatlantic.com/health/archive/2014/01/the-dark-side-of-emotional-intelligence/282720/
- Although the concept of emotional intelligence typically has positive connotations, this article discusses reasons for thinking that it is not universally beneficial.


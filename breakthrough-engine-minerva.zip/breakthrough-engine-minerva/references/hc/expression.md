# #expression — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/expression/](https://my.minerva.edu/academics/hc-resources/hc-handbook/expression/)
> **Habit of Mind** · Cornerstone course: Multimodal Communications · Competency: Communicating Effectively → Using nonverbal communication
> Taught in: Multimodal Communications | Semester One · Unit: Bringing it all together
> Big Question: How might we navigate our place in society?

## Definition

**#expression** — Interpret, evaluate, and utilize nonverbal communication.

> **Pitch:** Your face says it all, so make sure it says what you intend it to.

Nonverbal cues are a critical part of communication. Our bodies’ positioning, gestures, and movement can reinforce what we are communicating verbally or undermine our meaning. In particular, facial expressions convey enormous amounts of information, ranging from emotion to intention. Likewise, verbal delivery, intonation, and pacing strongly impact how a message is received. However, we must understand that although some aspects of body language, facial expression, and intonation are common across cultures, other aspects are culturally constructed—which helps us more accurately read the expressions of others and make our own communication more effective. Body language, facial expression, and intonation are a key component of communication, so one should learn to use them effectively.

## Worked example

You are giving an important presentation that has the potential to bring you considerable professional rewards. Having spent hours preparing the script, you stand in front of a practice audience and freeze. You speak much too fast, struggle to breathe, avoid making eye contact with the audience, and tense up your body. You realize that you must set aside time to practice delivering the speech with the right pacing, intonation, and deliberate pauses, which will help you to feel more relaxed and convey the right level of certainty and confidence to the audience. You run through your presentation a few more times, deliberately thinking about how to best deliver your speech, and the presentation is a big hit.

> **Footnote:** This student achieved a strong demonstration of #expression by recognizing how to modulate their body language and vocal delivery with self-knowledge and practice.

## Is it this HC?

Is #expression the right HC? If the answer to the following questions is yes, #expression could be useful:

- Are you giving an oral speech or presentation?

- Are you presenting yourself in front of an audience?

- Are you thinking about how nonverbal communication can enhance your work?

- Are you analyzing how a creator has expressed themselves or represents someone else's expressions through their work?

Depending on the work product, there might be other HCs to consider ….

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#professionalism](professionalism.md) | identifies and utilizes field-specific norms. you could connect #expression with #professionalism insofar as choices you make about which expressions you use could be based on your understanding of what would be credible and appropriate in a specific professional context. |
| [#audience](audience.md) | identifies and tailors the message of communication to the work's intended audience. in nonverbal communication, applying #audience will increase the effectiveness of your #expression. |
| [#persuasion](persuasion.md) | craft and interpret communications that move audiences to do or think something. effective use of #expression can elevate persuasive communication. |
| [#emotionaliq](emotionaliq.md) | use emotional intelligence to interact effectively. #emotionaliq can be a valuable tool to help regulate your expression or interpret others' expressions. |
| [#communicationdesign](communicationdesign.md) | apply principles of perception and cognition in oral and multimedia presentations and design. #communicationdesign focuses on text-based presentation of ideas, while #expression is applied to communication insofar as it is embodied. |
| [#connotation](connotation.md) | focuses on the implied meanings of words, tone, and style in a communication; here, the “tone” refers to the overall attitude of the work, which is not the same as “intonation” in verbal #expression. |

## Self-study Q&A (4 questions)

**Q1. What expression elements could you use to elevate your nonverbal communication?**

(Note that this list is not exhaustive)

- Verbal delivery: your intonation, pacing, volume, pitch, rate, and pauses all carry a meaning that elevates your message. Using a slower pace, low pitch, and intentional pauses tend to make you seem confident and knowledgeable to your audience.

- Facial expressions: the position of your eyebrows, lips, and eyes can convey emotion and meaning, changing how your message is interpreted and informing the audience how they are supposed to feel. Speaking on certain topics will feel unnatural or uncaring without appropriate facial expressions.

- Body language: hand gestures, foot stance, and posture are some aspects of body language to remember when expressing yourself. When you use body language to take up more space - animated gestures, tall posture, and wide stance - you emanate confidence and authority. If your body language is constrained and you seem to occupy as little space as possible, you come off as nervous and unqualified.

**Q2. How should you decide to apply #medium or #expression when interpreting a work of art?**

As a general rule of thumb, #medium provides an opportunity for a deeper analysis and exploration of the work’s message in the context of the medium employed. However, #expression can be a helpful complement if you analyze how an artwork element portrays aspects of embodied expression. For example, if you are studying a sculpture of a human, you could apply #medium or #expression, depending on assignment priorities. Your #expression application should focus on whether the sculpture’s body positioning and facial expressions adequately portray a particular emotion. This application could then complement the #medium application, which might explore things like material, form, style, color, light, and how those aspects of the sculpture impact the artwork’s message.

**Q3. How could you best use #expression in class?**

When speaking in class, you should know how you express yourself. Ensure that your verbal delivery, facial expressions, and body language align with the topic in discussion. You must present yourself with an appropriate level of confidence: a lack of confidence erodes credibility, while overconfidence comes off as smug and untrustworthy. If you want to be listened to in a long class, you may want to animate your facial expressions more than usual while keeping your verbal delivery well-paced and clear. However, #expression is also relevant when you are in the listening position. Active eyes, focused facial expressions, and strong posture indicate that you actively listen to your peers. How you express yourself as a listener will make you a more respectful peer, friend, and partner.

**Q4. How can you use #expression to interpret expressive communication from a cultural context you are unfamiliar with?**

Educating yourself on others' cultural norms and everyday expressions is essential to understand the nonverbal communication around you. You must recognize that you are in a cultural context that differs from yours. Then, when you have the opportunity, you should research, observe, and inquire about expressive norms. 

- First, research your new context: ask yourself what cultural norms prevail and how the common expressions stem from those norms. 

- Then observe the world around you. Notice how people tend to greet each other and interact; you may be shocked by the power of observation. 

- Then, ask the people around you to help clarify confusion about how you should express yourself and interpret others’ expressions in this context.

## Guided reflection (proficiency checklist)

1. Have you identified salient nonverbal communication effects, and described the techniques used to achieve those effects (if they were intentional)?
2. Have you explained how the effects of expression affect the overall meaning of the presentation, conversation, or other work?
3. Have you created a prospective plan for applying #expression before presenting your work?
4. Have you identified specific examples of #expression applications in your work?
5. Have you explained those examples in detail and justified why you chose them?
6. Do the expressive elements you used add value to your work? Have you explained how?
7. Have you considered alternate ways of applying #expression to ensure your application is the most effective?

## Common pitfalls

1. The application did not plan how to use #expression but instead reflected on what elements of #expression were met by chance.
2. The application identifies elements of #expression without pointing out specific examples.
3. Specific examples of #expression are identified, but particular choices are not justified.
4. The application misuses a particular expression based on a lack of cultural awareness.
5. The application is confined to gestures, facial expressions, and voice modulation when other notable aspects of #expression, such as clothing, cosmetics, rituals, and positioning could have been used.
6. The application tags #expression when no embodied communication was used. This often happens because #expression was confused with other nonverbal communication HCs like #medium and #communicationdesign.
7. The application overuses hesitations/qualifiers (e.g., 'like') with no clear purpose or justification.
8. The application confuses ‘tone’ in writing, which refers to word choice and connotation, with ‘intonation,’ a non-verbal vocal element related to pitch and emphasis.

## Applying the HC at Minerva

1. In class, #expression is significant. In small classes, everyone can see the faces of their peers, and each person's expression seriously impacts the class environment. Showing up with an enthusiastic expression and mindset lets you get the most out of class. Facial expressions can encourage peers to help promote positive discussions or undermine discussions by conveying a lack of interest in what others say. Remember that you’re constantly communicating when you are on camera – You can improve your application of #expression by doing so thoughtfully and with purpose.
2. In a recorded presentation, you should always be aware of your expression. When presentations are recorded, every little expression can be rerun and analyzed. Looking engaged is essential, not just for the speaker's benefit but also to maximize your time and learn thoroughly. The pace of your speech and intonation are crucial to consider when trying to convey your ideas clearly and persuasively. Strong applications of #expression typically involve recording drafts of your work, watching them and reviewing them for elements of expressive communication (possibly with a peer), and then re-recording them to reflect improvements.
3. In different concentrations, norms of #expression may differ. This tends to result from field-specific #professionalism norms, and you can thoughtfully apply these two HCs in tandem if you carefully explain how the choices you make address the priorities of both HCs. For example, for a business pitch, you may express yourself through animated facial expressions and large hand gestures as a #expression choice that you justify through thoughtful application of #professionalism, based on research you conduct by watching other business pitches that are deemed to be highly effective in their professional context.

## Applying the HC outside Minerva

1. For many people, clothes are a form of expression. Fashion is an art form as well as a daily practice. When thinking of fashion as an application of #expression, it is essential to distinguish the application from #medium. There will likely be some overlap between applications. However, if #expression is the focus, the clothes should be seen through embodied communication. Ask yourself how this piece interacts with my body language to convey an emotion or vibe – we often find it fun to express ourselves through style!
2. When caring for pets, we commonly rely on facial expressions, body language, and tone of voice to convey positive and corrective messages. Through observation, education, and trial and error, we can learn to improve our communication across species to help connect more effectively with pets and other animals we encounter.

## Key resources

1. Treasure, J. (2014). How to speak so that people want to listen | Julian Treasure. On YouTube. https://www.youtube.com/watch?v=eIho2S0ZahI&feature=youtu.be
- This is a valuable resource for advice on delivery styles to avoid when presenting.
2. Stanford University. (2021). Tips for Presenting like a Pro: Body Language. Www.youtube.com. https://www.youtube.com/watch?v=oN9keOMdsaQ
- This Standford video helps develop our awareness of body language as a tool for expression rather than being overly prescriptive with particular gestures and facial expressions. Use this to help you think about #expression and how you might want to use it as a communicative tool.
3. Busque, S. (2022) Non-Verbal Communication: Expressing Yourself beyond Words. https://www.agendrix.com/blog/nonverbal-communication
- This short entry provides a clear synthesis of several longer accounts of non-verbal communication, helping you quickly identify areas of focus and improvement, including a section on more subtle nonverbal cues.


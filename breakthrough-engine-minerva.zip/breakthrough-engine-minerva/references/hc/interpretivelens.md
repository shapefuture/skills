# #interpretivelens — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/interpretivelens/](https://my.minerva.edu/academics/hc-resources/hc-handbook/interpretivelens/)
> **Habit of Mind** · Cornerstone course: Multimodal Communications · Competency: Thinking Critically → Evaluating claims
> Taught in: Multimodal Communications | Semester One · Unit: Close Reading
> Big Question: How does language shape and represent reality?

## Definition

**#interpretivelens** — Be mindful of how prior experiences, expectations, and judgments affect inferences drawn from different forms of communication and react accordingly.

> **Pitch:** We can only appreciate the perspectives of ourselves and others when we understand how our past shapes our viewpoints.

Being open-minded requires being receptive to new ideas, even when they might conflict with your beliefs, worldview, or assumptions. We need to learn to recognize the effects of our prior experiences and expectations, and try to see the same material from different perspectives. One should consider relevant evidence and arguments and be receptive to new ideas and alternative solutions. The information in messages is not always what one expects or hopes to receive and thus one must carefully consider what actually is being communicated—not just what one anticipates.

## Worked example

Your teacher assigns a paper on impressionist art. You go to a museum with the intention of observing a Van Gogh painting and critiquing it for the purposes of the assignment. You have never seen impressionist art before, but you have a friend who loves it--unfortunately, that friend and you are in a slight argument, and you recognize that those negative emotions are affecting the way you view the painting. You aren’t able to pay close attention to its compositional features because you cannot take your mind off of your friend and the difficulty you two are having lately--the reds in the painting only make you think of anger, and the blues make you think of the melancholy feelings you are currently harboring towards your friendship. When writing your paper, you acknowledge the first impression you had of the painting, but choose to expand your analysis by coming back on a different day when you are feeling better. This allows you to discuss the differences in interpretation and extract richer conclusions about how impressionist techniques communicate feelings.

> **Footnote:** A personal experience that had the potential to affect the interpretation of the painting was identified, and you ensured that your understanding of--and proper critique of--the work would not be hindered by this experience/negative emotion.

## Is it this HC?

Is #interpretivelens the right HC? If the answer to the following questions is yes, #interpretivelens could be useful:

- Are you analyzing your own or another person’s unique perspective?

- Are you referencing how past experiences, expectations, or purposes impacted your interpretation of a communication?

- Are you approaching a work or communication with an open mind, being mindful of your biases?

Depending on the work product, there might be other HCs to consider. ….

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#context](context.md) | identifies appropriate background information and cultural influence to situate a work in its relevant context; apply #context, not #interpretivelens, when arguing that another person’s actions or views are shared by their social or historical context. |
| [#selfawareness](selfawareness.md) | identifies and monitors one’s strengths and weaknesses to mitigate behaviors and habits that impair effective performance; applying this HC could increase your understanding of your #interpretivelens. |
| [#responsibility](responsibility.md) | follows through on commitments, is proactive, and takes appropriate responsibility; often, you are responsible for being aware of your #interpretivelens when making decisions and completing work. |
| [#expression](expression.md) | interprets, evaluates, and utilizes nonverbal communication; your #interpretivelens impacts how you express yourself and understand or view the expressions of others. |
| [#emotionaliq](emotionaliq.md) | uses emotional intelligence to interact effectively; an application of #emotionaliq can complement #interpretivelens and empower you to interact effectively with different groups of people. |
| [#biasidentification](biasidentification.md), [#biasmitigation](biasmitigation.md) | these bias HCs focus on identifying and mitigating cognitive biases that result from psychological mechanisms or use of heuristics. This connects with #interpretivelens because it’s possible that cognitive biases can stem from one’s prior personal experiences or expectations. However, applying #interpretivelens to evaluate how one's past shapes their perspectives does not always imply an associated cognitive bias. |

## Self-study Q&A (6 questions)

**Q1. How can we determine whether #interpretivelens or #context should be applied?**

Both of these HCs relate to how environments shape interpretation. The key difference is that #interpretivelens focuses on the individual level, and #context focuses on the group's cultural level. Therefore, #interpretivelens analyzes how personal experiences, expectations, and purposes impact one’s own or another’s interpretation, while #context analyzes how cultural norms and values impact interpretation and interaction. If you are unsure about which applies best, check in with your professor!

**Q2. What biases may be particularly related to your #interpretivelens?**

(Note that this list is non-exhaustive)

- Representativeness Bias: This bias is rooted in your personal surroundings and prevailing stereotypes within your culture. This bias tends to confuse the majority with the universal. For example, if you join a discussion about a local criminal and ask, “What do you think he will do next?” you are probably falling prey to the representativeness bias. The conversation had nothing to do with gender identity, yet based on your previous experiences and cultural stereotypes, you made an assumption. If you had recently encountered a criminal of different gender, or the cultural stereotype was not present, perhaps you would have interpreted the information differently.

- Emotional Bias: Often, this bias is rooted in previous experiences or expectations. Perhaps you just had a stressful test and feel concerned about your performance. Then you go on a walk with friends but can not seem to have fun, and your dreariness brings down the group's energy. Your friends ask you if something is wrong, and you get defensive. When you get home, you wonder why you thought the walk was a good idea. The negative emotions carried over from the test to your walk with friends, and you could not understand that your #interpretivelens was being affected by emotional bias while your friends were not experiencing that bias.

- Confirmation Bias: People tend to look for confirming evidence for their pre-existing beliefs, which are deep-rooted in their personal experiences and surroundings. Therefore, if you have grown up in an anti-vax household, you are likely to be anti-vax and have a confirmation bias when searching for information about vaccination, overwhelming yourself with anti-vax articles even though they go against the common scientific consensus and are easily disproven.

**Q3. How to know when to apply #biasidentification/#biasmitigation or #interpretivelens?**

These HCs are often interconnected. However, they serve different purposes. With #biasidentification, a specific instance of bias should be recognized, described, and explained, focusing on the cognitive blindness that bias caused and the impact of that blindness. With #biasmitigation, a particular bias should have already been identified, and a technique to mitigate the bias should be explained in detail and backed up with evidence that supports its effectiveness. With #interpretivelens, a bias may or may not be identified, but an instance of a certain interpretation will be recognized and connected back to a previous experience, expectation, or purpose, and the connection will be explained. Notice that it’s possible for cognitive biases (that can be evaluated with the #bias HCs) to stem from one’s prior personal experiences or expectations. However, applying #interpretivelens to evaluate how one's past shapes their perspectives does not always imply an associated cognitive bias.

**Q4. How can one practice open-mindedness and widen their #interpretivelens?**

Open-mindedness is a characteristic we should all strive for. To practice open-mindedness, one must frequently seek to understand perspectives outside their own. This can be done by brainstorming what another person may feel to try to put yourself in their shoes or otherwise “take” their perspective. However, perspective-taking is often ineffective because it falls victim to many biases. Whenever possible, it is better to practice perspective-getting, where you absorb information straight from a source whose perspective differs from yours, whether this is a media article, research paper, or someone else’s words.

**Q5. How can one stay true to their opinions while nurturing an open mind?**

Strong opinions and an open mind are possible; the two are not mutually exclusive. The idea is not to be on all sides but to understand how your perspective is limited and shaped by your past and to appreciate the value of learning from people who have had different experiences. Be a listener, and decide what to do with the information you receive. It can be hard to listen to people with opinions that differ from yours, but a respectful argument is better than no discussion. Open-mindedness is not mindlessly believing what everyone has to say but constantly absorbing new information from new sources to evolve your opinions.

**Q6. Reflect on a recent disagreement or misunderstanding you had with someone. How might your personal interpretive lens (shaped by your experiences, culture, or beliefs) have influenced your understanding of the situation? What alternative interpretations could be considered when viewing the situation through the other person's interpretive lens?**

Here’s one possible reflection. Take some time to think about your own! During a recent project meeting, I pushed for an early deadline because I work in a fast-paced startup where getting things done quickly is often the most important thing. This went against the view of a coworker who came from a traditional business background that values careful planning and risk assessment. From my point of view, their hesitancy was seen as a caution, and from theirs, my haste meant I might miss important details. When I thought about this disagreement, I realized how important it was to combine our approaches and find a middle ground that meets both the need for quick progress and the need for thoroughness to ensure quality results. This shows how different points of view can work together to make a project more successful.

## Guided reflection (proficiency checklist)

1. Have you effectively explained how prior experiences, expectations, or purposes affect your own or other people’s interpretations of textual, visual, or aural communications?
2. Have you analyzed interactions among experiences, expectations, and purposes?
3. Have you effectively evaluated an alternative analysis of how prior experiences, expectations, and purposes affect interpretation?
4. Have you described how a particular previous experience informs a specific act of interpretation?

## Common pitfalls

1. The application fails to identify or describe the shaping experiences, expectations, or purposes that impacted the interpretation.
2. The application identifies the shaping factors of the interpretation but does not explain how those factors lead to a particular interpretation.
3. The application does not consider alternative analyses, making the analysis incomplete.
4. The application misapplies #interpretivelens when another HC could have been applied. For example, the application identifies cognitive biases but tags #interpretivelens instead of #biasidentification or explains an author’s historical background and tags #interpretivelens instead of #context.

## Applying the HC at Minerva

1. In every class, you will interpret your classmates’ and professor’s ideas and communicate your thoughts. Your individual experiences, expectations, and purposes will shape this communication, and you must consciously work to recognize when a disagreement arises from different #interpretivelens. People often express themselves through different words, gestures, and examples but mean the same thing. Determining when your #interpretivelens is inhibiting your understanding and actively striving for an open mind and broader #interpretivelens will elevate your classroom experience
2. Before coming to Minerva, we all received education on varying topics, and some parts of this education were particularly impactful. For example, imagine that you took a Latin Philosophy class that changed your perspective on feelings. In this class, you discussed how society labels certain feelings as “good” and others as “bad,” which creates the idea that “happiness” is the absence of negative feelings. “Happiness,” when defined this way, is an unachievable goal that people obsess over nonetheless. As a result, people are afraid to feel negative emotions and avoid them by dangerous and unhealthy means rather than letting themselves feel how their body needs them. Since this was particularly impactful, you might draw from these ideas in a creative assignment where you design a dystopian world. In this world, you depict how the seemingly utopian vision of a town that embodies modern “happiness” is not a utopia at all. You then tag #interpretivelens and explain how that class changed how you thought about happiness and how this changed perception influenced the world you created.

## Applying the HC outside Minerva

1. You will use this HC in your everyday life and relationships. So often, your interpretation of interactions will differ from those around you based on your unique #interpretivelens. Even though you can not understand everyone’s perspective, it is helpful to acknowledge that views differ and avoid assuming that your feelings are universal.
2. Your #interpretivelens plays a role in social media too. Your Instagram algorithm is likely based on your unique #interpretivelens, constantly feeding you products you like and information you already agree with. This algorithmic optimization to your interests is problematic because it works to narrow your #interpretivelens and satisfy your confirmation bias. If you are working toward a more open mind, you must actively look for information you disagree with or would not otherwise be exposed to. This way, you can use social media like Instagram to widen your #interpretivelens rather than inhibit it.

## Key resources

1. Resnick, B. (2019, August 8). How desire can warp our view of the world. Vox. https://www.vox.com/science-and-health/2019/8/8/20706126/motivated-perception-psychology
- This article discusses the idea of motivated perception--seeing what we want to see. It argues that much of our perceptual experience depends upon our expectations, ideas, experiences, and desires.
2. Jarrett, C. (2021). How to foster “shoshin” | Psyche Guides. Psyche. https://psyche.co/guides/how-to-cultivate-shoshin-or-a-beginners-mind
- This resource introduces shoshin, a practice that values having a beginner’s mind. By practicing openness, eagerness, and a lack of preconceptions when approaching a subject or experience, one can decrease gaps in their #interpretivelens.


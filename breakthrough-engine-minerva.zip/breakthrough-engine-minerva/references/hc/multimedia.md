# #multimedia — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/multimedia/](https://my.minerva.edu/academics/hc-resources/hc-handbook/multimedia/)
> **Foundational Concept** · Cornerstone course: Multimodal Communications · Competency: Communicating Effectively → Using nonverbal communication
> Taught in: Multimodal Communication | Semester Two · Unit: Multimedia
> Big Question: How is technology changing communication?

## Definition

**#multimedia** — Analyze or craft communications with layered modalities.

> **Pitch:** Synergizing media rule! Interfering media drool!

Multimedia works incorporate several communication modalities in order to convey meaning. Visual, aural, spoken, and written modalities may be combined in different ways, and each combination conveys a message differently. To draw inferences about and create multimedia communication, one must understand how these different modalities complement, undermine, or intensify each other.

## Worked example

You are watching television, and a commercial begins with a scene of a family having fun at a well-lit party while lively music plays in the background, setting a comfortable and fun atmosphere. The family’s smiles make you comfortable due to the theory of emotional contagion, which describes a phenomenon where one individual’s emotions have the ability of inducing the same emotional experience in others. The family leaves the party and gets in a car to drive home. A few seconds after the mother starts driving, the music suddenly turns ominous and the lights in the scene dim. You feel your heart-rate increase as you start getting unsettled due to the sudden change in environment, and realize that the darkness makes it hard to see exactly what is going on. The music stops as the screen turns black and you can hear the sound of a crash and screams. Sorrowful music plays, and the scene is now of an upturned car surrounded by debris. The scene changes again, showing the mother drinking beer with other adults earlier at the party. Red, bold text appears that says, “Think about your family. Don’t drive under the influence.” and the text fades in the silence. You are impressed by how the commercial manages to synchronize lighting and music choice, as well as utilize visual and contextual information to convey different moods: a calm one at first and a tragic one at the end.

> **Footnote:** The commercial effectively combines different types of media to create different moods, including a more festive, happy mood (through using well-lit environments with light-hearted music and the visual of a smiling family) and a more ominous, tragic mood (with less light, sorrowful music, and sound effects alluding to an accident). Additionally, the lack of music with the bold text also works to create an impact on the audience, highlighting the message being transmitted.

## Is it this HC?

Is #multimedia the right HC? If the answer to the following questions is yes, #multimedia could be useful:

- Are you blending multiple mediums together to illustrate your message?

- Would incorporating another medium elevate your work product?

- Are you attempting to communicate a message that is hard to squish into a single medium?

Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#medium](medium.md) | analyzes and utilizes elements of a single medium at the level of form and structure. |
| [#persuasion](persuasion.md) | discusses the design and execution of an argument. considers different theories and effects at play, like the assimilation effect from social judgment theory. |
| [#context](context.md) | situates a work in its appropriate context for analysis or argumentation. |
| [#communicationdesign](communicationdesign.md) | uses principles of communication design to connect with the intended audience. |
| [#emergentproperties](emergentproperties.md) | explains how the interactions between multiple parts of a complex system give rise to an emergent property. |

## Self-study Q&A (6 questions)

**Q1. What are the differences between the terms medium, medium element, and multimedia?**

Here are some possible explanations:

- Medium is a single form of expression used to communicate a message—such as music, painting, or poetry.
- Example: A watercolor painting is a work in the medium of visual art.

- Medium element is a specific feature or technique within a medium that helps shape meaning.
- Example: In the painting, color choice or brushstroke style are medium elements.

- Multimedia refers to a work that blends multiple mediums—like sound, visuals, and text—into one cohesive experience.
- Example: A documentary film is a multimedia work because it combines spoken narration (language), background music (music), and moving visuals (visual art/film).

**Q2. How can you break a multimedia analysis into a step-by-step process?**

Here’s an example approach:
- Identify all the mediums involved. List the distinct mediums used in the work (e.g., visuals, sound, text, movement).

- Select one medium and describe a specific choice. Focus on a particular decision within that medium (e.g., use of color, tempo, font) and categorize it using medium-specific language.

- Analyze the impact of that choice. Explain how it contributes to the work’s tone, message, or emotional effect.

- Repeat Steps 2–3 for each additional medium. Continue analyzing each medium separately, identifying a specific choice and its impact.

- Evaluate how the mediums interact. Discuss how the different mediums work together: Do they enhance each other? Create contrast? Undermine one another? You can imagine how the work would feel with one medium removed or changed.

- Conclude with the overall multimedia effect. Summarize how the combination of mediums creates meaning in a way that no single medium could achieve alone.

**Q3. What are some key multimedia techniques used in film to keep an eye out for?**

Multimedia techniques in film combine visual, auditory, and editorial elements to shape meaning, emotion, and rhythm. Some core techniques to pay attention to include:
- Cuts and Transitions. These are edits that connect shots and scenes. They affect pacing and continuity. For example, jump cuts create urgency, while dissolves signal the passage of time.

- Camera Movement. Techniques like pans, tilts, dolly shots, and handheld filming influence how viewers perceive space, emotion, and perspective.

- Sound Design. This includes diegetic sounds (within the story world) and non-diegetic sounds (like music and voiceovers). Sound bridges can smooth transitions or create contrast.

- Mise-en-scène refers to everything arranged in front of the camera, including setting, lighting, costumes, props, and actor placement. It shapes tone, character, and narrative subtext.

**Q4. When critiquing #multimedia, what details should you pay attention to?**

Multimedia pieces are meant to tell a message, so the first step of critiquing such a work is to find out what that message is. Then you can determine how effectively you believe the designer was able to portray that message by combining different mediums and shaping the interaction between those mediums. Remember, if a piece of multimedia work confuses you, return to its message, perhaps the artist wanted viewers to feel confusion and uneasiness in the presence of the work.

**Q5. How can one use #multimedia to create a sense of unity?**

A work that embodies multiple mediums can create unity by aligning all mediums to a certain message. For example, in a heavy metal music video a sense of unity could be created by pairing the intense and powerful sounds with visuals of the band playing aggressively pieced together with sharp transitions. In this way, the audio, visuals, and shots seem in harmony with each other, creating a unified feeling of intensity.

**Q6. How can one use #multimedia to create contrast?**

To create contrast in multimedia work, you should have one or more mediums that seem to go against each other. For example, if you were making a heavy metal music video that featured band members drinking tea and dancing in a dainty manner with smooth transitions between clips. This would create a clear contrast between the underlying music and the visuals. It may fight against the stereotype that heavy metal lovers are intense and aggressive, highlighting a clear message through contracting mediums.

## Guided reflection (proficiency checklist)

1. Does the application create or critique a work that employs multiple different media?
2. Does the application utilize different media to create a holistic deeper meaning? 
- Alternatively: do the different media in the piece conflict with each other in a way that undermines an intended deeper meaning?
3. Is the use of multimedia described and explained clearly?
4. Does the application mention how the different media conflict or complement each other?

## Common pitfalls

1. The application lays claim to multimedia when only one medium was used or analyzed.
2. The application uses different media, but the multimedia result is disjointed or confusing.
3. The application describes a multimedia work but fails to explain how the different media interact—whether they complement, contrast, or even conflict—and why.
4. The application only completes part of the analysis—either describing medium choices without interpreting them, or analyzing one medium without addressing others.
5. The application assumes the media work well together without analyzing or explaining how they do.

## Applying the HC at Minerva

1. You make a short film to convince people to support San Francisco’s street artists. In this film, you capture how you feel in the presence of street art by filming many clips of you interacting with street artists around the city. When editing these clips together, you get creative with the sound levels, colors, and transitions between clips. To create a contrast between how the audience feels between scenes with and without street art you make some deliberate choices. In scenes without street art, you lower the saturation of the clips, dulling the colors. You also increase the decibels of the ambient nose, making the city sound busy and anxious. Finally, you decide not to include transitions so that one scene merges with the next without inherent flow. On the other hand, in scenes featuring street art, you up the saturation of visuals, decrease ambient noise, and use transitions to create a smooth and natural change from one clip to the next. At the end of the short film, you present a written call to action that says: support street artists, they bring our cities to life. Since the short film does not feature writing before this point, this phrase catches the audience’s attention and clearly states your goal.
2. You have determined a new medicine helps reduce inflammation in joints with tendonitis, however, you expect most doctors will not understand how it works and why it is a better option than traditional tendonitis treatments without a clear explanation. Therefore, you create an animation of the medicine, using multimedia principles to ensure the animation is as informative as possible. You ensure the colors of the animation add to the viewer's understanding of the medicinal process by deliberately illustrating the pill and its anti-inflammatory growth factor contents in a bright green color because green symbolizes health and stands out from the rest of the animation. You also include  informative background noise. At first, the sound in the background is dissonant because the tendonitis is present and causing pain. Then upbeat sound effects are used to simulate the sound of the pill contents dispersing throughout the bloodstream, attaching to the inflamed tissue. Finally, the background sound turns melodic as the pill increases growth and soothes affected tissues, effectively ridding the patient of tendonitis. You use this animation to pitch your medicine to doctors who then prescribe it to patients.

## Applying the HC outside Minerva

1. You realize you suddenly feel on edge and anticipate something bad is going to happen in the thriller you are watching with friends. The visual scene has not changed, however, you expect the feeling to be a product of the film's effective multimedia communication. So, you listen closely and realize the background music has changed to an ominous chord in b minor and is slowly getting louder, cultivating your uneasiness.
2. You make a TikTok video to promote your small business by utilizing transitions that keep viewers engaged, using both audio and text to share your message, and placing trending audio behind your narration to get further reach. This careful combination of multimedia elements work together to get a larger reach than usual, and your orders increase dramatically.

## Key resources

1. Minerva Academic Team. (2021). HC Guide for Visuals. https://my.minerva.edu/academics/hc-resources/additional-resources/
- Check this out as an additional resource for successful application of #multimedia and other HCs related to visual communication.
2. Ignite. (2021, March 3). How to analyse a film - cinematic techniques. YouTube. https://www.youtube.com/watch?v=c-LPwanZv9A
- This resource explains how to analyze film by highlighting the basic language with which to analyze films. Note how the different film techniques surveyed in the video fall under the subcategories of #medium (literary, visual, musical).
3. RocketJump Film School. (2016). Cuts & Transitions 101 [YouTube Video]. In YouTube. https://www.youtube.com/watch?v=OAH0MoAv2CI
- Check out this resource for a closer look at different types of cuts and transitions used in multimedia works.
4. Now You See It. (2015). How Film Scores Play with Our Brains. In YouTube. https://www.youtube.com/watch?v=bCpYbSz1KqE
- This video highlights how film scores create interesting multimedia effects.


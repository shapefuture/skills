# #ethicalconsiderations — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/ethicalconsiderations/](https://my.minerva.edu/academics/hc-resources/hc-handbook/ethicalconsiderations/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Resolving ethical problems
> Taught in: Complex Systems | Semester Two · Unit: Prudence and Effective Interactions
> Big Question: How can we enable and support diversity while eliminating domination?

## Definition

**#ethicalconsiderations** — Identify ethical considerations relevant to a situation or decision and explain them by appealing to values and/or ethical theory.

> **Pitch:** We can only act rightly if we understand what is at stake.

Many decisions involve ethical considerations, even if those aren’t apparent at first glance. To act ethically, we must first recognize the ethical dimensions of our actions, and that, in turn, may involve identifying relevant ethical values or theories and explaining how they apply to the situation at hand. Ethical values define core commitments that form the foundation of an ethical outlook, which ascribe value to ideas like equality, freedom, life, security, happiness, privacy, and so forth. A commitment to ethical values gives rise to ethical considerations that may include, for example, people’s rights, duties, welfare, intentions, or inclinations. Ethical theories account for hierarchies of values and ways to determine what we ought to do, given those values, also known as principles. Such theories include, for example, deontology, utilitarianism, virtue ethics, care ethics, Buddhist ethics, Confucianism, and so on. Ethical theories could be useful to draw on when articulating ethical considerations though it is not necessary to have a complete theory in order to articulate and justify ethical considerations.

## Worked example

After graduation with a double major in arts and humanities and computer science, you find a great job in a small but exciting game design studio. Your company’s most successful game is a puzzle-like competitive murder mystery game called WhoSolvedItFirst that has hundreds of people try to solve a puzzle mystery in real time before others do. Recently the game went viral following a clip of a TikTok influencer and everyone has been working nights to keep up with the demand. The CEO has called a meeting to brainstorm ways to reduce workload while maintaining the success. The main goal is to monetize the game in a sustainable way. In the meeting, you’re very impressed with the creative ideas presented. When it’s your turn, near the end, you suddenly ask everyone - does it matter that our users are mostly 11-13 years old? Like many other plans, yours relies heavily on many microtransactions (many opportunities for buying in-game features for small amounts of money) and that now makes you uneasy. Your question stirred a lively discussion as some say children users require special protections while others said that microtransactions are manipulative even when users are adults. The CEO says that a core value of the company is to make products that celebrate joy and creativity rather than addiction and frustration, and tasks you to research the ethical considerations of microtransactions. In the memo you’re preparing for the CEO, you consider the different issues with microtransactions in general and those that are specific to children users. In general, microtransactions are accused of being manipulative - they ‘trick’ people into buying things they wouldn’t want or didn’t really agree to. You summarize research on the psychology of impulse purchasing and the design tricks of deception called ‘dark patterns.’ You conclude that a key value is informed consent and that the company needs to decide what exactly that means. Turning to the issue of children, you find that children are particularly vulnerable to manipulations as well as claims that children under a certain age cannot at all give informed consent because their brain hasn’t yet fully developed. Relatedly, you find a host of issues relating to parental control. Some apps rely on features offered by the mobile device while others involve parents' permission directly. Summarizing this section of your memo you conclude that the key question is whether, and to what extent, kids’ consent is limited in its reach and specifically, what role should parents/guardians be required to play in the process of getting children’s consent.

> **Footnote:** This passage presents a context where the ethical dimensions of the decision at hand were not, at first, in the forefront of the discussion. The passage digs into various ethical concerns that have been raised regarding microtransactions, sorts them into different kinds of considerations, and traces each of them to the core value that motivates them.

## Is it this HC?

Is #ethicalconsiderations the right HC? If the answer to the following questions is yes, #ethicalconsiderations could be useful:

- Are you explaining why a situation or case raises ethical issues? 

- Are you explaining in which ways factors of that situation relate to moral values, rights, or responsibility?  

- Are you using a theory of morality to explain why those factors or features of this situation are ethically relevant? 

- Are you analyzing how the effects or cause of a decision might be ethically significant?

- Are you analyzing what specific situation features demand certain moral considerations and how this depends on our values?

However, depending on the focus of the work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#ethicaljudgment](ethicaljudgment.md) | Builds a case for one moral stance, addresses arguments from multiple sides, and justifies judgment. It is about determining what is right after identifying relevant #ethicalconsiderations. (At the end of the Self Study of the #ethicalcourage handbook, there’s a practice example that integrates all three ethics HCs and helps you distinguish the contribution of each one.) |
| [#ethicalcourage](ethicalcourage.md) | analyzes the costs of ethical decisions and how to face them. #ethicalconsiderations and #ethicaljudgment are usually applied beforehand to decide what is moral. The costs of ethical decisions also inform what ethical considerations you identify. (At the end of the Self Study of the #ethicalcourage handbook, there’s a practice example that integrates all three ethics HCs and helps you distinguish the contribution of each one.) |
| [#responsibility](responsibility.md) | Explains how to work diligently (in a team) by implementing accountability and communication strategies. Be careful! When establishing ethical responsibility, you are applying #ethicalconsiderations. |
| [#evidencebased](evidencebased.md) | Presents evidence in a way that supports an argument or analysis strongly. An ethical argument always needs normative evidence (theories, arguments), whereas scientific arguments use empirical evidence. |
| [#critique](critique.md) | Provides subtle interpretations of text and language. Often, you need this skill to interpret ethical theorists and improve the application to a specific situation. Also useful when contrasting different ethical views, defining a concept, or explaining an author's assumptions. |
| [#utility](utility.md) | Analyzes how humans use utility functions to compare outcomes. It is the empirical brother-theory of the philosophical theory of utilitarianism and is possibly useful when using a utilitarian lens. |

## Self-study Q&A (6 questions)

**Q1. What are the most common moral frameworks and what are their most important considerations?**

See the Markkula resource in the Key Resources Section for more information on the following frameworks:

Those that you have come across in your Cornerstone SS courses:

- Utilitarianism: the morality of actions is determined by the amount of good or harm that comes from it. One must seek to maximize utility.

- Rights approaches (such as Kantianism): morality is determined by whether rights are respected. You might use positive (you have a right to something) and negative (you have the right to be protected against something) rights.

- Virtue ethics: Goodness comes from cultivating virtues: good character traits that will, in turn, lead us to act morally. Virtues are habits promoted through self-discipline and through community values. We should develop virtues in ourselves and our communities. Aristotelian and Confucian ethical theories are two prominent examples of virtue ethical theories.

- Justice approaches: morality depends on whether people are rendered their due. This means that equals deserve to be treated equally and unequals unequally. For example, it is justice to make public space accessible to everyone, respecting people’s physical differences. Different forms of justice are distributive, retributive/corrective, restorative, procedural, and transitional justice.

Other frameworks often used:

- Common Good: morality depends on whether systems, environments, and institutions that are good for all humans are established and maintained. It is a holistic approach to ethics, arguing that goodness comes from the contribution to a larger system and cannot be reduced to the outcomes of just individual actions. Communitarian ethics, like Ubuntu ethics, apply a common good framework.

- Care Ethics: An originally feminist framework that places care at the center of ethics. Acting rightly means showing up for those we share important relationships within the ways that respect that person and the relationship. It acknowledges our dependency on other human beings and the importance of allowing emotions (like empathy and compassion) for ethical decision-making.

**Q2. What is the difference between consequentialist ethics and virtue ethics?**

Consequentialist frameworks try to decide what is good based on the consequences of our actions; utilitarianism is an example of such a framework. 
Virtue ethical frameworks try to establish what it is to have good character and argue that the goodness of an action comes from the ethical codes one is using.

**Q3. What is the difference between deontological and consequentialist ethics?**

According to Kantian ethical theory, often described as deontological, features in the act itself determine the rightness of an action. Did the person do what the motive of duty requires, and did they do it from the motive of duty? In other words, did a person do the right thing just because it’s the right thing to do? If so, that action has moral worth. According to Utilitarian ethical theories, famously defended by J.S. Mill, the rightness of an action is determined by whether the consequences of that action brought about the greatest good for the greatest number.

**Q4. In Minerva dormitories, all drugs (including alcohol) are forbidden. When students use such substances anyway, others might inform on them. There is a broader debate about whether such rules should exist in the first place. What are some areas here where ethics might play a role? Can you identify which ethical concepts are at stake?**

- Should alcohol be allowed in the dormitories?

- Right to Autonomy - students should have a right to decide how to lead their lives, even if it arguably damages them.

- Right to Privacy -  to enforce rules like that, students’ privacy is at stake, as staff and classmates check each other. Privacy is important to be respected.

- Common Good - alcohol arguably damages the community’s health and safety by exposing the group to risks associated with alcohol abuse. A safe and healthy environment is best for everyone’s learning, which is a crucial thing Minerva should focus on.

- Respect for culture/religion - alcohol is forbidden in some religions and looked down upon. Keeping those substances outside the common living spaces is a form of respect.

- The ethics of informing on someone.

- Care - you have an important relationship with classmates and student life staff. Informing on someone can break trust and damage those relationships. The fabric of the community is more important than individual differences and disagreements if the community is not in danger.

- Safety -you might have an ethical obligation to maximize the good for the group as a whole by violating a person’s trust if you worry that a person is posing a risk to the group, or you might have an obligation to help someone who is harming themselves through alcohol abuse by bringing that behavior to light.

- Desert - if rules are set, and someone breaks them, they deserve repercussions for breaking those rules. The rules are only fair if they are enforced equally.

**Q5. Do I have to tag all three #ethics HCs when I tag any one of them?**

No. Tagging all three (#ethicalconsiderations, #ethicaljudgment, and #ethicalcourage) would be a good idea only when you have the space to apply all three especially well in an assignment. You’ll often be asked to focus on some, but not all, of these HCs. For example, you might be asked to defend a position on universal basic income, in which case you should definitely apply #ethicaljudgment, and possibly #ethicalcourage (depending on how much background information you take for granted and assignment instructions). 

However, whenever applying #ethicalcourage, you have implicitly (or explicitly but shortly) decided what is ethically important (#ethicalconsiderations) and what action is the most ethically appropriate (#ethicaljudgment). 

Understanding how all three can be scaffolded effectively is important, even if you do not tag all three in one particular work. As a general rule of thumb, it’s a good idea to reflect on the central purpose of your assignment and tag those HCs that are most relevant and use the Guided Reflection below to check whether your application is complete. It’s also good to ask an instructor for advice about HC tagging priorities.

**Q6. How can #levelsofanalysis help you apply #ethicalconsiderations to moral frameworks like utilitarianism?**

Applying #levelsofanalysis can clarify how ethical concepts operate across multiple levels, how those levels interact, and where tensions between them might arise. For example, in utilitarianism, you might:

- At the individual level, consider how a decision affects a person’s well-being or happiness.

- At the group or societal level, examine how utility is measured, i.e., what is defined to make the group “better off”, and how that may inadvertently prioritize subsets of society (when applicable). 

- At the institutional level, analyse how laws and policies distribute benefits and burdens, and whether they treat people fairly when implementing utilitarian goals.

Using #levelsofanalysis strengthens the application of #ethicalconsiderations by helping you:

- Be clear about who is affected at each level and how - considering individuals, groups, and institutions.

- Identify tensions across levels. Pay attention to conflicts between levels (e.g., a rule that protects institutions but does not consider individual rights, or policies that maximize overall utility but leave some individuals significantly worse off).

- Evaluate whether outcomes are ethically justified, not just in aggregate, but also in how they are distributed and experienced by different populations and groups.

## Guided reflection (proficiency checklist)

1. Have you centered your analysis around one or more ethical concepts?
2. Have you clearly explained why certain concepts are relevant in the given context? Have you considered opposing concepts, where possible?
3. Have you connected the theory or concepts of morality to the context of your problem? / Have you discussed the implications of certain considerations to your context?
4. Have you explained how different ways of considering the problem lead to different analyses of what one should do?
5. If you applied one or more moral theories, have you given clear definitions of the concepts in those theories and applied those to your problem?

## Common pitfalls

1. Not clearly interpreting/defining an ethical concept, leading to confusing reasoning.
2. Listing relevant considerations without explaining what makes them (more) relevant (than others) in the given context.
3. Supporting the relevance of ethical considerations without presenting a normative (ethical theoretical) argument for including that consideration.
4. Not addressing the relationship between different concepts but analyzing them separately.
5. Simply explaining what different moral theories would have you do without explaining the essential concepts or differences behind them.
6. Confusing different ethical concepts or interpreting them without accounting for differentiating definitions.

## Applying the HC at Minerva

1. Business - Outlining what ethical considerations are relevant in any avenue of business is important for being a responsible business. For example, if your company has a data analysis component, you might think about privacy (or theories of autonomy), but also of identity.
2. Research - Especially when researching human participants, it is important to consider the ethical considerations of doing that research, such as privacy and confidentiality concerns. An important concept here is informed consent: the idea that participants must participate and be informed about the research voluntarily. There are stricter and less strict understandings of this. For example, letting participants tick off a box but offering them money for the research might not encourage or enable them to make a fully informed decision about participating. Other considerations are apparent in medical experiments when offering an experimental treatment to one group with a certain condition and not to another.
3. Social Sciences - Our social systems inform our worldviews and have a moral function. You might apply this HC on an assignment by explaining the importance of political institutions or actions based on ethical frameworks. There are many instances in which ethical concepts are relevant to dilemmas of social systems, from ideas about surveillance to the design of our economic systems. Applications of this HC in social sciences fields can get overly complicated if you try to address every possible angle. Instead, use #ethicalconsiderations first to define the most salient and useful ethical concepts to use in your reasoning. Constraining yourself to a specific part of the social system you are talking about might assure the deepest, most fruitful application.
4. Philosophy - In Ethical Theory, you’ll refer to a philosopher’s principles and arguments to justify your framing of a situation as particularly ethically weighty. But in the context of philosophical research and writing, you’ll likely spend more time on careful interpretation and critique than in other academic contexts. Ethicists are especially concerned with the careful definition, interpretation, and application of different sets of ethical values and arguments. Contrasting ethical views and describing nuanced interpretations and implications of an ethical theory you’re studying is a great way to use #ethicalconsiderations in a philosophy course. Though, remember that philosophy concerns itself with a much wider field of questions than ethics alone!
5. History - Ethics is relevant to many aspects of historical disciplines. When engaging in historical research and writing, you’ll consider your responsibilities to the living and the dead in terms of contributing to historical narratives, the ethical significance of revisionism when aiming to improve historical knowledge, and ethical concerns surrounding obtaining and using oral history. Moreover, what we consider a historical record and who is silenced in those records pose ethical questions about the relationships between historical research and power dynamics.

## Applying the HC outside Minerva

1. Politics: Political matters typically have ethical dimensions insofar as they involve ways of coordinating actions among a group of people in ways that reflect the decisions of some over others or that benefit some more than others, in the short-term or long-term. Understanding political issues and forming beliefs about them involves framing them in light of their ethical significance by asking who is most impacted by a policy, law, or enforcement mechanism or whether political actions improve conditions of society toward some accepted political values (like equality, fairness, liberty, compassion). Understanding what ethical frameworks and ideals people are driven by helps you understand politics more richly. It makes you more likely to make better decisions, contribute to a healthy debate, and/or act as an ethical leader.
2. Dealing with (#)differences:Different ethical considerations can lead to friction and disagreement in professional and personal contexts (does the relaxation of a holiday to the Amalfi coast justify the pollution it brings forth? Do you have the obligation as an employee to stand up when a manager abuses his/her power, even when it could have repercussions for you?)

## Key resources

1. Wisor, S. & Perry, T.J. (2022). Ethics and Justice in Complex Systems. Minerva Guide v2.5. https://docs.google.com/document/d/17S9I_ct0FuVqZWC3W42R4EqUW7vCklA0M-rSbgzgbX4/edit#
- This reading introduces some of the key concepts and approaches of ethical and political theory.
2. Sheskin, M., Perry, T. (2022, January 20). Ethical Courage - Minerva Guide. https://docs.google.com/document/d/1wA8ybnTXoAabp-AqsTR5p9cPr0EyMdyVLrhqe9nQfkE/edit?usp=sharing
- This guide argues for the necessity of #ethicalcourage after one has applied #ethicalconsiderations and #ethicaljudgment. It also explains the main features of the phenomenon that it’s difficult to make decisions we believe are right and how one can approach this problem.
3. Markkula Center for Applied Ethics. ‘Ethical Decision Making’. Accessed 10 July 2023. https://www.scu.edu/ethics/ethics-resources/ethical-decision-making/
- This article outlines various aspects of ethical decision-making and the main paradigms driving ethical decision-making. Use their “Making an Ethical Decision” step-by-step poster to inform your ethical decision. — [link](https://www.scu.edu/media/ethics-center/resources/making.pdf)
4. Beyond Point-and-Shoot Morality: Joshua Greene - Harvard Thinks Big, 2011. https://www.youtube.com/watch?v=sChdbsbTNxI
- An important video for all three ethics HCs. For #ethicalconsiderations, pay attention to how analyzing the moral considerations of a decision take effort. Point-and-shoot morality happens when we don’t take the time to analyze what factors are relevant beyond the obvious. Still, exactly this is necessary to come to a well-reasoned decision.
5. Elliot, Deni. ‘All Is Not Relative.’ Ethics Unwrapped. Accessed 4 July 2023. https://ethicsunwrapped.utexas.edu/video/all-is-not-relative
- This video explains the danger of moral relativism (thinking there is no way to make the right decision) but explains why considering different perspectives is still important! The key to #ethicalconsiderations is identifying what factors differentiate people’s different views on what is good or bad.

## Custom HC guides

- [Ethics and Justice in Complex Systems](https://docs.google.com/document/d/17S9I_ct0FuVqZWC3W42R4EqUW7vCklA0M-rSbgzgbX4/edit)
- [Ethical Courage](https://docs.google.com/document/d/1wA8ybnTXoAabp-AqsTR5p9cPr0EyMdyVLrhqe9nQfkE/edit)

# #ethicaljudgment — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/ethicaljudgment/](https://my.minerva.edu/academics/hc-resources/hc-handbook/ethicaljudgment/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Resolving ethical problems
> Taught in: Complex Systems | Semester Two · Unit: Prudence and Effective Interactions
> Big Question: How can we enable and support diversity while eliminating domination?

## Definition

**#ethicaljudgment** — Articulate and justify ethical positions, addressing opposing positions and counterarguments.

> **Pitch:** The best judgment comes from the battle of great ideas.

Ethical questions can be difficult to answer, and one may feel torn in the face of dilemmas that involve trade-offs of morally valuable outcomes, as the case when circumstances force us to choose between equality and freedom or privacy and security. To act ethically in the face of dilemmas, one must exercise ethical judgment by weighing the relevant ethical considerations in light of the situation, and arrive at a considered and justified position. Furthermore, exercising ethical judgment requires defending our considered position by considering and addressing alternatives and counter-arguments, as well as identifying courses of action that best advance that position in the given circumstances.

## Worked example

A mass shooting has recently taken place, and a suspect is in custody. He refuses to give his passwords for his laptop and cellphone, which authorities believe contain information relevant to this attack and other imminent ones. The suspect has shared videos where he threatens that other attacks are forthcoming. The government has asked the company that sells the phone and laptop to find a way to break into the phone. Still, the company is hesitant because it prides itself on prioritizing the security and privacy of its customers. 

On reflection, you decide to defend the position that the company should comply with the government’s demands, and you draw from ethical theoretical resources to support your argument. You choose to adopt the perspective of a utilitarian, who aims to produce the greatest good for the greatest number. As a consequentialist, utilitarians would argue that the ends justify the means, and that if we have good reason to believe that violations of this one person’s right to privacy could prevent catastrophic loss of life, then there would be strong ethical reasons to support policies or laws that enable a company to coordinate efforts with the government. 

You then pit two interpretations of utilitarianism against each other to test your argument. Utilitarians care about both long-term and short-term utility, so you develop a counterargument from another broadly utilitarian perspective that concludes the opposite – we shouldn’t override personal privacy rights in this case because doing so catalyzes long-term and far-reaching opportunities for governments to claim exceptions to rules of protection for consumer privacy. Releasing private data could erode public trust and confidence in the independence of businesses from government monitoring. 

Then you respond to this counterargument. While there are risks in taking either approach, you reason that this is an exceptional case because of the credible and catastrophic threat to life and property this person poses. You suggest that in such a case, a company should adopt a narrowly defined exception to its privacy clause and retain judgment in future cases, which it would evaluate individually. You conclude that the company should comply with the government’s demands in this case.

> **Footnote:** My defense of the ethical judgment that the company should comply with the government’s request, in this case, is anchored in normative reasoning generated from utilitarian ethical principles, carefully explored by weighing two different possible utilitarian lines of reasoning. I strengthened my judgment by responding to a credible counterargument, noting specific ways to mitigate the concerns raised in the counterargument.

## Is it this HC?

Is #ethicaljudgment the right HC? If the answer to the following questions is yes, #ethicaljudgment could be useful:

- Are you presenting an argument for or against something based on normative (ethical) reasoning and evidence? In other words, are you making the case that something - an action, a policy, a proposal - is ethically right/wrong? 

- Are you taking a clear stance on a moral dilemma with competing reasons to act a certain way?

- Are you addressing (a) counterargument(s) against an ethical claim you are defending?

- Are you explaining why your argument is convincing in an ethical dilemma or problem?

However, depending on the focus of the work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#ethicalconsiderations](ethicalconsiderations.md) | Explains which factors are morally significant and why, often by placing them within existing value systems or moral frameworks (such as a moral theory offered by a philosopher). #ethicalconsiderations helps us frame a dilemma or problem, while #ethicaljudgment takes the next step and defends a stance. (At the end of the Self Study of the #ethicalcourage handbook, there’s a practice example that integrates all three ethics HCs and helps you distinguish the contribution of each one.) |
| [#ethicalcourage](ethicalcourage.md) | Analyzes the costs or burdens of acting on ethical decisions and how to manage them. #ethicalconsiderations and #ethicaljudgment are applied when you explain and defend a particular decision about what you should do. In contrast, you use #ethicalcourage when addressing what it takes to act on those decisions.  (At the end of the Self Study of the #ethicalcourage handbook, there’s a practice example that integrates all three ethics HCs and helps you distinguish the contribution of each one.) |
| [#responsibility](responsibility.md) | Explains how you take personal responsibility for your commitments, communicate with team members about any impediments, and resolve them. When defending the prescriptive claims that one should act responsibly, then you should apply #ethicaljudgment to defend that claim. |
| [#evidencebased](evidencebased.md) | Presents evidence in a way that supports an argument or analysis strongly. See the HC Handbook guide for #evidencebased for ideas about using normative evidence to support normative (ethical) arguments. |
| [#audience](audience.md) | Tailors an ethical argument to an intended audience regarding language, presentation, arguments, evidence, etc. You will often convey ethical judgments to an #audience, and you might want to consider (counter)arguments they find convincing. |
| [#critique](critique.md) | Provides subtle interpretations of text and language, which may be helpful when defending your ethical judgment as an application of an existing ethical principle or system. #Critique may also be helpful when developing a counterargument to your position to the extent that you carefully contrast different ethical views, define a concept, or explain an author's assumptions. |
| [#utility](utility.md) | Analyzes how humans use utility functions to compare outcomes. It is the empirical brother-theory of the philosophical theory of utilitarianism and is possibly useful when using a utilitarian ethical lens. |

## Self-study Q&A (5 questions)

**Q1. 5 steps of making an ethical decision are 1) recognizing an ethical issue, 2) getting the facts, 3) evaluating alternative actions, 4) making a decision and “testing” it, 5) acting and reflecting on the outcome (see the Markkula resource below). Which step(s) is/are part of #ethicaljudgment?**

3 and 4. (although 1 and 2 are important too, they are not the focus of THIS HC)

The third step involves considering alternative actions or arguments is important to come to a well-justified conclusion.The fourth step reflects on the implications of an action and how the argument would play out, so to speak, in that context. This is important for consequentialist reasoning but also helps you build a convincing argument that addresses the unique challenges the context might provide. Imagining the responses to a decision might also inform you about what people agree or disagree with about that decision.

Steps one and two are also important to come to a good #ethicaljudgment but are more squarely aligned with applications of #ethicalconsiderations and #evidencebased. They pertain to building the normative framing and empirical evidence around the case. 

The fifth step is closely aligned with applications of #ethicalcourage.

**Q2. What could justify civil disobedience, such as blocking a road, by climate protestors if this causes inconvenience in the short term? (Tip: you might want to use one of the main frameworks from the Markkula resource in the Key Resources section.)**

A good argument should:

- establish the ethical values your judgment stems from.

- provide arguments for why the values lead to the judgment.

- pose and respond to a possible counterargument.

Two possible arguments include:

- Common Good: Thinking about the common good from a long-term perspective is important. Actions that uphold or improve environments or systems on which we all depend for our livelihood are ethically justifiable from this ethical lens, even if they cause some disruption in the process (1). Climate activists are addressing systemic issues with our economies and environment. These need to function properly to secure a safe and livable future for all, which makes the short-term inconvenience negligible (2.1). Protesting is always part of a larger, longer movement that tries to create better systems. This movement in and of itself is valuable with the same logic (2.2). 
Some may argue that short-term goods are valuable from a common good perspective and that interfering with them is not negligible. Preventing people from attending school and work for the sake of longer-term goals typically burdens already worse-off people within a society who have fewer resources in terms of alternate transportation, paid time off from work, or supplementary tutoring for school absences. So, the long-term good sacrifices important short-term goods. (against 2.1)

But this counterargument presumes that acts of civil disobedience cannot be sufficiently tailored to prevent disruption to major roadways needed for access to emergency services and schools. To be effective, civil disobedience must balance these goods such that selecting a road to block is appropriate to the ends of the protesters. For example, blocking the road to the construction of a pipeline project or the road to a legislative institution on a day when legislators aim to vote to undo environmental regulations on companies would both be cases that use long-term common good interests to justify protest without being dismissive of the many other appropriate priorities within a society.

- Utilitarian/Consequentialist + ethical responsibility: It is important to consider the greatest good for the most people since politicians should also consider this (1). Therefore we must compare the harms of protesting to those of not protesting. Protesting will increase the likelihood of governments adopting policies addressing climate change. Climate change will undeniably cause harm across the board; the small disruptions in people’s days are small and few in comparison (2). You might argue that whoever’s lives are disrupted are not responsible for climate change. First, a utilitarian would still argue that this does not matter since the harm done to them is little compared to the harm inflicted upon billions of people across the globe (possibly including passersby) by exacerbated climate disaster. Additionally, protestors may obstruct people from their daily activities, but it does not mean they assign responsibility to those people. If a protest is aimed against the government, the inconvenience caused to passersby can be alleviated as soon as the government implements policies to address climate change sufficiently (3)

**Q3. (1/2) Which of the following is a better starting point for an argument for #ethicaljudgment – we should not eat meat because:

- …meat is bad for your health and the environment. Our ancestors also ate much less meat than we do today.

- …we are infringing upon the rights of animals. Animals have the right to a natural and healthy life, just like humans do.**

2! It is certainly not complete yet, but it suggests normative evidence that it could use in rights theory to help support the argument, while the first argument only presents empirical information about eating meat without addressing normative reasons for advancing health and the environment in this way. Although this sounds obvious, an application of #ethicaljudgment needs to explain why certain outcomes or considerations are morally significant.

**Q4. (2/2) How might we improve the less strong argument from above?**

We should include the why (or support for our arguments):

- Firstly, we should focus on one particular ethical reason to make it more feasible to defend well. 

- Secondly, we should draw from ethical principles to support our arguments, tailored to our intended audience. Imagine you are trying to convince someone who isn't already convinced of your argument, and consider the reasons you could offer to persuade them. Perhaps you observe that your audience is invested in the goods of longevity and mobility, and so you argue that since consumption of meat contributes to cardiovascular problems (based on empirical evidence), you shouldn't do things that impair your well-being (based on normative reasoning), that you should reduce or eliminate meat from your diet. 

- Lastly, we should include a counterargument and respond carefully to the concerns raised by that argument.

**Q5. Do I have to tag all three #ethics HCs when I tag any one of them?**

No. Tagging all three (#ethicalconsiderations, #ethicaljudgment, and #ethicalcourage) would be a good idea only when you have the space to apply all three especially well in an assignment. You’ll often be asked to focus on some, but not all, of these HCs. For example, you might defend a position on universal basic income, in which case you should definitely apply #ethicaljudgment, and possibly #ethicalconsiderations (depending on assignment instructions and how much background information you take for granted). 

However, whenever applying #ethicalcourage, you have implicitly (or explicitly but shortly) decided what is ethically important (#ethicalconsiderations) and what action is the most ethically appropriate (#ethicaljudgment). 

Understanding how all three can be scaffolded effectively is important, even if you do not tag all three in one particular work. As a general rule of thumb, it’s a good idea to reflect on the central purpose of your assignment and tag those HCs that are most relevant and use the Guided Reflection below to check whether your application is complete. It’s also good to ask an instructor for advice about HC tagging priorities.

## Guided reflection (proficiency checklist)

1. Have you presented an argument in which your reasoning is supported by normative evidence and reasons about what is good or right to do?
2. Have you clearly identified the ethical principles and concepts you use to justify your decision, drawing from normative theories and textual evidence?
3. Have you justified the chosen values upon which you act and how they are relevant in the context?
4. Have you compared your judgment to an appropriate alternative argument?
5. Have you responded to possible counterarguments to making your decision without merely restating your initial argument?

## Common pitfalls

1. Presenting an argument without addressing possible counterarguments or other views
2. Provide empirical evidence supporting your argument, but not normative evidence or ethical reasons.
3. Simply applying an ethical framework to a situation without explaining why you use that framework and addressing (countering) other ways of reasoning.
4. Provide a literary review about competing ethical theories without focusing on crafting an argument and defending your stance.
5. Not explaining why the chosen ethical framework(s) are relevant.

## Applying the HC at Minerva

1. Business - When entering any avenue of business, it’s important to consider the ethical decisions you must make. For example, in a business course, you may be asked to imagine how to address privacy concerns within a company. Suppose your company has a data analysis component. In that case, you might consider respecting privacy (or theories of autonomy) by including components of data security or informed consent, defending your judgment that this is a sufficient resolution of the concern by overcoming possible problems you anticipate.
2. Research  - Especially when doing research with human participants, it is important to consider the ethical decisions made regarding the research design, procedures, and applications. For example, an important concept here is that of informed consent: the idea that participants need to participate and be informed about the research voluntarily. There are stricter and less strict understandings of this. Letting participants tick off a box but offering them money for the research might not encourage or enable them to make a fully informed decision about participating. You apply #ethicaljudgment when you offer reasons supporting the value of informed consent based on ethical reasons and then explain which kind of policy toward informed consent is most compatible with that value, in contrast with an alternative.
3. Social Sciences - The effects of our social systems on various areas of ethics is immense; from ideas about surveillance to our economic systems, and from the views on relationships to the views on practices such as death sentences, ethics are involved. Social science applications can get overly complicated if you try to solve them from every possible angle. Instead, try using #ethicalconsiderations first to define the most salient and useful ethical concepts to use in your reasoning. Being precise and constraining yourself to a specific part of the social system you are talking about might assure the deepest, most fruitful application. Then, present an ethical argument that acknowledges the peculiarities of that application area, for example, by explaining what meaning certain ethical concepts take in the new context.
4. Philosophical ethics - In contexts outside philosophy, you’ll refer to a philosopher’s ethical theory to justify your decision. But in the context of philosophical research and writing, you’ll likely spend more time on careful interpretation and critique than in other academic contexts. Ethicists are especially concerned with carefully defining, interpreting, and applying different ethical values and arguments. Applying an idea to a new context and describing what meaning the concepts take on can be a fruitful application, as well as contrasting ethical arguments and implications of different theories you’re studying, is a great way to use #ethicaljudgment in a philosophy course.

## Applying the HC outside Minerva

1. In your relationships: Sometimes you will have a conflict between moral beliefs in a relationship. For example, are friends or a romantic relationship more important if both invite you to an event? Or you will observe the responsibilities you feel towards family/friends compared to what you have to sacrifice to fulfill those. Figuring out what decisions to make takes careful thought.
2. As a consumer: Who are we thinking about when we consume, and what ethical beliefs are behind our consumer decisions? For example, there are arguments considering: the impacts of consumption (consequentialism); our motivations for consumption, the kinds of systems we support by consuming; the right we have to certain kinds of consumption as compared to other consumers; and so on… You will find that making these decisions will become easier if you find out which values and arguments you find convincing…
3. As a citizen: Political participation, or non-participation, has ethically significant impacts on oneself and others. Speaking up at community events, attending political protests, voting, and volunteering might all be things you think you should do, according to your #ethicaljudgment.

## Key resources

1. Wisor, S. & Perry, T.J. (2022). Ethics and Justice in Complex Systems. Minerva Guide v2.5. https://docs.google.com/document/d/17S9I_ct0FuVqZWC3W42R4EqUW7vCklA0M-rSbgzgbX4/edit#
- This reading introduces some of the key concepts and approaches of ethical and political theory.
2. Sheskin, M., Perry, T. (2022, January 20). Ethical Courage - Minerva Guide. https://docs.google.com/document/d/1wA8ybnTXoAabp-AqsTR5p9cPr0EyMdyVLrhqe9nQfkE/edit?usp=sharing
- This guide argues for the necessity of #ethicalcourage after one has applied #ethicalconsiderations and #ethicaljudgment. It also explains the main features of the phenomenon that it’s difficult to make decisions we believe are right and how one can approach this problem.
3. Markkula Center for Applied Ethics. ‘Ethical Decision Making’. https://www.scu.edu/ethics/ethics-resources/ethical-decision-making/
- This article outlines various aspects of ethical decision-making and the main paradigms driving ethical decision-making. Use their “Making an ethical Decision” step-by-step poster to inform your ethical decision. — [link](https://www.scu.edu/media/ethics-center/resources/making.pdf)
4. Beyond Point-and-Shoot Morality: Joshua Greene - Harvard Thinks Big, 2011. https://www.youtube.com/watch?v=sChdbsbTNxI
- An important video for all three ethics HCs. For #ethicaljudgment, pay attention to how analyzing the moral considerations of a decision take effort. Point-and-shoot morality is what happens when we don’t take the time to analyze what factors are relevant beyond the obvious. Still, exactly this is necessary to come to a well-reasoned decision.
5. Nagel, T. (2015, June 24) Joshua Greene’s Moral Tribes. The New Republic http://web.archive.org/web/20150624165406/http://www.newrepublic.com/article/115279/joshua-greenes-moral-tribes-reviewed-thomas-nagel
- A further explanation of Joshua Greenes’ views on morality, situating it as a theory of utilitarianism and moral psychology instead of moral philosophy.
6. Elliot, Deni. ‘All Is Not Relative’. Ethics Unwrapped. Accessed 4 July 2023. https://ethicsunwrapped.utexas.edu/video/all-is-not-relative
- This video explains the danger of moral relativism (thinking there is no way to make the right decision) but explains why considering different perspectives is still important: the key to #ethicaljudgment.

## Custom HC guides

- [Ethics and Justice in Complex Systems](https://docs.google.com/document/d/17S9I_ct0FuVqZWC3W42R4EqUW7vCklA0M-rSbgzgbX4/edit)
- [Ethical Courage](https://docs.google.com/document/d/1wA8ybnTXoAabp-AqsTR5p9cPr0EyMdyVLrhqe9nQfkE/edit)

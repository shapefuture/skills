# #responsibility — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/responsibility/](https://my.minerva.edu/academics/hc-resources/hc-handbook/responsibility/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Working with others
> Taught in: Foundation Week | Semester One · Unit: Purpose and Responsibility
> Big Question: How can we be the authors of our own life's story?

## Definition

**#responsibility** — Follow through on commitments; be proactive and adaptable.

> **Pitch:** Set honest goals, follow up honestly, and communicate honestly when unable to follow through.

When working with others, one should take responsibility for one’s own contribution and communicate proactively. This means that one should contribute according to one’s abilities and ethical principles, keeping in mind not to set unrealistic expectations. After carefully setting expectations, it is crucial to think about accountability structures. To act responsibly, it is vital to recognize what is and is not within your locus of control. One can improve one’s self-control and grit to an extent, which will help set and achieve ambitious goals, but it is important to recognize the limits of individual effort too. When setbacks arise, it is crucial to acknowledge your responsibility for areas where you have fallen short and to be proactive about finding solutions. Others should be told about problems with enough advance notice for them to adjust their plans and deal with the resulting challenges.

## Worked example

You have a final project team that has never worked together, and decide to split tasks and assign members responsibilities within the group. You decide to plan a meeting every other week to check-in and ensure members keep up with their responsibilities. To hold yourself accountable, you also schedule at least 45 minutes every day after class to work on your final project, during which you arrange to have your friend take your phone away from you to enhance focus. These strategies enhance your efficiency, and you stay on track. After several meetings, your team realizes one of your coworkers is not showing up. Several of you approach him to ask if he is having difficulties, but he is hard to reach. By the end of the semester, even though all other members kept each other accountable and finished their tasks, this member hadn't completed his part. Whether he simply lacked self-control or was limited in his contribution by external factors, his contribution hurt the overall team grade. Next time, you will consider how to embed accountability and adaptability in pursuit of your goal more effectively. While the individual’s actions and circumstances are his own, the team could have worked together to identify those factors that are within their control, such as proactively mitigating the impact of his poor contribution and setting a point at which they would seek external advice regarding the composition of their team.

> **Footnote:** The application not only explains how particularities of responsibility for different members of the group combined to lead to a specific outcome in the social system but also details some of the strategies (weekly meetings, no phone) used to target specific facets of responsibility and why they were effective. It demonstrates a separation between what is and what is not within the team’s locus of control. It also highlights what could be done differently in the future by taking ownership of the teamwork dynamic and intervening when external factors (in this case, a teammate) create challenges.

## Is it this HC?

Is #responsibility the right HC? If the answer to the following questions is yes, #responsibility could be useful:

- Are you doing one of the following: a) explaining how you have integrated responsibility in your work, b) analyzing how facets of responsibility have shaped an individual's behavior or interactions within a group of people?

- Do you show how to create accountability – e.g., by using incentives or setting clear expectations – to meet deadlines and follow through on your commitments?

- Are you reporting about the way certain methods or procedures for accountability worked or didn’t work?

- Are you thinking about what approach to locus of control is appropriate?

However, depending on the focus of the work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#shapingbehavior](shapingbehavior.md) | Sets incentives and deterrents to meet the project’s goals. Helpful in thinking about motivation but focuses on external factors, while responsibility tries to cultivate accountability often from an internal locus of control. |
| [#selfawareness](selfawareness.md) | Explains the causes and effects behind self-awareness. Has a much broader scope, but self-awareness can be a component of creating personalized accountability systems. |
| [#emotionaliq](emotionaliq.md) | Analyzes how to behave in a situation, considering how emotion shapes behavior. Responsibility focuses on actions rather than emotions while analyzing emotions can be informative. Sets a goal and develops strategies for self-control. Some of these strategies might also help increase a responsible relationship to work. |
| [#ethicalconsiderations](ethicalconsiderations.md), [#ethicalcourage](ethicalcourage.md), [#ethicaljudgment](ethicaljudgment.md) | In ethics, we might establish the moral responsibility of agents and your resulting goals and actions. These might then demand personal responsibility and strategies to be proactive and communicative about them. |
| [#differences](differences.md) | Understanding and utilizing people’s differences. It might be relevant to realize that accountability works differently for different team members, and some people might be better at acting out certain roles (i.e., motivator vs organizer) to create an accountable teamwork dynamic. |
| [#professionalism](professionalism.md), [#constraints](constraints.md), [#biasidentification](biasidentification.md), [#biasmitigation](biasmitigation.md) | Uses these HCs in conjunction with #responsibility for a stronger application. |

## Self-study Q&A (6 questions)

**Q1. What qualities and strategies can you develop to achieve more ambitious goals (as an individual or team)?**

Strategies include:

- cultivating an internal over an external locus of control, 

- planning and the planning fallacy, 

- self-control, 

- shaping and incentivizing behavior that is aligned with acting responsibly (related to #shapingbehavior), 

- using superordinate goal-setting or showing the tenacity to work toward a goal over the long term (grit), 

- accountability strategies, 

- adaptability strategies

**Q2. What is the danger of the above strategies of #responsibility as focusing on improving output?**

Although grit, internal locus of control, and self-control can work to an extent to become a more responsible adult and achieve the goals you want to achieve, one should not get the idea that these can help you overcome any obstacle. Many people face external constraints to their ambitions. Developing an honest locus of control is likely more healthy. Sometimes, acknowledging the limits of your control is actually taking control of a difficult situation.

**Q3. What is a locus of control?**

A locus of control refers to an individual's belief about the extent to which they have control over their own life and the events that happen to them. It can be internal or external. An internal locus of control means that an individual believes they have control over their own life and the events that happen to them. In contrast, an external locus of control means that an individual believes that external factors such as luck, fate, or other people have more control over their life and the events that happen to them. Go to the Key Resources section for a great resource!

**Q4. How can someone use their locus of control?**

There are several ways, including:

- Taking responsibility for actions and decisions you made yourself. 

- Focus on what you can control and let go of what you cannot.

- Setting realistic goals in the first place and working towards them.

- Developing a positive mindset and reframing negative thoughts. 

- Building resilience and coping skills to respond to challenges and setbacks.

- Seeking support from others when needed.

**Q5. What are some benefits of an internal locus of control?**

Having an internal locus of control has been linked to various positive outcomes, including higher levels of motivation, better coping skills, and increased success in achieving personal and professional goals. Individuals who believe they have more control over their life and what happens to them are also more likely to take proactive steps to improve their lives and are less likely to feel helpless or hopeless in the face of adversity.
But! Be careful because many things are indeed outside of your control. Believing everything is can lead to disillusionment or being overly self-critical. Increasing pressure on yourself can cause stress/burnout and a refusal to delegate. Having a balanced (and accurate!) locus of control is always best. Especially within larger systems, there are people whose internal locus of control is limited by external factors. Criticizing oneself in such circumstances misses the big picture that we also want students at Minerva to think about!

**Q6. What are some strategies for overcoming procrastination and improving follow-through?**

One strategy for overcoming procrastination is to break down goals into smaller, more manageable tasks that can be completed in shorter periods. This helps create a sense of progress and momentum, which is motivating. Another strategy is to create a specific action plan with deadlines and to hold oneself accountable by sharing this plan with others. Additionally, it can be helpful to identify and address any underlying emotional or psychological barriers that may be contributing to procrastination, such as fear of failure or perfectionism.

## Guided reflection (proficiency checklist)

1. Have you explained how specific facets/practices effectively (or ineffectively) shape behavior in particular ways, or have you embodied and justified the characteristics of responsibility in your own actions?
2. Have you argued what being “responsible” means in a given context?
3. Have you analyzed how elements of responsibility (or lack thereof) relate to the efficacy of interactions or outcomes in a social system?
4. Have you identified sophisticated or nuanced strategies that use facets of responsibility (such as grit, self-control, or planning) to interact effectively or achieve goals?
5. Have you explained why a proposed strategy effectively achieves a goal in – or responsive to – a particular context?
6. Have you explained strategies or actions you used or could have used to address the issue if you identified issues in project management?

## Common pitfalls

1. The application only focused on the colloquial use of responsibility, tagging an action as an application of #responsibility because the action showed the characteristics of acting responsibly without explaining specific strategies.
2. The application did not go in-depth to describe how the individual showed thinking ahead of time in developing strategies, mindsets, or habits that would enable them to accomplish a stated goal.
3. The application focuses only on establishing responsibility (morally, legally, etc.) without thinking about how to follow through effectively.
4. Focusing on individual responsibility and an internal locus of control without acknowledging the constraining factors or responding to those realistically.

## Applying the HC at Minerva

1. In your Capstone. Managing such a big project with sometimes ambitious premises can be daunting. Since you work mostly independently, you must recognize the tools you can use to progress and keep moving through academically challenging times. An essential part is setting realistic goals and breaking down the large project into smaller moments of success and celebration. Another element within your internal locus of control is communication with your supervisor. When setbacks arise, being honest about this makes them much better able to help you adjust your plans.
2. When doing your assignments, you can use strategies that make planning and sticking to the plan easier. You could allude to specific strategies or challenges you encountered with a footnote.
3. When doing group work on projects (like civic projects), you might have weekly check-ins, break down the problem into smaller sub-goals you schedule in a calendar, and complete project subsections by adopting effective project management strategies.
4. Minerva’s course, SS162: Personal and Social Motivation, details strategies and the research behind multiple strategies that can enable you to plan and meet your goals. You will very likely to apply this HC within the course. If you have not taken this course, this might be a good time to reach out to someone who has or is a professor of this course!
5. In a business course, you might apply responsibility to analyze how an organization can improve the responsibility of its employees or how colleagues and managers can hold each other accountable. You might think about how responsibility and expectation-setting strategies inform how you organize and create workflows.

## Applying the HC outside Minerva

1. In personal relationships, responsibility might be relevant. We often have commitments toward our family members, partners, or friends. In these, we communicate honestly about expectations, show up for each other in critical moments, and might commit to the longevity of a relationship (through marriage, for example).
2. In business, monthly team projects will require the team to schedule, coordinate, and ensure everyone is on the right track.
3. When developing a business, you might go through periods of self-doubt. This is an instance where recognizing how #confidence might fluctuate and compel you to develop contingency plans, like “If I find myself doubting my capacities to build a business, I will open a journal I will make to archive other things I have built.”
4. When doing creative work like producing a film or writing a novel, you might have to set up incentive structures to accomplish the task as well as reminders about why you want to do the work to help you during days when your motivation is lacking.

## Key resources

1. Eatough, E. (2022, March 2). Understanding Locus of Control and What Motivates You. https://www.betterup.com/blog/locus-of-control
- This resource explains the difference between the external and internal locus of control. Pay attention to the possible benefits and drawbacks of both approaches as described in “The role of locus of control in everyday life” and think about the conditions under which each one might be appropriate. There are some great examples to compare them. Note that locus of control is about attitude towards events, irrespective of whether you did in fact have or have no control over them.
2. Looser, C. E. (2019). Forum Magic. Minerva University. https://docs.google.com/document/d/182DpMpDXjmp9ohd8fZ9GeB3DG2Hmanj5xQe_IF5GEMs/edit
- This source uses cognitive psychology to explain how attention and perception shape your behavior and interactions on Forum, which can give you a new perspective on how to demonstrate #responsibility during class.
3. Nemko, M. (2014, July 11). 7 ways to make yourself follow through. https://www.psychologytoday.com/us/blog/how-do-life/201407/7-ways-make-yourself-follow-through
- This short article provides tactics that one can employ to avoid procrastinating working on a task or a project.
4. Snow, S. (n.d.) (2022, June 6). How to Set Boundaries at Work When It’s Hard (Especially When Remote). https://www.forbes.com/sites/shanesnow/2020/04/13/how-to-set-boundaries-at-work-when-its-hard-especially-when-remote/?sh=23dd2f1d1870
- This article describes the importance of setting boundaries in functional work environments and how to communicate your needs and abilities in group work contexts in a way that promotes a positive work relationship and clear sense that the whole team shares a common goal.
5. Harrington, A. (2021, March 19) You Can Only Lend a Helping Hand if Your Hands Aren’t Full. https://acrlog.org/2021/03/19/you-can-only-lend-a-helping-hand-if-your-hands-arent-full/
- This short blog post is written by academic and research librarians, offering ideas about how to engage in self-care and effectively help others when you can in order to create conditions that allow for individual and shared responsibility for projects and work.


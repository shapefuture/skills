# #audience — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/audience/](https://my.minerva.edu/academics/hc-resources/hc-handbook/audience/)
> **Habit of Mind** · Cornerstone course: Multimodal Communications · Competency: Communicating Effectively → Using language
> Taught in: Multimodal Communication | Semester One · Unit: Writing as a Craft
> Big Question: What might a perfect society look like?

## Definition

**#audience** — Tailor oral and written work by considering the situation and perspective of the people receiving it.

> **Pitch:** Everyone can have brilliant ideas; successfully sharing these ideas with others is the challenge.

Different audiences have different background knowledge, interests, goals, world-views and perspectives. To apply #audience effectively, one must do two crucial steps: 1) characterize: identify and articulate characteristics of an audience and 2) tailor: adjust details and features of a communication to match and speak to these characteristics. Applications of audience become especially nontrivial when an audience consists of people who have different levels of knowledge, goals, interests, or motivations; in these cases, one cannot reach all of them equally effectively with the exact same delivery. Learning about and carefully considering an audience’s point of view can help one design communications that they can grasp, will appeal to their interests, and will be perceived as compelling.

## Worked example

You present a new product to a company that you hope will buy it in three independent meetings with the directors, engineers, and sales team. Your first meeting is with the directors. In your experience, directors are not interested in the technical details of the product, because they are more focused on making sure the product is a worthy investment. Thus, you presented a 5-minute summary of its functionality, potential revenue and time to profitability. Next, you present it to the engineers, who want an in-depth description of its “specs” and the potential problems during manufacturing, since their job relies on the product’s mechanical aspects. You focus on the technical aspects of the product, taking no time to explain technical jargon knowing your audience is knowledgeable in the field. Finally, you present it to the sales team, and they ask about the most novel and noteworthy features of the product that they can use to advertise it to customers. You give them a description of the product’s most useful functions and explain its most sensational aspects. You adjusted both the content and the manner in which you present it to each audience—including the length of your presentation—to meet the audience’s expectations and interest.

> **Footnote:** The content and method of the presentation are adapted to suit each specialized target audience based on an understanding of their main interests and perspectives. For example, for the directors, who are less interested in the product details and who have time constraints, the presentation was made to be short and to focus on their area of interest: profitability.

## Is it this HC?

Is #audience the right HC? If the answer to the following questions is yes, #audience could be useful:

- Do you aim to communicate a message to an individual or group?

- Does the audience have specific goals and motivations to consider?

- Would your work product be improved by attending to audience input?

- Would successfully communicating with a particular group of people best serve your purpose?

Note that the question above is a trick question. #audience pertains to all of our communication, and attending to its significance offers us ways to achieve our communicative goals, whether to entertain an audience as a comic writer or persuade an audience as a political candidate. It is a good idea to remember this HC even if you do not plan on tagging it. However, depending on the focus of the work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#professionalism](professionalism.md) | adheres to its professional conventions in tone, organization, and language. |
| [#persuasion](persuasion.md) | discusses the design and execution of an argument. considers different theories and effects at play, like the assimilation effect from social judgment theory. |
| [#strategize](strategize.md) | details the strengths and weaknesses of the entity’s position, diagnosing the situation, guiding policy, and course of action. |
| [#conformity](conformity.md) | adopts a contrarian posture or analyzes the role of a contrarian. analyzes conformity in a system. identifies and studies the kinds of social influence that led to conformity and the norms that were being conformed to. |
| [#medium](medium.md), [#multimedia](multimedia.md) | these HCs are used to analyze or craft a communication with one or more mediums, which could be enhanced by identifying the relevant audience and how the work can be effectively tailored to it. |
| [#connotation](connotation.md), [#expression](expression.md), [#designthinking](designthinking.md), [#purpose](purpose.md) | draws on #audience to make the application of these HCs stronger. Most HC applications will require an analysis of #audience to orient the work products. |

## Self-study Q&A (6 questions)

**Q1. What are the two key steps in applying #audience effectively?**

Applying #audience effectively involves two essential steps:

- Characterizing the audience – Before making any communication choices, first define who the audience is. Consider factors like their background knowledge, interests, expectations, perspectives, and potential biases. This step also involves ensuring your defined audience is reachable and aligns with your purpose. 

- Tailoring communication to the audience – Based on the characterization, make deliberate choices in tone, language, structure, and content to ensure the message resonates with and is accessible to the intended audience. This usually involves evaluating alternatives for tailoring your message and justifying which strategy is most effective.

Both steps are crucial, as without characterization, tailoring may be misdirected, and without tailoring, even a well-defined audience won’t be effectively engaged!

**Q2. How can you support your interpretation of your audience?**

First, get informed about your audience. Merely assuming or claiming that you know your audience's point of view is not enough. Applications of this HC involve researching your audience to figure out how to tailor your work and justify those decisions, given what you've learned about the audience. Second, use your information about the audience to tailor the length of your message, what types of vocabulary you use, and what content they will be most interest in. Suppose you know your audience but have not built your message around their interests. In that case, your application of #audience would not be complete, and you are unlikely to impact the people you want to reach.

**Q3. What is the difference between perspective taking and perspective getting?**

Perspective taking is imagining yourself in someone else's shoes; this is often done by researching the intended audience's motivations, interests, and shared experiences. However, this method is prone to assumptions and stereotypes because it is easier to know what your audience thinks if you ask them. This is exactly what perspective getting is about; with this strategy, you ask your subject directly about their motivations, interests, and experiences. Gathering your information about the audience straight from the source reduces bias.

**Q4. What happens if your audience is too broad?**

If your audience is too broad, they will have highly diverse goals and perspectives, and you will only be able to reach some members with your message. You may fall into the trap of using generic examples and words, hoping everyone will understand them. However, when your message does not appeal to the audience's interests, it will be unlikely to resonate with them. In this case, you must refine your audience, ideally to a subgroup with a common interest that you can build your message around.

**Q5. What happens if your audience is too narrow?**

If your audience is too narrow, you will likely be able to identify their interests and tailor your message to them adequately. Additionally, your limited audience may come in conflict with your message's purpose. If you want to spread your message to others, making your message too specific to a few people's personal interests will make it unrelatable to the vast majority of possible audience members. Therefore, ensure your audience is broad enough to fulfill your purpose and make a difference, and tailor it well so that it appeals to your intended audience but maintains its purpose.

**Q6. Why is tone important when tailoring your work for your audience?**

A casual tone in a professional environment might make you seem less credible, while a formal tone in a relaxed atmosphere might make you seem less relatable. Knowing who you are talking to is essential to tailor your tone appropriately. This way, you can sound how your audience expects a knowledgeable, credible, and relatable individual would. Note that communications can be tailored to an audience both in terms of the tone of words and their implied meaning (#connotation) and in terms of the intonation of voice (#expression).

Here are a few examples of how the tone of words can shape a message depending on the audience:
- Professional (Formal and Respectful) Tone
- Audience: Business colleagues or stakeholders

- Message: We are pleased to announce the launch of our new project, which aims to enhance customer satisfaction through innovative solutions. Please feel free to reach out with any questions or concerns, as we value your input.

- Casual (Friendly and Conversational) Tone
- Audience: Friends or close-knit team members

- Message: Hey everyone, super excited to share our new project - it’s all about making things easier for our customers. Let me know what you think!

- Humorous (Lighthearted and Engaging) Tone
- Audience: Social media followers or friends

- Message: Turns out, solving problems and drinking coffee are best friends. Got a solution? Share it below - coffee optional!

## Guided reflection (proficiency checklist)

1. Have you specified and characterized who the target audience is?
2. Have you ensured your defined audience is reachable and aligned with your purpose?
3. Have you accurately explained an audience's perspective?
4. Have you used knowledge of an audience's perspective to tailor a message subtly and sophisticatedly?
5. Have you evaluated other alternatives for tailoring your message and justified which strategy is most effective for your audience?
6. Have you explained technical terms unfamiliar to your audience?
7. Have you used input from the audience to gain information about their experiences and values?
8. Have you considered what factors might prevent your audience from reacting as you intended?

## Common pitfalls

1. The application identifies an audience but does not tailor the work to that audience.
2. The application identifies an audience but makes incorrect assumptions about the audience's perspective, possibly basing such assumptions on limited demographic information or stereotypes.
3. The application identifies an audience but does not consider how their patterns and perspectives are important for our communication or design purposes.
4. The application's intended audience is too broad or too narrow.

## Applying the HC at Minerva

1. When solving problem sets in a computer science class, you imagine your audience is your peers. By defining your audience in this way, you can ensure your explanation is appropriately detailed and explained. This is preferable to assuming the audience is your professor with advanced knowledge, leaving out important details, or assuming your audience knows nothing and wasting time explaining unimportant steps.
2. When writing a paper about how your culture's norms manifest in your country's politics, you should define your audience. If talking to people from your culture, your audience's background knowledge will allow you to talk about niche examples and save you extensive explanations. On the other hand, if your audience is your Minerva peers, you will have to tailor your message to a group that shares very little background knowledge about your culture but has many interests and education in common. In this case, you will have to do more explaining about your culture but will be able to utilize shared knowledge on complex systems in your paper.

## Applying the HC outside Minerva

1. When presenting in other states or cities, a political candidate gives different speeches to align her message with the diverse backgrounds and interests of people from different regions.
2. A taxi driver knows from experience that when a group of people enters his car, they tend to talk amongst themselves and prefer he stays out of the conversation. On the other hand, individual passengers tend to enjoy some conversation. He has also noticed his older passengers are usually more talkative than his younger passengers. Based on his observations, he decides whether to engage in conversation based on his passengers' quantity and age.
3. A museum curator changes how they phrase a particularly controversial figure depending on whether or not the prospective investors agree with the figure's message.
4. A TV channel considers when to program certain shows, given who will likely tune in. Therefore, shows meant for adults and parents are streamed in the evening when most adults are done with work and their children are asleep.
5. In making an app, a user experience (UX) designer might use #audience and #designthinking to gather product feedback. They might use #audience to a) identify who they want to interview and b) form the questions they will ask them in the interview.
6. When writing to parents at home, you are most likely applying to tailor your message to what your parents want to hear. You may prioritize writing about your academic accomplishments and write less about your social life and how much money you are spending.

## Key resources

1. Gershon, T. (2018, June 25). Quantum computing expert explains one concept in 5 levels of difficulty | wired. YouTube. https://www.youtube.com/watch?v=OWJCfOvochA
- The resource illustrates how you might change your explanation of a concept depending on your audience. For example, when writing your paper about cryptography algorithms, not everyone will know as much as your crypto-researcher grandma, so you will have to change the way you communicate.
2. Moxley, J. M. (2023, May 10). Audience – audience awareness. Writing Commons. https://writingcommons.org/section/rhetoric/rhetorical-situation/audience/
- This resource gives a broad overview of audience awareness. It includes questions to consider when writing for audiences outside of academia, such as technicians, decision makers, and online readers, as well as unknown audiences.
3. Wray, A. (2020, August 5). What to think about when writing for a particular audience. Writing Commons. https://writingcommons.org/article/what-to-think-about-when-writing-for-a-particular-audience/
- This resource provides specific examples and techniques for adapting writing to a particular audience. It highlights the four areas one should take into account when writing: audience, purpose, context, and medium.


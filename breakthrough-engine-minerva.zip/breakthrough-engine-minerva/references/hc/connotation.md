# #connotation — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/connotation/](https://my.minerva.edu/academics/hc-resources/hc-handbook/connotation/)
> **Habit of Mind** · Cornerstone course: Multimodal Communications · Competency: Communicating Effectively → Using language
> Taught in: Multimodal Communications | Semester One · Unit: Close Reading
> Big Question: How does language represent reality?

## Definition

**#connotation** — Understand and use connotations, tone, and style.

> **Pitch:** The magic of saying exactly what you mean.

To communicate effectively, one must understand and use connotations—the idea(s) or feeling(s) that the words, tone, and style of a communication imply. Individual words as well as idioms and colloquialisms carry not only literal meanings, but also implied meanings that affect communication.

## Worked example

You are writing a campaign advertisement about police brutality in your hometown in response to recent murders of innocent citizens, and are trying to decide between the words “strong” and “forceful” to describe the police force. The denotative meanings of such words are close enough that in principle they often might be substituted for each other — but their connotations are very different, which cautions against simply using a thesaurus to select words. Because you are trying to raise awareness of unwarranted use of force by police officers, you wish to portray them as aggressive. You therefore choose to go with the word “forceful” because the connotative meaning is slightly more negative, successfully antagonizing the police force for your purpose, as opposed to using “strong”, which might have a positive connotation and portray them as protectors instead of abusers.

> **Footnote:** The diction chosen to describe the police force was carefully selected to connote a body of unnecessarily aggressive officers (e.g. “forceful”), thus portraying them in a negative light and contributing to the purpose of your campaign as opposed to other word choices that could unintentionally glorify them (e.g. “strong”).

## Is it this HC?

Is #connotation the right HC? If the answer to the following questions is yes, #connotation could be useful:

- Are you attempting to communicate in a precise way?

- Are you questioning the implicit meaning of a word?

- Are you hoping to match the implicit meaning of your words to your message?

Depending on the work product, there might be other HCs to consider. ….

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#composition](composition.md) | communicates with a clear and precise style by utilizing sentence structure. |
| [#critique](critique.md) | actively and critically engages with texts and other forms of communication, this may include observations of connotation patterns and be complemented by an application of #connotation. |
| [#audience](audience.md) | tailors oral and written work by considering the situation and perspective of the people receiving it, applying #connotation will be effective when informed by an application of #audience. |

## Self-study Q&A (9 questions)

**Q1. What is the difference between connotation and denotation, and why is it important?**

Denotation is the literal definition of a word that might be found in a dictionary, while connotation refers to the wide array of positive and negative associations that most words naturally carry with them. Two words that have the same denotation may have different emotional and imaginative associations surrounding them, meaning they have different connotations. Since words can have the same denotation and very different connotations, understanding the differences will positively influence your close reading and writing skills. In order to communicate precisely, both connotation and denotation should be considered in your word choices, so you say and imply exactly what you mean too. Failure to consider connotations can lead to misunderstandings.

**Q2. How can I focus specifically on the effect that connotation has on meaning?**

One effective strategy is to consider how the meaning of a sentence or passage changes when you swap in a synonym for a particular word. If you have actually chosen a synonym, the denotation of the sentence should not change. However, you may still have a sense that the two versions of the sentence convey different meanings. This will guide your identification of the relevant connotations, and it will allow you to choose the version that best suits your communicative purposes.

**Q3. How does #connotation relate to #audience and #context?**

The effect of connotation is going to be based on the set of associations or implications that are triggered in the minds of the audience. In that sense, there is no single “connotation” of a word. In certain cases, a word may have a very strong connotation for one audience, but not another. For example, if a word features prominently in a particular religious text, followers of that religion may have strong associations with the word that are not shared by others. When you are communicating, you need to think about the associations a word would carry with your intended audience. When you are analyzing text, consideration of the author’s background may help you to identify connotations.

**Q4. What if I don’t know the connotation of a word?**

Because connotation is about the associations and implications of a particular word choice, rather than its dictionary definition, it can be challenging to identify connotations in a language that you are not fully fluent in, since you may not yet have built up that set of associations in your own mind. One effective way to address this is to talk with native speakers of the language. Ask them to describe what meaning they take from alternative word choices.

**Q5. What is diction?**

Diction refers to the words writers use to express ideas, or otherwise writers’ word choice. Diction changes in different contexts, especially between formal and informal settings, so it is important to tailor your diction to a specific context. Choosing words should be based on both the denotation and connotation of the possible choices. By being mindful of diction, your writing will avoid vagueness or language that has more than one equally probable meaning. In practice, effective diction also avoids clichés, wordiness, and unnecessarily complex language. (Note that this final point begins to cross over into #composition).

**Q6. What is tone?**

Tone is the ”attitude” of the work. The tone should be appropriate for the audience and purpose of the communication. Some examples of tone include: objective or subjective, logical or emotional, intimate or distant, serious or humorous. Writing should change to suit the occasion, context is important for determining tone to use in communication. Understanding tone is essential to processing what is being said in communication as well. Tone is going to be the aggregate effect of many individual word choices, each of which is guided by considerations of #connotation.

**Q7. What is the difference between tone and voice?**

Tone varies based on the environment of the communication while the voice is personal to the author. Your writing voice is made up of the individual ideas and ways of expressing yourself that you find yourself returning to. Your voice does not have to be rigid, it will evolve as you evolve as a writer, but it should always be a representation of you.

**Q8. What is style?**

Style is the way in which something is written, not what is written. Consistency is important in style, switching it can distract readers and lower credibility. Style includes both diction and tone. When the audience and the purpose of the writing should align with the style.

**Q9. What are types of styles?**

Persuasive, narrative, expository, and descriptive styles are common in writing. 
- Persuasive: This style is useful when the writer is trying to convince the reader of the validity of a certain position or argument. Persuasive writing includes the author's opinions while providing justifications and evidence to reinforce their assertions.

- Examples: Letters of recommendation; cover letters; Op-Eds and Editorial newspaper articles; argumentative essays for academic papers

- Narrative: This style is useful to share information in the context of a story. It is most common in longer writing samples. Writing in this style should include characters, conflicts, and settings.

- Examples: Short stories; novels; poetry; historical accounts.

- Expository: This style is used to explain a concept and share information with a broader audience. Expository writing utilizes evidence, statistics, or results, focusing on the facts of a certain topic. This style is not meant for expressing opinions.

- Examples: How-to articles; textbooks; news stories (not editorials or Op-Eds); business, technical, or scientific writing

- Descriptive: This style is used to depict imagery to create a clear picture in the mind of the reader. This approach establishes a stronger connection with the audience by appealing to their senses. Literary techniques such as similes, metaphors, and allegories are employed in descriptive writing to engage the audience. 

- Examples: Poetry; fictional novels or plays; memoirs or first-hand accounts of events

## Guided reflection (proficiency checklist)

1. Have you used the implications of words, tone, or style to communicate subtle or nuanced meanings?
2. Have you justified your use of connotation, explaining how the implications of your word choice reflect your purpose?
3. Have you provided alternate wording, tone, or style options and highlighted how your choice is preferable?
4. Have you effectively justified an evaluation of implications in a communication?

## Common pitfalls

1. The application does not identify or use the implications of words, tone, or style when prompted or does so mostly or entirely inaccurately.
2. The application uses the implications of words, tone, or style in ways that are inappropriate in a particular context.
3. The application does not provide justification for the word, tone, or style choices made.
4. The application does not consider alternative wording, tone, or style options.

## Applying the HC at Minerva

1. When writing a research paper, you should investigate the implications of certain word choices relating to the main concepts of the study. The connotation of the words used can significantly impact whether readers believe the findings of the study to be important, positive, or negative. For example, when the global COVID pandemic spread in 2020, studies began finding that greenhouse gas emissions were decreasing. This was good news for environmental scientists because they could study how when human mobilization decreases, carbon emissions also decrease, thus mitigating global warming. However, communicating these findings required a deep understanding of connotation. For one, you need to be sensitive to the anxieties of people experiencing a global pandemic; wording that holds cheery connotations may come off as tone-deaf. You also must communicate that decreased emissions mitigate but do not cure climate change and that the decreased mobilization of people must be sustained to have lasting effects. Thinking deeply about precisely what you want to say and understanding common misunderstandings allows you to effectively communicate your findings.
2. One of Minerva’s seven guiding principles is “Be Selective.” Think for a moment about why that particular term was used. Focusing solely on denotation, we could just as easily have said “Be Picky,” or “Be Choosy.” In fact, if you look up any of the three terms in the dictionary, you will probably see references to the other two. So what are the differences in connotation among pick, choose, and select?

Let’s start with pick. In addition to the meaning that overlaps with choose and select, pick is used to describe the process of collection without discrimination. If you pick fruit, you are not necessarily collecting only the very best fruit. It is also the name of a tool used in mining, which is related to the meaning in “to pick apart.” If you are making specific choices when “picking,” you may be focusing on trivial features. If you say that someone does not have a significant other because they are “picky,” you are implying that they reject people based on traits that should not bother anyone, like that they wore a green shirt that one time. To “nit-pick” is explicitly to object to trivial or insignificant details. 

Contrast that with choose. If you are choosing a piece of fruit, you are definitely evaluating multiple pieces and grabbing the best one. Likewise, if you are “choosy,” rather than “picky,” it implies that you have standards. The word “choice” is used as an adjective to refer to items of high quality, particularly in the context of food. 

Finally, consider select. If you select a dress to wear, there is no question that you have put thought into the decision. In biology, “natural selection” refers to differential reproduction based on advantageous qualities. Selecting something implies a much higher degree of intentionality than choosing or picking. The adjective “select” is often used to indicate premium versions of products like wine or olive oil. And if someone describes you as “selective” in your dating habits, you have standards, but they are completely legitimate. 

Notice that the shades of meaning between pick, choose, and select are even reinforced by the phonetics of the words themselves. “Pick” is the shortest of the three, with a single syllable consisting of two stops surrounding a short vowel. “Choose” also has a single syllable, but the vowel is longer, and both consonants are continuants. Just as it takes more time to choose an apple than it does to pick an apple, it takes more time to say “choose” than “pick.” Finally, “select” has two syllables, with continuant ‘s’ and ‘l’ sounds. You could also point out that select ends in a stop. Your mouth lingers over the first part of the word, just as you deliberate over your selection, but the word ends with a sense of finality, consistent with your having arrived at the optimal outcome.

## Applying the HC outside Minerva

You may use #connotation when faced with different claims in the media. For example, you may see an article that claims: "The widespread adoption of social media has led to a concerning erosion of real-world interactions." In this article, the word "erosion" carries a negative connotation, implying that real-world interactions are being gradually worn away or damaged by the use of social media. The gradual nature of erosion makes it seem like it is a long-term problem, but also an insidious process that can go on without our noticing consciously. The next day, you plan to share the article with a friend, and you notice that they have changed the headline, which now reads “Social media addiction is destroying relationships.” This version of the headline implies a much more urgent and nefarious situation. Having carefully read the article, you conclude that the revised headline misrepresents the actual evidence presented, and you decide not to forward the article, which now seems unnecessarily alarmist.

## Key resources

1. Anna, J. (2007). Connotation and Denotation. https://www.csun.edu/~bashforth/098_PDF/06Sep15Connotation_Denotation.pdf
- This handout outlines the differences between denotation and connotation, and describes how connotation can convey additional meaning. The exercises at the end will give you a chance to practice identifying connotations.
2. Wheaton College. (2009). Style, Diction, Tone, and Voice. Wheaton College. https://www.wheaton.edu/academics/services/writing-center/writing-resources/style-diction-tone-and-voice/
- This short article defines style, diction, tone, and voice. Focus on how all of these features work together to convey information. How do the connotations of specific words contribute to these features?
3. Writing Styles. (n.d.). The University of Rhode Island. https://web.uri.edu/graduate-writing-center/writing-styles/
- This resource breaks down some common writing styles.
4. Solomon, A. (2021, April 12). What Words We Use — and Avoid — When Covering People and Incarceration. The Marshall Project. https://www.themarshallproject.org/2021/04/12/what-words-we-use-and-avoid-when-covering-people-and-incarceration?fbclid=IwAR111levRBeQ9zmkTCU6stIVVABbPCUuD9q60ZCz1a2pxeLtE9MI5cnqhr8
- This short article demonstrates the power of words and the impact labels have on the lives of real people.


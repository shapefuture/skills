# #evidencebased — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/evidencebased/](https://my.minerva.edu/academics/hc-resources/hc-handbook/evidencebased/)
> **Habit of Mind** · Cornerstone course: Multimodal Communications · Competency: Thinking Critically → Evaluating justifications
> Taught in: Empirical Analysis | Semester One · Unit: Problem Solving
> Big Question: How can we feed the world? How should we allocate water?

## Definition

**#evidencebased** — Identify and appropriately structure the information needed to support an argument effectively.

> **Pitch:** An argument without evidence is merely an opinion.

A written or spoken communication intended to make a specific point should clearly present relevant and persuasive evidence. Doing this well is a two-step process. First, one must identify the evidence relevant to supporting the conclusion. The argument must be formulated to be consistent with the supporting evidence and should address apparent contradictions. Second, one must arrange evidence effectively. This means anticipating where one’s audience will notice a need for evidence, determining how much evidence will be needed given the strength of the conclusion, and deciding on how best to present the evidence (e.g., as a set of claims, a figure, a quote, or a paraphrase). In all cases, evidence should support underlying assumptions and show that the implications of the argument are consistent with established facts and principles.

## Worked example

You have a proposal for how to help your elementary school students learn math, and need to convince your academic supervisor that it is worth implementing. While preparing your presentation, you organize evidence to support two main lines of reasoning: interventional studies that showed the efficiency of the method and results of similar programs in other cities that were able to learn more complex materials with a curriculum involving this method. You select the best original figures and results, interpret them and add overarching conclusions from the individual examples and the evidence as a whole. You evaluate the studies you present, explaining the strengths and weaknesses of the evidence you use and explaining why it is generalizable to your school. Finally, you mention potential counter-arguments to the method such as the associated capital and labor costs, but explain why the advantages that the implementation offers outweigh the disadvantages.

> **Footnote:** Two main lines of evidence were employed to support the argument for the math curriculum modification. Raw findings and overall conclusions were presented and interpreted to support the merits of the program, and the use of evidence was justified through an evaluation of its strengths and explanation of their significance. Counter-arguments were considered and refuted.

## Is it this HC?

Is #evidencebased the right HC? If the answer to the following questions is yes, #evidencebased could be useful:

- Is the work explaining why a source is relevant to an argument?

- Is the work justifying the quantity, placement, and type of evidence given factors like the work’s audience, medium, length, and purpose?

- Is the work quoting, paraphrasing, summarizing, or a different form of restating another’s work being utilized?

- Is the work critiquing how an argument presents evidence to support its claim?

However, depending on the focus of your work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#sourcequality](sourcequality.md) | explains why a source is credible. |
| [#dataviz](dataviz.md) | supports its arguments using visual components like pictures or diagrams, including specific references, aggregate views, and trends. See the HCs for Visuals guide for more. |
| [#descriptivestats](descriptivestats.md) | outlines and accurately calculates specific quantities meant to summarize data like mean, standard deviation, and range. analyzes the implication of specific quantities. |
| [#induction](induction.md) | evaluates the strength and reliability of an argument given its evidence. uses multiple pieces of evidence to construct an inductive argument. |
| [#organization](organization.md) | builds the structure and flow of an argument by determining the best placement of sub-arguments and evidence. |
| [#medium](medium.md), [#audience](audience.md), [#context](context.md) | uses these HCs along with #evidencebased to identify where, what type, and how much evidence to present. |
| [#plausibility](plausibility.md) | evaluates the previous findings and assumptions underlying a hypothesis. |

## Self-study Q&A (5 questions)

**Q1. What counts as evidence?**

What counts as evidence depends on what the evidence aims to support or demonstrate. Empirical research and normative theory offer two different kinds of evidence, so it’s essential to match the evidence you use to the kind of argument you are making. For example, if you aim to support an empirical claim, like that large-scale scientific research contributes to our climate crisis through its use of carbon-based energy and emission of greenhouse gasses, then you need credible empirical evidence to support each component of that claim. If you are trying to support a normative (ethical) claim, like the claim that it’s ethically wrong to test cosmetics on animals, then you would need to provide normative evidence to support your argument about what makes such a practice wrong, drawn from an ethical theory. In some cases, you might need different kinds of evidence for different parts of your argument. For example, if you aim to support the claim that the death penalty is unjust in the context of racial bias in a country’s criminal justice system, you would need to provide normative evidence for the claim that a practice is unjust and empirical evidence for the claim that a particular criminal justice system suffers from racial bias.

**Q2. Is personal experience evidence?**

Evidence comes in many different forms: observation, news articles, official documents, interviews, surveys, experiments, and, yes, even personal experience. However, determining which type of evidence is most appropriate depends on the context. Personal experiences can be valuable evidence when your experience is well-aligned with your argument. However, it should not be your only form of evidence. Personal experience is most effective when it is paired with other forms of evidence. Rather than treating personal anecdotes as either sufficient on their own or entirely irrelevant, strong applications of #evidencebased triangulate personal experience with empirical data or research. You must also determine if you are a credible source in the specified context. For example, if you are writing an essay about the pitfalls of nationalism in your country, you may have valuable and credible experiences. However, if you are writing up an interventional study, your personal experience is not typically relevant. Check the #sourcequality handbook for more on how to evaluate the credibility of personal forms of evidence.

**Q3. How much evidence is too much?**

You will know you have too much evidence when new evidence repeats what existing evidence already states; therefore, the additional evidence does not add value to your argument. Cutting redundant evidence strengthens one’s argument by keeping the audience engaged and creating room for diverse evidence that supports the argument from different angles. Context is also important because more evidence may be appropriate in a formal report than in a creative story.

**Q4. Are direct quotes always required when offering interpretations of arguments or articles?**

No! Quotations are just one way to portray evidence. Using quotes can be helpful when the author’s words and tone are important to preserve. However, over-quoting will cause your work to sound disoriented, making it hard for the audience to grasp your ideas. Other ways to interpret evidence include paraphrasing, summarizing, and using graphs and visuals. These are great ways to utilize important evidence by capturing the main ideas in your own words. Often, presenting evidence in various forms is the best way to connect with your audience.

**Q5. Should researchers seek only evidence that supports their ideas?**

No. One should be cautious to avoid confirmation-biased research. It’s natural for individuals to seek evidence to support their ideas, however, a better application of this HC would involve gathering all relevant evidence that can inform an analysis of an issue, carefully evaluating the evidence, and then presenting it effectively. Actively seeking out counter-evidence and engaging with it critically can help one develop a more holistic understanding of a topic and deliver an overall stronger argument.

## Guided reflection (proficiency checklist)

1. Have you included evidence of the appropriate type (quantitative vs. qualitative, empirical vs. normative) or a combination of them in the given context?
2. Have you identified information that makes for compelling (relevant and substantial) evidence?
3. Have you backed every claim with evidence and explained how your evidence supports the claim?
4. Have you gone through your text and understood which pieces need evidence?
5. Have you clearly identified the argument you are backing up with evidence?
6. Have you sought out and considered any counter-evidence for your claims?
7. Have you used enough sources in consultation with assignment guidelines and discipline-specific norms?
8. Have you included in-text citations for every source listed in your references?
9. Have you effectively evaluated the presentation of evidence for a given purpose by others and justified the evaluation (when applicable)?
10. Have you included an annotation (footnote/endnote) highlighting how and why you’ve utilized evidence, demonstrating that you’ve considered alternative approaches?

## Common pitfalls

1. The application copy-pastes evidence from a source without additional analysis.
2. The application does not cite enough high-quality sources, given the author’s goal.
3. The application has evidence and a work cited page but no in-line citations, so it is difficult to know where the information comes from.
4. The application backs claims with evidence, but the line of reasoning is difficult to follow.
5. The application mismatches the kind of evidence and the claim it is designed to support, as in the case of using empirical evidence to support an ethical claim or vice versa.
6. The application trivializes a claim rather than substantiating the claim with evidence. Rather than write, “The majority of people in Brazil like their president,” and cite evidence like political polls or journals, the application states, “Some people in Brazil like their president.”
7. The application has data and trend charts but does not reference or analyze them.
8. The application relies on statements of personal opinions rather than making claims and backing them up with evidence.

## Applying the HC at Minerva

1. You research what causes tendonitis and existing treatments. This evidence fuels your hypothesis that a new medicine that claims to reduce inflammation and increase growth factors around the swollen area will reduce the effect of tendonitis in people. You administer an interventional study on the effect of a new medicine on people with tendonitis. There is a control group with tendonitis and no drug to compare to. You take MRIs of both groups before and after a month-long period. You do a p-test on your findings to determine whether or not this medicine had a statistically significant benefit, meaning it lowered inflammation. Your evidence could include the following: 
- A description of your process.

- The visual evidence from the MRIs.

- The p-test results.
You would then need to thoroughly explain what this evidence means and whether or not it supports the use of the medicine.
2. You are writing a paper that advances an ethical argument in favor of increased gun control measures in America. While you use empirical evidence to support your claim about the effects of gun violence, you primarily need to develop ethical theoretical evidence to support your claim that gun purchases should be limited. You decide to introduce Utilitarian ethical theory as the basis for your argument. Your evidence could include the following: 
- Analysis and application of the core Utilitarian ethical principle, the greatest happiness principle, to this case. 

- A counter-argument that poses an objection to this ethical principle, perhaps from a libertarian perspective in favor of a fundamental right to private property. 

- A response to that counter-argument on behalf of the Utilitarian ethical theory, and defense of the adequacy of this theory in support of your argument about gun control. 
You draw from textual evidence to support your interpretation and application of that theory to this example and support the credibility of this evidence by posing and responding to a counter-argument.
3. You are trying to persuade your Minerva peers that skateboarding is the best way to navigate San Francisco. Tailoring both your evidence and your presentation of this evidence to your peers informs your application in this case. For example, you may realize your audience is passionate about sustainability and has a short attention span. In that case, your evidence could include the following: 
- The use of a data visualization to show how much carbon other forms of transport emit compared to skateboarding, based on empirical evidence you find and cite. 

- You also use a personal anecdote of your great skateboarding experience. This is appropriate because you are acquainted with your audience, and you’re confident that they’ll find your experience engaging and credible.

## Applying the HC outside Minerva

This HC is always applicable in how we structure and present our point of view or any argument, whether tailored for our friends, co-workers, or boss. It is also relevant in many contexts, whether for an article, research paper, speech, or any other form of communication. Identifying and structuring relevant evidence effectively is essential to thinking and communicating critically.

## Key resources

1. Minerva Academic Team. (2019). Preparation Resources Writing - Evidence. https://my.minerva.edu/academics/curriculum/foundation-year/cornerstone-summer-preparation/resources/writing-resources/
- This guide is found by clicking the “Evidence” tab in Minerva’s Cornerstone Summer Prep Writing Resources. It describes common forms of evidence and tips for incorporating them effectively.
2. Minerva Academic Team. (2021). HC Guide for Visuals. https://my.minerva.edu/academics/hc-resources/additional-resources/
- This guide has a section on #evidencebased that describes its focus, use cases, and robust applications in the context of visuals.
3. Minerva Academic Team. (2022). Writing an Argumentative Essay. https://my.minerva.edu/academics/curriculum/foundation-year/cornerstone-summer-preparation/resources/writing-resources/
- You can find a guide on organizing an argumentative essay by clicking the “Writing An Argumentative Essay” tab in Minerva’s Cornestone Summer Prep Writing Resources. Refer to the “Incorporating evidence” section for more.


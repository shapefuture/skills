# #rightproblem — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/rightproblem/](https://my.minerva.edu/academics/hc-resources/hc-handbook/rightproblem/)
> **Habit of Mind** · Cornerstone course: Empirical Analyses · Competency: Thinking Critically → Analyzing problems
> Taught in: Empirical Analyses | Semester One · Unit: Problem Solving
> Big Question: How can we feed the world?

## Definition

**#rightproblem** — Characterize a complex problem in detail to really understand it.

> **Pitch:** If you’re not carefully characterizing your problem, you ARE the problem.

The first step to solving a problem is to characterize exactly what the problem is. This helps to ensure that proposed solutions address the right problem—the one that needs to be solved. Characterizing a problem requires specifying the initial and goal states, the obstacles that stand between the starting situation and the goals, and the scale of the problem. Different types of solutions are appropriate for problems that arise at different scales.

## Worked example

Events that ensure interaction between students and their rotation cities are at the heart of the Minerva experience. During the COVID-19 pandemic, these events were unable to happen as they originally did, as measures of social distancing and quarantine were in effect and many students studied remotely. Aiming to still promote student engagement and interactions, understanding the core problem was key to designing appropriate solutions. The initial state of the problem was that original in-city Minerva programs were canceled and students were at risk of feeling disconnected from their community. While some students were in rotation cities, a large percentage were totally remote. The goal state was for all students to have opportunities to engage with their class, feel a sense of belonging, and connect their academic experience to their student life experience. The scale of the problem concerned the whole Minerva community, internationally, though considering the problem at the cohort scale also seemed useful. The most relevant obstacles included (1) fearful mindsets about the pandemic, (2) the pandemic added uncertainty to planning, and (3) student routines and needs changed.

> **Footnote:** This application of #rightproblem consists of a problem-focused analysis, that starts with some general context but then narrows down to the problem characterization of initial state, goal state, scale and obstacles. It is important that this stage of problem solving is focused on understanding the depth and scope of a complex problem we want to solve, and ideation and selection of solutions will come up later on in the process. Ways this characterization could've been stronger include quantifying information about the scenario and including more aspects than just disconnect and lack of interaction (for example, the mental health impacts of the pandemic).

## Is it this HC?

Is #rightproblem the right HC? If the answer to the following questions is yes, #rightproblem could be useful:

- Does the work analyze and detail multiple aspects of a problem including the initial state, goal state, obstacles, and scale of the problem?

- Along with initial state, goal state, and scale of the problem, does the work identify a problem’s consequences and implications?

- Is the problem’s analysis robust, using reliable sources, and possibly incorporating additional HCs like #breakitdown and #constraints to make a more meaningful application?

Depending on the focus of the work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#breakitdown](breakitdown.md) | deconstructs the initial state of the problem iteratively into smaller subproblems analyzes subproblems in depth (determining which subproblems are most relevant) |
| [#constraints](constraints.md) | differentiates between constraints and obstacles. justifies the choice to classify aspects of the problem as constraints. specifies how a solution works within a constraint. |
| [#strategize](strategize.md) | describes one’s position in a complex system. leverages one’s position to meet a particular outcome. |

## Self-study Q&A (4 questions)

**Q1. What are some useful strategies to generate a more useful definition of the initial state of a problem?**

Quantify and specify aspects of the problem using reliable sources. For example, if you are characterizing San Francisco’s homeless situation, you might want to know what percent of their income residents use to pay for housing. You can use #breakitdown to look at elements of the problem you might have overlooked and consider how things change over time to analyze how and why problems have evolved.

**Q2. What are some ways you can obtain a specific, realistic, and comprehensive goal state?**

On top of identifying your goal state, support it with some evidence, using existing studies or reasonable estimations. For example, if you’re tackling a problem regarding energy crisis, you can look for ideas from existing urban sustainability reports. Try justifying the goal states: what made you think about this goal state? If you struggle to find an explanation, it may imply that the goal state is unrealistic. 

Alternatively, focus on the quantitative measures defined in the initial state. Using the same measures in the goal state makes the problem tractable. For example, if the initial state is that X% of San Francisco population is homeless, the goal state would be to reduce the percentage to Y%.

If applicable, consider multiple goal states as alternatives! Create an “interval” between the least and most optimistic goal state. Building from the previous example, the short-term goal state is to reduce the percentage to Y% within P years, while the long-term goal state is Z% within Q years.

**Q3. How do you determine whether an obstacle is relevant to a problem?**

Similar to goal states, key obstacles are usually discussed in existing studies. If not, it’s okay to identify a new obstacle, but make sure that it’s based on research. The main idea is to use reliable evidence and consider multiple stakeholders. 

Note that an obstacle is only a part of the problem. If you find yourself spending too much time on an obstacle, consider reframing the main problem.

**Q4. What are some factors you must consider when defining the scale of the problem?**

You should consider the stakeholders of the problem and multiple levels of analysis. For stakeholders, it might be useful to apply #systemmapping to think about different ways you can relate the stakeholders to each other. A problem can exist within multiple levels of organization. For example, the homelessness situation in San Francisco is a city-wide problem. However, narrowing the analysis to neighborhoods might ask you to understand how different neighborhood policies affect the problem. Considering the region or state, like the Bay Area of California, might reveal other factors that impact the problem.

## Guided reflection (proficiency checklist)

1. Have you identified, clarified, and clearly explained the aspects of a problem, like its initial state, goal state, scale, and key obstacles?
2. Have you identified likely future consequences of a problem?
3. Have you recognized and effectively critiqued an ineffective approach to a problem?
4. Have you identified and effectively corrected an ineffective approach to a problem?
5. In your HC footnote, have you included how and why you applied #rightproblem?

## Common pitfalls

1. The application’s problem characterization is too vague to be useful, or is only a partial characterization (e.g., missing goal state).
2. The application does not explain how someone measures whether the goal has been achieved.
3. The application does not consider obvious factors that are relevant to the problem.
4. The application includes inaccurate information that undercuts understanding of the problem (e.g., an obstacle is listed that is not actually an obstacle and giving it attention would make problem solving less effective).
5. The application makes this HC about “right” vs. “wrong” problems, using the colloquial 'right problem' rather than the more comprehensive HC.
6. The application sets a goal state that presupposes a solution.

## Applying the HC at Minerva

1. You’ll apply #rightproblem when doing the introduction or explaining the context to an explanatory challenge. You’ll encounter this when writing an essay for a course about history, creating an algorithm for a course on software development, or introducing the motivation behind a thesis in empirical research.
2. Your civic projects will often start with a research question or state a problem you will aim to solve. Characterizing the problem will be important to produce a successful project.

## Applying the HC outside Minerva

The UN Sustainable Development Goals are one application of #rightproblem because they lay out a clear and detailed goal state and define and break down obstacles by stating the scale of problem and ways to measure whether they have reached the goal state (SDG indicators).

## Key resources

1. Minerva University. (2019). Using #rightproblem to characterize complex problems. In Minerva Guide. https://docs.google.com/document/d/1hoiSKEGZ_zTg3I9mObblCq1rAq1zcu2cZYBuNnvq708/edit
- This whitepaper explains the four main aspects of #rightproblem.
2. Spradlin, D. (2012). Are you solving the right problem? Harvard Business Review. https://hbr.org/2012/09/are-you-solving-the-right-problem
- This article provides an overview of how to identify the right (or root) problem when faced with a complex problem. Focus on the tools and questions that may help you to identify the driving problem at the root of a complex issue. See this version to see comments of how problem solving HCs correspond to different parts of the article.

## Custom HC guides

- [Using #rightproblem to characterize complex problems](https://docs.google.com/document/d/1hoiSKEGZ_zTg3I9mObblCq1rAq1zcu2cZYBuNnvq708/edit)

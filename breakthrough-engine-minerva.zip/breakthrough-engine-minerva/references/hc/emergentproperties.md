# #emergentproperties — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/emergentproperties/](https://my.minerva.edu/academics/hc-resources/hc-handbook/emergentproperties/)
> **Foundational Concept** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Interacting with complex systems
> Taught in: Complex Systems | Semester One · Unit: Characteristics of Complex Systems
> Big Question: How should the world be governed?

## Definition

**#emergentproperties** — Understanding nonlinear effects of complex systems.

> **Pitch:** Give one person words and they will document their life; give two people words and they will invent language; give three people words and they will build the Tower of Babel.

Some properties of complex systems, such as mass, are easily understood as trivial combinations of the properties of their parts: the total mass of all Minerva students is the sum of the mass of each student. Other system-level properties are not easily understood as the sum of the properties of each part, due to the interactions between the parts: the total learning gained by Minerva students each year is not the sum of each student’s capacity for learning because interactions (e.g., discussion and joint activities) lead to additional learning. Emergent properties can usually, in principle, be analyzed and predicted in terms of the properties and interactions of the parts in a system; in practice, there are often limits to our ability to know and think about all parts and interactions, and so thinking in terms of the emergent property itself can be useful as well. Emergent properties typically occur at a higher level of analysis, and so emergent properties are macro-level properties.

## Worked example

Inspired by your first experiences learning and using Python, you join a group of students learning JavaScript. Indeed, you are so excited you then join a second JavaScript-learning group as well. You have particularly high hopes for the second group, since it contains a couple of students who already know some JavaScript and are particularly motivated to learn even more. In general, the students in the second group seem more knowledgeable, and also seem more motivated to increase their knowledge. Much to your surprise, it is the first group that learns more. The first group “gels” better, creating norms of mutual support and encouragement, and working together on tough problems, and so group-level properties like “commitment to working consistently towards better programming ability” are higher than would be expected just by looking at the individual members in isolation. Fourteen months later, most of the members from the first group are still working together, have branded themselves “Minerva’s Minions of Majestic Programming” (M3P), and have just won their first hackathon.

> **Footnote:** A group-level property is identified that, for two groups, is different than the sum of the individual properties (one group much higher than expected). This is explained in terms of the interactions between the individuals, and linked to a very different outcome for each group.

## Is it this HC?

Is #emergentproperties the right HC? If the answer to the following questions is yes, #emergentproperties could be useful:

- Is a high level phenomenon observed that is easily identified, but cannot be easily explained  when looking at the (simple) interactions at lower levels?

- Does the work investigate what factors on “lower” levels interact to create an unpredictable phenomenon on a “higher” level?

- Does the work analyze why emergence occurs?

- Is analyzing an emergent property helpful to understand the explanatory challenge?

However, depending on the focus of your work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#complexcausality](complexcausality.md) | focuses on analyzing the structure of causal relations (e.g., feedback loops, causal chains) leading to the outcome, which could be used to complement the analysis of emergence. |
| [#levelsofanalysis](levelsofanalysis.md) | describes the interaction between multiple levels (back and forth) to understand a system. An emergent property is when lower level interactions and properties create emergence at a higher level. |
| [#networks](networks.md) | describes the topology of a network and the relative position of its agents. evaluates how the network’s topology affects how information flows through the network. evaluates the consequences of including or excluding certain nodes in the network. network effects are an example of emergent properties. For an emergent property it is important that it is a nonlinear effect. |
| [#systemmapping](systemmapping.md) | considers multiple ways to connect agents in a system to address an explanatory challenge. A systems mapping might help understand what factors can explain an emergent property, but usually this requires insight beyond a visual representation of the system. |

## Self-study Q&A (3 questions)

**Q1. Imagine you are stuck in traffic. As per usual, cars are moving extremely slowly and instead of the usual 15 minutes it takes you to get from your home to work, you need to travel almost an hour, even though it’s clear that there aren’t four times as many cars because the street simply cannot take that many. Explain in a few short sentences, whether and, if yes, how this phenomenon is an emergent property, and how that is relevant if your explanatory challenge was to improve air quality in cities.**

The significantly increased amount of time it takes to travel is an emergent property, because it is not simply a sum of all the cars that are present on the road, but when a certain volume of cars make it through the street, a threshold is reached at which congestion happens. Also the increased number and complexity of decisions of each driver might matter. For example, some drivers react a little slower than others and that can have a significant impact in the presence of more cars. Additionally, knowing that there is traffic, drivers might get unnerved, and do many untypical movements which ultimately complicates the outcome. Tying this back, more traffic increases pollution because not only are cars more clustered together, but they also end up burning fuel for longer. Understanding how to redirect traffic to alternative routes will contribute to clearer air in larger cities.

**Q2. Explain why it is important to distinguish between system properties that are emergent and ones that can be explained as the summed effect of individual actions.**

One analyzes emergent properties always for the sake of a particular explanatory challenge. The explanatory challenges of complex systems require deep understanding of the systems and the ability to predict how the system would react if it were to be manipulated from the top-down or bottom-up. Understanding which properties would change from such manipulations and how they would change strengthens that prediction power and provides more depth to approaches to the explanatory challenge.

**Q3. What is the difference between ontological and epistemological emergence? Which type of emergence are we most interested in?**

Epistemological emergence is when we are not able to predict the emergence of a phenomenon because we have limited information about agents and interactions to fully predict what would happen, but that we could have predicted as a sum of the interactions had we had access to such models and knowledge.

Ontological emergence is when a phenomenon cannot be explained by a reductionist approach, it is inherently emergent. Something changes fundamentally when those interactions take place that complete knowledge about the lower level would not be enough to explain it bottom-up. 

We are most interested in ontological emergence, since it requires a truly complex systems approach, where holistic understanding and methods beyond reductionist science are needed to explain the phenomenon.

## Guided reflection (proficiency checklist)

1. Have you explicitly classified and justified a property as emergent?
2. Have you discussed how relevant factors might be causing that emergent property?
3. Have you explained why analyzing an emergent property is helpful to understand the explanatory challenge?
4. Have you discussed and justified how factors in a system could lead to an emergent property provided you have sufficient knowledge about the system?
5. Have you discussed how a manipulation of any part of the system could lead to a change in the emergent property and the system itself provided the unpredictability?
6. Have you discussed what makes the property non-reducible to its lower-level components?

## Common pitfalls

1. The application does not clarify the emergent property. Sometimes it is helpful to name the emergent property so the reader is on the same page about what is being discussed, and then to add justification for why it's emergent by explaining something about how the property arises.
2. The application does not elaborate why the property should be classified as emergent. Saying the property is “unpredictable” is not a defining feature of emergence (ie, one can’t get a strong score by saying, “it’s an emergent property because it’s unpredictable”), though it's true that it's often harder to predict emergent properties.
3. The application identifies emergent properties that cannot be measured because they only exist in abstract terms.
4. The application does not offer an explanation for how the property is “larger” than the sum of its parts.
5. The application does not explain how certain factors or specific interactions among agents are important to understand the emergent property.
6. The application does not describe the effect the emergent property has on the system.
7. The application does not describe what the existence of an emergent property within a system reveals about the system.

## Applying the HC at Minerva

1. Social Sciences: When many people come together and form communities, they can create properties that are not achievable on the individual level. You could think about cities, culture, or political systems all as emergent properties of the individuals and their interactions in it. It is always important to evaluate if the emergent property you describe is not just a property shared by all individuals, but something that just exists in the system of people.
2. Biology/Ecology: Trying to analyze how interactions in biological communities create complex livable habitats and a balanced ecosystem - e.g. How do the interactions between different pollinators maintain balance in flowering plant populations?
3. Chemistry: The properties of molecules depend not only on the properties of their constituent atoms, but also on the spatial arrangement of those molecules. For example, the polarity of water is not a simple sum of the properties of hydrogen and oxygen; it results from the relative electronegativities of the two elements and the geometric arrangement of the atoms in the water molecule.
4. Neuroscience: How do the connections between neurons in an artificial neural network end up contributing to the overall analytical power and complexity of the network?
5. History: Studying the historical interactions between academic institutions, political factors, and wealth that created the most inspirational environments for art creation - What environments produced bursts of artworks and what social implications did that phenomenon have?
6. Philosophy: Emergent properties pose ontological/etiological questions about the nature of the world. For example, a determinist worldview might argue that emergent properties are actually fundamentally predictable, but that we just have limited knowledge about the state or rules of the universe that we’d need to predict them.

## Applying the HC outside Minerva

1. Love: love is a combination of chemical reactions of your brain, higher-level concepts, different functions of the brain are involved like perception, emotion, memory. Simply put, love is not that simple. You cannot point at one clear origin of love, it is unpredictable. Maybe that is what makes it the most popular topic for movies, songs, poetry, and so on. If you are joining those on their quest to understand love, accepting its overwhelming complexity might be a good start…
2. You are a policy analyst working for an NGO and you have been tasked with studying the history of country A to understand whether the implemented policies fit its geopolitical and cultural landscape well to ensure prosperity. You analyze the main economic niches, present and past, the communication style and education level of the people, whether the country has easy paths of communication with neighbors, etc. Then, based on the data you collected, you attempt to explain emergent properties on the population level, such as mass migration which cannot be explained by simply looking at one factor. Finally, you tie your analysis back to the explanatory challenge and make predictions about how changes in the national policies could mitigate this migration of locals and improve the country’s standard of living.

## Key resources

1. Sheskin, M. (2021) Characteristics of Complex Systems – a Brief Introduction. https://docs.google.com/document/d/1cxCp8FqZB_bN_AaMTUgAnv36gu0bDEHpRwMgkEI5VX8/edit
- a Brief Introduction: this reading is the overview of how six characteristics of complex systems interrelate.
2. Mercer, E. (2018) What are emergent properties? https://sciencing.com/emergent-properties-8232868.html
- This resource provides a few basic examples to introduce you to the concept of emergent properties and their broadness.
3. O’Connor, T. (2021), 'Emergent Properties', The Stanford Encyclopedia of Philosophy. https://plato.stanford.edu/archives/win2021/entries/properties-emergent/
- This is an extensive reading that goes over many more examples than you will need in class, but is a good resource to go in depth for those interested.

## Custom HC guides

- [Characteristics of Complex Systems – a Brief Introduction](https://docs.google.com/document/d/1cxCp8FqZB_bN_AaMTUgAnv36gu0bDEHpRwMgkEI5VX8/edit)

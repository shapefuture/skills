# #levelsofanalysis — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/levelsofanalysis/](https://my.minerva.edu/academics/hc-resources/hc-handbook/levelsofanalysis/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Interacting with complex systems
> Taught in: Complex Systems | Semester One · Unit: Characteristics of Complex Systems
> Big Question: How should the world be governed?

## Definition

**#levelsofanalysis** — Analyze characteristics or behavior of a complex system, integrating explanations found at different levels of analysis and their interactions.

> **Pitch:** Think big. Think small. Think in between to find out more.

To understand and explain the characteristics and behavior of complex systems, one may conduct their research on different scales, or levels of analysis. For many of the questions we’re interested in, an explanation that is situated on one level of analysis may be insufficient on its own to address the explanatory challenge, and a multilevel analysis is necessary. For example, in trying to figure out why students of a particular course aren’t as engaged one may examine the individual students and their personalities but that investigation will be incomplete without also studying the academic culture of the students’ class and even of the institution as a whole. One useful way to demonstrate the value of multi-level analysis is to pay attention to the ways in which phenomena on one level of analysis affect or shape outcomes in other levels. Analysis on multiple levels would often, but not always, require different disciplinary approaches, which provide different tools for conceptualizing components.

## Worked example

After graduation, you and five friends plan to start a nonprofit to advocate for environmental issues. You have an ambitious 5-year plan to raise money and quickly scale to hundreds of employees. Part of your planning is to ensure that your nonprofit is a great place to work, so you investigate companies that seem to be doing a good job with that.

In a 2021 survey of 70,000 companies in the USA, the happiest employees were at Adobe. In an interview about ranking #1, you learn that Adobe identified employee preferences and ideas through surveys, meetings, and focus groups, and then (1) added days each month when the entire company had days off, (2) added community-building events, including an annual diversity and inclusion event, (3) allowed each employee to take an additional 20 days off of their choice each year, (4) allowed employees to have more flexibility in their work schedules, especially in recognition of family responsibilities, and (5) reimbursed an additional $600 per year for expenses related to health and wellness. 

You think about how these items worked on many levels and interacted with each other. The most important to you seem to be the community level of the company as a whole, each worker’s friend or family circle, and finally, each worker. You identify how crucial a healthy working environment is for a person’s overall mood based on a psychological study that you read and how feeling good after a day at work may make a person more receptive to the moods and feelings of their closest people. You clearly outlined the mechanism through which less stressful working environments are likely to influence healthy family dynamics significantly. On the other hand, you analyzed how spending more time with family and friends makes a person more well-rested (individual level) and boosts their working creativity, which improves the company’s productivity overall (working community level) by providing additional examples of effective companies based on employees self-reported satisfaction with their family situation. 

As your startup grew, you learned how Adobe got to #1 on employee satisfaction. In an interview, you discovered Adobe’s enthusiasm for community-building events and wondered how creating a shared sense of togetherness at a group level depended on each person (individual-level) showing up happy and well-rested (biological level).

> **Footnote:** In your attempt to understand the phenomenon for Adobe’s success you consider the individual employees’ lives at multiple levels and how those might interact to support the company’s productivity. First you analyze how the community building events have a beneficial effect on the employees’ attitude towards the work process and how that attitude is transferred to their personal lives. Then you look at how the extra time they dedicate to their personal lives contributes to their work performance. Finally, you identify how both of those levels impact each other through the level of the individual and how the individual’s perception of their situation might influence their work and family life

## Is it this HC?

Is #levelsofanalysis the right HC? If the answer to the following questions is yes, #levelsofanalysis could be useful:

- Are you analyzing a complex system on different levels to understand it holistically?

- Does understanding the interactions between different levels of a system aid in your explanatory challenge?

- Are there multiple relevant physical scales (e.g., micro, macro) on which you could analyze the system to understand it as a whole?

- Are you employing different analytical lenses or evidence for different levels while simultaneously integrating those?

Depending on the work product, there might be other HCs to consider. Not all analyses about a system will be #levelsofanalysis.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#complexcausality](complexcausality.md) | Focuses on the complex ways in which causes interact (like creating feedback loops), which could be possible between levels of a system; however, it does not necessarily address the nature of those levels, and would often involve causes at a single level. |
| [#systemmapping](systemmapping.md) | Defines characteristics of each component, regardless of their scale. |
| [#emergentproperties](emergentproperties.md) | Analyzes how the agents and interactions at one level produce a qualitatively distinct and interesting group-level property at a higher level. |
| [#psychologicalexplanation](psychologicalexplanation.md) | Investigates the interactions between inner psychological states and environmental factors that can affect those states. You might find psychological explanations between different levels of psychological analysis. |

## Self-study Q&A (11 questions)

**Q1. What does it mean to analyze the "interactions" between levels? Give an example.**

Often, students apply this HC by listing explanations from different levels, without addressing how those explanations influence each other. Any example that has causes from different levels affecting each other is great!

**Q2. Why is analyzing the interactions between levels important? What can it tell you?**

Oftentimes, addressing a question or an explanatory challenge at a single level provides insufficient explanation, and multilevel analysis is necessary for a nuanced understanding of the complex system. For example, floating ice is a large-scale phenomenon that can be observed by the naked eye and we can understand its importance for aqua systems without looking at any other scales. However, we can only explain the low density of ice by looking at the organized arrangement of water molecules.

**Q3. How might multi-level analysis allow one to understand an emergent property?**

Emergent properties almost always arise at higher levels from interactions within a lower level. Multi-level analysis can help explain emergent properties that arise from causes at multiple lower levels, or it can also help understand how the emergent property might interact again with those lower levels. For example, company culture is an emergent property from employees' individual characteristics and interactions, but it also affects and alters individuals.

**Q4. Describe an example of a multi-level analysis.**

Many examples are possible. Remember that for a strong application, you will need to address the nature of the relationship between the levels and how they influence each other.

- Economics (microeconomics and macroeconomics)

- Materials science (where we might consider molecular properties and their relationship with macro-scale physical properties of a substance)

- Neurobiology (molecular properties of proteins --> behavior of individual neurons --> function of brain regions and neural pathways -> behavior --> social interaction)

- Psychology --> Sociology

**Q5. Which of the following situation(s) would #levelsofanalysis not be appropriate for? 
- You are trying to find your closest connection to a person you have an interest in meeting so you begin analyzing your common friends/acquaintances, their broader social groups, and their everyday activities.

- You are interested in figuring out the interactions that make water able to “climb up” the tubes inside plants to supply them with nutrients. You have some knowledge about the properties of water molecules themselves, but you are unsure of why those properties arise, and how they interact with the properties of the tree tubes.**

- In the first one #levelsofanalysis will not be appropriate. Your aim is to find the position of the person of interest in a certain community of other people and potentially identify key aspects of their life that they interact with often (#systemmapping). However, you do not want to move between levels too much (such as trying to identify the psychological reasons why your person of interest chose those specific activities to act on), because that may ultimately prove unnecessary. Here are two key things to remember when you are applying for an HC: the simplest possible answer to the explanatory challenge is preferred, and your arguments should be backed-up with evidence. You may also be tempted to think about #networks, however in that case you would need to explain an effect that arises as a consequence of the structure of the network. While that is perhaps possible, unless the network is at least relatively homogenous or has a very influential binding characteristic, your answer may drift towards speculation.

- Here #levelsofanalysis will probably be relevant. This question is a great example of how you can transfer HCs outside of the realm of their core competency. You will need more chemical knowledge here, but generally you have a few things to consider - the interactions between the particles of a water molecule (level 1), the interactions between the molecules themselves (level 2), and the specific chemical structure of the tree tubes (level 3), and how it affects the lower level properties of water that make is possible to overcome the gravitational pull.

**Q6. What are the preliminary steps you need to take when you analyze a complex system? Where might this HC fit in?**

We always try to break complex systems down into its parts and think about the interactions between them, while also using tools of holistic analysis. This HC tries to break down a system in scale, while other HCs might look at causation closely (#complexcausality) or system structure (#networks and #systemmapping). Important with any complex system HC is to integrate the approach with the holistic understanding of the system.

**Q7. How do you know if you are focusing on the most appropriate level(s)?**

A strong application of #levelsofanalysis involves the identification of the most appropriate levels. The appropriate level of analysis should contribute to your understanding of the complex system. If you are using this HC in problem-solving, it is important to think whether the causes identified on a particular level can be addressed given its scale and your constraints.

**Q8. Is the following a good application of #levelsofanalysis - why or why not? Justify your answer in one to a few sentences, then double check with the answer key. 

You are trying to analyze the impact of cars for everyday use on the environment. You start from the level of the individual car, and you acknowledge that almost every car, no matter whether it is electric or petroleum based, has some impact on pollution. Then you move up to a country scale and you conclude that the large numbers of personal automobiles are a likely reason for bad air quality, and even increased costs for medical care, because many people develop disease as a consequence of the exposure to polluted air.**

This is NOT a strong application of #levelsofanalysis as is. One reason is the lack of explanation for how the different levels influence each other. For example, the application could have mentioned that the increased levels of exhaust gasses have increased temperatures in cities (a phenomenon known as the urban heat island effect), which in turn prompts more people to drive around rather than use public transportation, bike, or walk. Also, for a strong application of this HC, additional levels should be analyzed. For example, we can look into the personal level (how are individuals influenced by this?), the city level (island effect, city-wide policies, public transportation), and then the national level (possible migrations from big cities to more rural areas, water pollution, public health). This more comprehensive multilevel analysis is likely to yield new insights about the system.

**Q9. Which of the following #levelsofanalysis are relevant to the Cuban missile crisis? 
- The personalities of J.F. Kennedy and N. Khrushchev who ultimately approached the situation analytically rather than impulsively. 

- The state of the Cold War between the US and the Soviet Union at that period and the race for global influence.

- The broader geopolitical situation that involved Cuba as an ally to the Soviet Union and Turkey - to the USA.

- The reaction of the American citizens to the situation and their overall support for the leaders.**

All of them would be relevant. Generally speaking, political leaders hold the power to execute important decisions, but they always operate within a specific socio-political context that determines their agenda and are (some more than others) dependent on their voters’ sympathy. Tying things to the example above, Kennedy and Khrushchev both had sufficient power to order the deployment of nuclear missiles had they wanted to, given the structures of the USA and the Soviet Union. The reason that was a possibility in the first place was the Cold War. However, the war itself does not determine the details of the political course a leader would take, so both levels influence each other. The reason why the crisis happened in the first place was the strategic location of Cuba for the SU where the Soviets decided to place nuclear weapons. The US responded by doing the same on Turkish territory. Finally, the public opinion of the US citizens was important for Kennedy because he was aware how catastrophic a potential nuclear war could be and also because of the possibility for a new election.

Note that analysis of a complex historical event like this would almost certainly involve the application of several other HCs, including non-complexity HCs.

Also note that, depending on the scope of the analysis and the specific explanatory challenge, you might focus on only two or three of these levels. However, you would want to consider the potential importance of all of the levels, even if some of them did not make it into your final work product.

**Q10. What are some ways #levelsofanalysis are misapplied in the real world?**

- Giridhardas criticizes those who focus on social change on an individual rather than political level. He argues that individual efforts to improve the world, without acknowledging the exploitative structures they might encourage is short-sighted. Basically: you cannot understand making change as effort on one level without analyzing the effects on/from other levels.

- Michelle Obama’s book is criticized as focusing on personal empowerment at the expense of engaging structural racism.

**Q11. How does the idea of embeddedness relate to #levelsofanalysis?**

Embeddedness is an idea that highlights that individuals, groups of people, large organizations are situated within overlapping social contexts that shape their behavior. With #levelsofanalysis, this concept can be examined across multiple levels and can be systematically analyzed through the interactions between them.

For example, when explaining migration, an individual-level explanation may focus on a person seeking a higher-paying job. However, a multiple-level analysis of embeddedness would consider how that individual’s decision process is impacted by 1) family obligations (household level); 2) influenced by information and support received from migrant networks(community level), and 3) affected by labor trends and by broader migration trends within their home country or the region (societal level).

At a higher level (global level), embeddness can also be analyzed by examining how institutions and policies shape migration patterns. For example, immigration laws or economic agreements between countries create conditions that support or limit global mobility. These higher levels of analysis subsequently influence community-level networks that impact and shape individual-level decisions of migration.

Thus, #levelsofanalysis allow us to demonstrate that embeddedness is not just an individual experience, but is a dynamic interaction across multiple levels from individual choices to institutional structures and policies as well as influenced by global trends.

## Guided reflection (proficiency checklist)

1. Have you clearly identified the explanatory challenge or context and the levels most relevant to that challenge?
2. Have you clearly identified two or more levels you are analyzing and made clear distinctions between them?
3. Have you used different and appropriate lenses/disciplines for the different levels of analysis?
4. Have you justified why an analysis on multiple levels is necessary, and why analysis of the levels you chose to analyze is sufficient?
5. Have you justified why the levels you chose are relevant to your explanatory challenge?
6. Have you justified why analyzing multiple levels is better to understand the problem than analyzing only one level?
7. Have you justified your focus on one or more particular levels?
8. Have you explained how the levels interact and influence each other?
9. Have you gone beyond simply listing levels and provided an analysis of the levels and how they shape each other?
10. Have you integrated the insights from several levels to address the explanatory context?
11. Have you applied this HC in a way that serves your purpose and elevates your work product?
12. Have you included an annotation (footnote/endnote) to highlight how you’ve used the core elements of this HC and why it was relevant for your purpose?

## Common pitfalls

1. The application misinterprets what a “level” is and focuses really on different paradigms.
2. The application talks about different agents influencing each other, but all the agents belong to the same level of analysis.
3. The application mentions but does not describe the levels of analyses.
4. The application explains the effect of different levels, but does not explain how the levels of analysis are connected to each other.
5. The application footnotes this HC for purposes more relevant to other HCs (refer to section “Is it this HC?”).

## Applying the HC at Minerva

1. Physics: Magnetism, for example, is observed on macroscopic scales, but its origin comes from the movement and individual spins of electrons, how the shells of different atoms line up, and how the domains in the crystal structure are aligned. The direction of the spins of electrons affect the magnetic property of a mass of atoms, but at the same time can a magnetic field change the direction of the spins of electrons - microscopic properties affect macroscopic properties and vice versa. An analysis of the origins of magnetic properties at different levels and the interactions between these different "levels" gives us the full picture of magnetism.
2. Economics: Macroeconomic phenomena often have microeconomic origins and microeconomics are influenced by macroeconomics. This is one way in which economists often forget to think between the levels that they commonly analyze. Such applications are usually fruitful! But you can think of other levels within economics, like individuals, a country’s economy, and the global economy.
3. Materials science: We might consider molecular properties and their relationship with macro-scale physical properties of a substance. You might come across a (soapy) chemical that is frequently used to create bubbles with air. This bubble forming only happens at a larger scale, but how can the structure of a molecule explain the way that a bubble maintains itself? You can explain what happens between atoms and how this creates charge divisions within the molecule or hydrogen bonds, you can explain how hydrogen bonds manifest between molecules, and how groups of molecules attach to each other in the shape of a bubble when air is blown against a layer of them.
4. Neurobiology - Psychology - Sociology: Molecular properties of proteins, for example ion channels, can affect how a neuron cell as a whole (made up of many types of proteins) works or develops. This in turn affects behavior of individual neurons, which might explain the function of brain regions and neural pathways. And from that level, you might explain individual behavior or even social and group interactions. This is useful when working on cases that require an approach across neuroscience, psychology, and sociology, which is something most scientists aren’t as much used to doing! Remember that in these fields too influences can go both ways (lower levels influencing upper levels and the opposite). When someone makes you angry (social interaction), it can lead to a biophysical response at the molecular level! Whenever you are trying to understand any neurobiological phenomenon, be sure to look at the levels below or above that are interconnected with that phenomenon.

## Applying the HC outside Minerva

1. You can use this HC to respond to people’s analysis of almost anything that happens in a system. For example, if your grandpa believes that criminality is explained by someone’s personality alone, you can explain with your knowledge about systems that there are almost always interacting causes from other levels too, recognizing that that might be a different discussion from responsibility, but at least helps you intervene effectively!
2. You can imagine a multi-level analysis being useful when addressing a company’s culture. For example, if a company saw a decline in employee satisfaction and productivity, they could consider the issue at multiple levels: individual micro level, a team or department at the intermediate level, and the organization at the macro level. This would illuminate several scales of factors, including work-life balance, team dynamics, resource allocation, and company values. Such an approach offers insights into how these different levels may be affecting each other, for example, how organizational company culture can mitigate micromanagement at the team level and improve individual job satisfaction. This holistic analysis also helps the company intervene at the most appropriate level.
3. You can use this HC to understand yourself (#selfawareness). “Which higher levels influence me, and which lower levels of my biology influence my consciousness?”
4. Similarly, it can help you understand others based on which levels of context they are embedded in. It can cultivate empathy
5. The term ‘levels of analysis’ is used in social sciences and is often used in research. 
- For example, in Political science there are four levels that are most often used for analysis and decision making: individual, domestic/state, systemic, global. 

- Another example is cognitive science. There are different approaches to using #levelsofanalysis as a tool. One of them is Marr's tri-level hypothesis that involves the computational, algorithmic/representational, and physical/implementation levels.

## Key resources

1. McAllister (2018). Levels of Analysis for Evaluating Complex Systems. https://docs.google.com/document/d/1x2-iCWle8LPHG2_wuTLDmqOGNf26v8Cm23huUm-looE/edit
- A custom Minerva HC guide on this HC exists. It’s the main required reading.
2. Sheskin, M. (2021). Characteristics of Complex Systems – a Brief Introduction. https://docs.google.com/document/d/1cxCp8FqZB_bN_AaMTUgAnv36gu0bDEHpRwMgkEI5VX8/edit
- This reading is the overview of how six characteristics of complex systems interrelate. It goes more into depth into each HC and how it is different from the other HCs.
3. McAllister (2019). Organizational Structure in Complex Systems. https://docs.google.com/document/d/1zv1RS5KRTSYlMC2LnOpi1jnNlarCQYLqKaRt2gdKIZM/edit
- This reading provides a brief introduction to the different aspects of organizational structures.
4. Core Concepts in International Relations: Levels of Analysis. [Video] https://www.youtube.com/watch?v=TlKXysc6yPg
- The topic itself is not important here but how they present and actual explanatory challenge and look at different levels to gain deep understanding of such a “complex” complex system as the global political scene.

## Custom HC guides

- [Characteristics of Complex Systems – a Brief Introduction](https://docs.google.com/document/d/1cxCp8FqZB_bN_AaMTUgAnv36gu0bDEHpRwMgkEI5VX8/edit)
- [Levels of Analysis for Evaluating Complex Systems](https://docs.google.com/document/d/1x2-iCWle8LPHG2_wuTLDmqOGNf26v8Cm23huUm-looE/edit)

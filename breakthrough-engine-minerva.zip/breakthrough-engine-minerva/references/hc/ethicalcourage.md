# #ethicalcourage — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/ethicalcourage/](https://my.minerva.edu/academics/hc-resources/hc-handbook/ethicalcourage/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Resolving ethical problems
> Taught in: Complex Systems | Semester Two · Unit: Prudence and Effective Interactions
> Big Question: How can we enable and support diversity while eliminating domination?

## Definition

**#ethicalcourage** — Identify and analyze psychological, social, and material costs of acting in accordance with one’s considered ethical judgment; devise strategies to act ethically in the face of such costs.

> **Pitch:** Sometimes it's not that hard to know what's the right thing to do, but actually doing it is hard.

It’s often challenging to figure out what the right thing to do is or even notice that there’s an ethical dimension to what may seem like a benign decision. Even when we have firm convictions, considered opinions, and keen attention to ethical considerations, we may find ourselves struggling to follow through on our ethical commitments when we act. Ethical courage requires understanding and overcoming these impediments, which range from external social pressures to internal psychological barriers. Ethical courage also often involves social costs, like alienation or ostracism by others, or physical risks posed by those whose acts one may be ethically required to resist. Beyond identifying these impediments, ethical courage also requires proposing realistic strategies to resolve them.

## Worked example

Having spent most of your time in high school focused on liberal arts, you learn a lot about tech when you arrive in San Francisco to start your Minerva journey. A week after you settle in the res hall, you have 15 new apps on your phone. About half of them are ones you’ve never heard of before. One of these apps allows students in your class to post anonymous messages about whatever they want. It is supposed to be a space to ask questions and get help about mental health issues, but you quickly learn that it’s where many rumors are circulated, including personal information (like who is dating who). You find it a little troubling at first, but it really starts to bother you when one student becomes a frequent target for nasty messages. She is a quiet student who doesn’t engage much socially and speaks very slowly. You start hearing impatient sighs when she is called on to talk in class and it makes you feel very uncomfortable. When she incidentally appears in a Minerva Quest vlog for a few seconds, someone posts an edited version of it to the anonymous app, slowing it down to make her sound ridiculous. A string of memes then follows with other students reposting the clip with a variety of cheap photoshopped modifications that receive lots of emoji responses. Someone then writes… “you all are just assuming that she isn’t on this app… but maybe it’s better if she is lol.” 
After that, you can’t take it anymore and decide you’re going to respond. You hate doing this because you already have a reputation as a party pooper for complaining about noise in the study room during quiet hours. You decide you’ll just have to live with it and find friends among people who really know you. You write a long message in the anonymous app and reveal your identity. You say it’s not cool to make fun of someone like that and that it’s not the purpose of the app. No one responds to your message, except for thumbs-up emojis, but the activity there dies out completely. You also note that people are much more careful about reacting in class when the targeted student is talking. To your face, people only express support for your post, but you also find that you aren’t invited to many social events and it becomes harder to make new friends. This feels bad but you also know that this attitude will pass, and that in time, you’ll find the right people for you. Plus, you’re happy that the bullying stopped, at least in public.

> **Footnote:** This example reveals a case where the right thing to do was obvious but hard because it went against the grain. No one else spoke up and many people participated in the bullying so the individual knew that saying something would not be seen well by many students. They took advantage of their own moral outrage and the anger felt after seeing some of the particularly nasty messages to gather the mental fortitude needed to say something. In addition, they anticipated the consequences and prepared mentally for the result, thinking of different ways to make friends.

## Is it this HC?

Is #ethicalcourage the right HC? If the answer to the following questions is yes, #ethicalcourage could be useful:

- Are you focusing on how to do the right thing rather than why?

- Are you analyzing the costs of acting ethically and describing how to overcome or cope with those costs?

- Have you identified a case where it is challenging to act on one's moral convictions? 

- Does your application feel like a practical approach to an ethical problem?

However, depending on the focus of the work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#ethicalconsiderations](ethicalconsiderations.md) | explains which factors are morally significant and why, often by placing them within existing value systems or moral frameworks. It is a purely theoretical ethics HC, focused on identifying different lines of reasoning. (At the end of the Self Study section, there’s a nice practice example  that integrates all three ethics HCs and helps you distinguish the contribution of each one.) |
| [#ethicaljudgment](ethicaljudgment.md) | builds a case for one moral stance, addressing arguments from multiple sides and justifying the choice of judgment. It is about determining what is right, but not necessarily about how to do what’s right.(At the end of the Self Study section, there’s a nice practice example  that integrates all three ethics HCs and helps you distinguish the contribution of each one.) |
| [#responsibility](responsibility.md) | is about taking personal responsibility for one’s commitments and following through. When these commitments are moral – to do the right thing – and courage is a way to overcome them, these HCs might go hand in hand. . |
| [#utility](utility.md) | is about analyzing the decisions of individuals as utility-maximizing but recognizing the biases involved herein. Watch out! This is often directly conflated with utilitarianism, but utilitarianism is a set of ideas about how we should make decisions, not a theoretical and psychological framework about how we do make decisions. If you are analyzing the costs that are posed by an individual’s utility calculation, you could build your #ethicalcourage application on this. |
| [#evidencebased](evidencebased.md) | uses and structures evidence to support a claim or argument. You might want to include evidence about the social, psychological, and physical risks of decisions to inform the first step of your #ethicalcourage application (identifying costs). |
| [#conformity](conformity.md) | focuses on analyzing social norms, their appropriateness, and how people conform to them; such analysis can go hand in hand with applications of #ethicalcourage because decisions about whether or not to abide by or overcome social norms commonly involve ethical costs. |

## Self-study Q&A (8 questions)

**Q1. What two things do we do to be able to act based on a controversial ethical position?**

Steps:

- Identify the costs of such action.

- Suggest strategies to overcome those costs or stand in their adversity.

**Q2. What are, broadly speaking, the two types of costs we might face when taking ethical action?**

Internal costs (psychological) and external costs (social, material)
An example of internal cost can be the balance of a moral equilibrium, by which a person does not feel required to act ethically in one situation as they already acted ethically in another situation in a close period of time. Another example involves the diffusion of responsibility, by which an individual perceives as acceptable not intervening in a situation as other individuals present are also failing to intervene. 

External costs may include fear of being ostracized from a social group or some kind of retaliation among the group individuals for acting against the general trend even if it is ethically to do so. There may also be material or personal costs to acting ethically, like a large economic burden or danger to oneself.

**Q3. Why do we need “courage” for ethical action?**

If being ethical was easy, everyone would do it. It is almost embedded in ethical philosophy that good deeds might not come naturally or costlessly. Ethical reasoning must be paired with our ability and willingness to put our beliefs about what we should do into action. In some cases, our ethical reasoning leads us to believe that we should do something that is at odds with our immediate self-interest. Making a decision that is not beneficial to yourself requires strength, courage, and commitment.

**Q4. Which central skill at Minerva is particularly relevant for the second step of #ethicalcourage - suggesting strategies to overcome costs of an ethical decision?**

Creative thinking.

Once you identify what you should do (#ethicaljudgment), there are myriad ways in which you can execute that plan and deal with the consequences. Identifying creative ways to work around costs that might prevent you from acting on your beliefs is essential. You might need to think outside the box to reframe the situation and find opportunities in the face of those costs.

Other possible answers: perseverance, interacting effectively with others, …

**Q5. You have identified the costs of an ethical decision, but they seem inevitable/unavoidable. How do you still apply #ethicalcourage effectively?**

You could devise strategies to deal with the costs internally too. For example, there might be unavoidable mental or social repercussions of a decision. Still, you could find ways to make yourself resilient against those, seek out social support elsewhere, or develop ways to process those costs better. “How do you cultivate courage within yourself in the face of the costs of ethical decisions?” is a question you might ask yourself.

**Q6. SYNTHESIS: How do #ethicalconsiderations, #ethicaljudgment, and #ethicalcourage work together? Use the following example to explain when each HC is applied.**

This excerpt applies all three #ethics HCs by building from #ethicalconsiderations to #ethicaljudgment, and finally to #ethicalcourage. See the notes below. 

Introduction: You are an important member of Extinction Rebellion - an environmental activist group - and believe that disturbing people’s daily lives by blocking roads (civil disobedience) is justified in the face of exacerbating climate disaster and appalling lack of action from governments and industries.

#ethicalconsiderations: Individual and community values of health are at stake in the effects of climate change, both for human and non-human populations, and you believe that all living beings are ethically significant. You also believe that forms of civil disobedience are conducive to virtuous behavior, exercising a form of civic excellence and that your community should support your exercise of disobedience in this case. 

#ethicalconsiderations is applied briefly in the passage above by highlighting what makes climate change ethically significant regarding the well-being of humans and non-humans. It also mentions the ethical value of civil disobedience. A stronger application would go into more detail about the specific ethical values and principles underlying this analysis. 

#ethicaljudgment: You aim to defend the claim that activists should block roads as a disruptive tactic in this case. You have evidence of success with environmental policy changes that amplify the voices of the public in favor of the change can be effective, and your group is considering whether they should protest by disrupting the daily lives of everyday citizens or take a more targeted approach and focus on directly disrupting fossil fuel activity. You adopt a utilitarian ethical lens to consider each option. On the one hand, directly interfering with activities of the fossil fuel industry seems especially effective in the short-term, but you learn from comparable examples that protesting at companies does not attract enough attention for your voices to be taken seriously or incentivize change in the long run. The costs to the activists at such events outweigh the benefits. You then consider blocking roads within the city to gain public visibility. It draws enormous attention when timed before a relevant vote and planned effectively to gain attention without blocking access to necessary services. It has a higher chance of motivating individuals to demand action from policy-makers. In the second case, the benefit of motivating the public to vote in favor of fossil fuel regulation outweighs the costs to everyday citizens regarding their traffic disruption.  

#ethicaljudgment is applied in the passage above by defending an ethical claim – namely, that activists should protest by blocking roads used by everyday people – by (a) explaining the ethical lens and values to which they are appealing in defending this claim (in this case, how utilitarianism supports this claim), and (b) considering and responding to an alternative ethical action. Here too, a stronger application would more carefully engage with the background ethical theoretical lens employed and would possibly consider two alternative ethical values in conflict in this example (perhaps the value of the greater good vs. the value of justice). Greater care to back up the empirical assumptions and claims would also strengthen this application.   

#ethicalcourage: For the sake of this example, there are multiple costs that activists will face. First of all, this action might have legal and physical consequences: activists could be (violently) arrested, held in jail for long times, and possibly get a record with the police, even if protesting is a civil right protected within this (imagined) society. Secondly, activists risk immediate social backlash from traffic participants and social media backlash from people disagreeing with your arguments or your strategies. Lastly, activists could suffer from mental strain from the blockade, the negative reactions from people around them, and possibly online harassment. 

You want to keep your fellow activists engaged and address those costs. You realize that as an organization, you can prepare individuals by providing training about civil disobedience so that protesters are prepared to respond to police and avoid violating their rights (which is unfortunately common). Additionally, these training sessions can prepare you for the mental strain. Secondly, you think that community-building will be an important source of social safety within the movement, so you decide to group protesters with a buddy they look after and create smaller subgroups that stick together. To address the social backlash, you reiterate in your communications and protest that you see the disturbance of people’s lives as unnecessary but a last resort because governments and companies don’t act. Creative protest signs like “I also wish I was home already, but I might not have a home in 50 years!” can help communicate this to the general public. In time, you hope that more people will sympathize with the actions. 

#ethicalcourage is applied in the last two paragraphs. This approach identifies the different costs (psychological, physical, and social). The identified costs are based on observation of environmental movements and how police and the public have treated them in the past. (A stronger application would back these costs up with empirical evidence.) After this, this explanation addresses multiple strategies: preparing individuals, building a connected movement, and adjusting the language of the protest. What is especially good about this application is that the strategies are coherent with the ethical principles from which you made the decision (about the value of the long-term greater good), meaning that the moral value of the action stays consistent. It also refers to #audience considerations in thinking about how the rhetoric of protest signs can support conditions for the activists to exhibit #ethicalcourage (and, again nodding to the utilitarian value in this example, promotes the effectiveness of the protest).

**Q7. Do I have to tag all three #ethics HCs when I tag any one of them?**

No. Tagging all three (#ethicalconsiderations, #ethicaljudgment, and #ethicalcourage) would be a good idea only when you have the space to apply all three especially well in an assignment. You’ll often be asked to focus on some, but not all, of these HCs. For example, you might be asked to defend a position on universal basic income, in which case you should definitely apply #ethicaljudgment, and possibly #ethicalconsiderations (depending on how much background information you take for granted and assignment instructions). 

However, whenever applying #ethicalcourage, you have implicitly (or explicitly but shortly) decided what is ethically important (#ethicalconsiderations) and what action is the most ethically appropriate (#ethicaljudgment). 

Understanding how all three can be scaffolded effectively is important, even if you do not tag all three in one particular work. As a general rule of thumb, it’s a good idea to reflect on the central purpose of your assignment and tag those HCs that are most relevant and use the Guided Reflection below to check whether your application is complete. It’s also good to ask an instructor for advice about HC tagging priorities.

**Q8. Can #ethicalcourage be applied to analyze others’ actions?**

Yes, this HC can be applied to analyze others’ actions as long as you can provide evidence of the challenges an individual faced when acting morally and the process they underwent to do so. This application may occur in the context of a biography where you can provide a detailed account of someone’s internal and external impediments to ethical action, as well as the means they employed to overcome them.

## Guided reflection (proficiency checklist)

1. Have you considered a wide range of possible costs, from psychological and social costs to material and physical costs?
2. Have you researched the relationship between those costs and ethical decision-making? For example, if you’re arguing that social anxiety makes it especially burdensome for you to perform an action you believe is the ethically right thing to do, you could research academic papers investigating whether there is a connection between social anxiety and ethical decision-making.
3. Are the outlined possible costs realistic/probably? Have you tried quantifying the risk of a decision, by, for example, clearly comparing the financial costs of the ethical decision to the other decision(s)?
4. Have you thought about how the context of the decision might affect the result of the decision?
5. Have you devised real-world or mental strategies to cope with, address, or overcome costs? For example, have you considered whether you have cultivated, or how to strengthen, a support network to help you overcome costs and barriers?

## Common pitfalls

1. Explaining the reason for acting ethically courageous without explaining at what cost.
2. Describing carefully the costs of acting courageously but only reiterating why the moral value outweighs the cost instead of coming up with pragmatic solutions to address or relieve the costs of the decision.
3. Making assertions without evidence about ethical action's social, psychological, or material costs.
4. Trying to tag all three #ethics HCs without sufficient space in your work to justify all three applications. While they build on each other, you are not typically required to tag every single HC related to your work. Tag foregrounded HCs or those applied especially well.
5. The “I am a good person” pitfall: this HC is not supposed to establish that you were ethically courageous. It only tries to explain how you dealt with or implemented a decision you judged ethical. Whether it was actually THE right thing to do has more to do with applications of #ethicaljudgment, a precursor to #ethicalcourage.

## Applying the HC at Minerva

1. Psychology: You are a research team member at your university. You worry that an element of the project design is ethically problematic and are wondering how to raise that concern and advocate for adjustments to the project design. For example, perhaps you notice that informed consent is only gained at the outset of a project that spans several months, and you worry that this doesn’t allow a participant to change their mind. Reflecting on the value of informed consent, you reason that participants should be engaged in the informed consent process richly and robustly over time, to fully respect their autonomy and freedom to change their minds as they learn more about the project.

Recognizing the importance of your role in an assistant-structured research team, how should you raise this with your supervisor? From your perspective, what else might you do if they don't take your concerns seriously? Do you know how to find additional resources and support in the host university to raise such concerns?
2. Computer Sciences: You are designing an algorithm that predicts whether someone is eligible for a loan or not. However, you have limited digitized information about the clients, and you are afraid that a simple learning algorithm will reinforce existing inequalities that are apparent from this data. For example, if your algorithm recognizes that neighborhood correlates with the long-term financial reliability of clients - and your algorithm uses this to deny people loans disproportionately from such neighborhoods - you might be denying people the opportunity of social mobility. If you believe social mobility is something to be promoted and your algorithm should protect that, you will have to alter your algorithm. You decide to do so and instead do further research into important factors that can determine loan eligibility without discriminating.

Now comes the application of #ethicalcourage: You identify that changing your algorithm will cost you time personally in researching alternatives and brainstorming solutions. It might also cause you stress if you feel this responsibility. Additionally, the efficiency and speed of your algorithm might suffer. This leads to possible extra costs of implementing the algorithm, but it might also mean less successful predictions and lower revenue of the investments. 

You come up with a way to carve out time to research alternatives and also reach out to a connection of yours that has experience with such algorithms to decrease the time you have to spend on reinventing the wheel. She suggests including certain promising variables from other datasets as a way to move towards more comprehensive data. She also tells you that sometimes simplicity wins over complexity. To address the lower efficiency of your algorithm, you thus come up with two solutions to compare:

- Making the algorithm more successful, but slower, by including more sophisticated and unbiased datasets. This will require more time to find and account for that data in your algorithm.

- Reducing complexity and focusing on a small amount of financial data (like credit score) instead. This might take you much less time, but you are not sure if it avoids the problem.

You model both algorithms and record the expected discrimination (for which you could use – for example – a proxy of neighborhood discrimination from a dataset of possible loan recipients), speed, and revenue of your algorithm. You find out that the second option has a slightly lower expected revenue, but also lower expected discrimination and it is much faster! This is the option you go for and you justify that decision. 

In data-driven fields, #ethicalcourage works well when you are analyzing a broad range of costs and addressing the most important ones sufficiently. In this case, two alternatives were compared and the costs were quantified. Still, the application is in the justification for the chosen strategies to address the costs in efficiency and revenue. This application also shows a creative and actionable approach to deal with the setback - using the power of networks to crowdsource an ethical solution.

## Applying the HC outside Minerva

1. In your relationships: Sometimes you will have to do the hard thing when you believe it is right. Or you will follow through on responsibilities you feel towards family/friends even when it comes at your own expense (for example, should you confront your parents about actions they take that you think are environmentally irresponsible?). Figuring out how to make those decisions resiliently takes careful thought.
2. As a consumer: Consumption has impacts. Choosing to consume more responsibly can mean you are excluded from certain opportunities and joys. How can you face those costs to be a “better consumer”?
3. As a citizen: Political participation, or non-participation, has ethically significant impacts on oneself and others. Speaking up at community events, attending political protests, voting, and volunteering might all be things you think you should do, according to your #ethicaljudgment. But they often take time, resources, and open you up to public scrutiny.
4. As an employee: your employer might be engaging in morally questionable practices, whether in terms of the people/organization they associate with (e.g. sketchy donors), in the way they treat clients/users (are they manipulating people to spend more money than they would want? Are they not transparent about what the product actually does?), the way the company treats employees or the implications of your company’s work on others (be it environmental implications or impact on working conditions of people in faraway countries).
5. In combination with other disciplines, like history: consider studying the internal and external barriers that a social group or people faced to act ethically during a conflict or time period (eg. German citizens during the Nazi regime). You may employ memoirs, bibliographies, and historical accounts to evaluate how those barriers interacted to lead to the historical outcomes at hand, as well as to determine what processes those who acted ethically and courageously underwent (possibly exploring how a German family helped Jews hide from the regime).

## Key resources

1. Sheskin, M., Perry, T. (2022, January 20). Ethical Courage - Minerva Guide. https://docs.google.com/document/d/1wA8ybnTXoAabp-AqsTR5p9cPr0EyMdyVLrhqe9nQfkE/edit
- This guide argues for the necessity of #ethicalcourage after one has applied #ethicalconsiderations and #ethicaljudgment. It also explains the main features of the phenomenon that it’s difficult to make decisions we believe are right, and how one can approach this problem.
2. Beyond Point-and-Shoot Morality: Joshua Greene - Harvard Thinks Big, 2011. https://www.youtube.com/watch?v=sChdbsbTNxI
- An important video for all 3 ethics HCs. For #ethicalcourage, pay attention to the emotional costs that are identified in different scenarios, and how an ethically equivalent (by some standard) decision can have different emotional or social costs depending on the context of that decision. Recognizing how the context of a moral dilemma influences the costs that come with making a decision is important!
3. Ahmed, Sara. “Selfcare as Warfare.” Feministkilljoys, 25 Aug. 2014, feministkilljoys.com/2014/08/25/selfcare-as-warfare/
- This resource provides an analysis of an alternative take on the role of ethical courage in the context of self-care. Audre Lorde’s A Burst of Light serves as the inspiration for Ahmed’s argument in this piece, emphasizing that doing the right thing (like fighting against racism) requires close attention to self-care as a strategy for self-preservation.
4. “Moral Courage Project.” Human Rights Center, University of Dayton, udayton.edu/artssciences/ctr/hrc/moral-courage/index.php
- The “Moral Courage Project” is a digital storytelling project that seeks to highlight ways that people (individually and collectively) engage in morally courageous actions. They also offer resources for others to undertake similar projects.
5. Lachman, Vicki D. “Strategies Necessary for Moral Courage | OJIN: The Online Journal of Issues in Nursing.” Ojin.nursingworld.org, 30 Sept. 2010, ojin.nursingworld.org/table-of-contents/volume-15-2010/number-3-september-2010/strategies-and-moral-courage/
- This resource provides an explanation of the applications of moral courage in a health professional context. Beginning with a discussion of Ancient Greek philosophical values of courage, Lachman proceeds to give concrete examples about how to identify and overcome danger and risk in acting according to ethical judgments.

## Custom HC guides

- [Ethical Courage](https://docs.google.com/document/d/1wA8ybnTXoAabp-AqsTR5p9cPr0EyMdyVLrhqe9nQfkE/edit)

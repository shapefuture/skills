# #designthinking — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/designthinking/](https://my.minerva.edu/academics/hc-resources/hc-handbook/designthinking/)
> **Habit of Mind** · Cornerstone course: Multimodal Communications · Competency: Thinking Creatively → Solving problems
> Taught in: Multimodal Communications | Semester Two · Unit: Design As Process
> Big Question: How might design help us communicate more effectively?

## Definition

**#designthinking** — Apply design research processes and iterative design thinking to conceive and refine products or solutions.

> **Pitch:** All the magic that happens between coming up with an idea and making it a reality.

Design thinking with a human-centered focus entails using the tools of design to respond to problems within particular social conditions and circumstances. This process typically consists of: research on your users and their circumstances, ideation that incorporates your design research in experimental ways, rapid prototyping and modeling to solve particular problem areas with your design, and continuous feedback from users during this process that results in further iteration. Through this process, design ideas become more and more refined and responsive to users' needs, giving one’s efforts greater reach and impact.

## Worked example

You are tasked with informing county residents regarding the newly opened multi-purpose park. You’ve learned that design thinking involves first empathizing with your users, defining the problem, ideating possible solutions, prototyping some of them, and testing the results—and then iterating until a satisfactory solution is achieved. With this process in mind, you first hold a set of interviews in your local cultural center to understand what types of advertisement most attract residents. You design a poster to announce a concert in the center based on your user research. You show it to a few friends whom you consider as representative of the audience, who tell you that the poster looks too cluttered, so you simplify it. You then notice that the colors clash, so you change one of the background colors. You print one real-sized copy to test the poster in its intended setting and find that the color change made the lettering fade into the background, so you then adjust the size of the font. The final result is much better than what you had initially.

> **Footnote:** An iterative design thinking process, including devising various versions, employing feedback from the intended audience and testing the product under various conditions, contribute to a more effective, fine-tuned final product.

## Is it this HC?

Is #designthinking the right HC? If the answer to the following questions is yes, #designthinking could be useful:

- Are you creating a work product for a human audience?

- Are you trying to bring an idea to life?

- Are you documenting your creative process?

However, depending on the focus of your work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#audience](audience.md) | apply principles of perception and cognition in oral and multimedia presentations and in design. |
| [#organization](organization.md) | builds the structure and flow of an argument which includes outlining, writing, and reverse outlining. |
| [#communicationdesign](communicationdesign.md) | tailors visual communication so it is best understood by the audience. |
| [#medium](medium.md) | analyzes and utilizes elements of a single medium at the level of form and structure. |
| [#multimedia](multimedia.md) | analyzes how multiple mediums work together or conflict with each other to create a work of multimedia, with a result that is different from the sum of the contributions of each individual medium. |
| [#optimization](optimization.md) | the process of identifying local and global optima and applying an appropriate optimization technique until the optimal solution is achieved. |
| [#breakitdown](breakitdown.md), [#rightproblem](rightproblem.md), [#gapanalysis](gapanalysis.md) | these HCs typically work to understand the underlying rules or mechanisms of a problem, and the process tends to be structured and analytical. However, #designthinking typically focuses on solving a problem, and the process tends to be less defined and require more creativity. |

## Self-study Q&A (7 questions)

**Q1. What is the discovery phase of the design process?**

The discovery phase includes all researching, brainstorming, and defining steps that you must complete before starting the actual design. This phase allows you to understand the goals of the audience and define the strategic goals of your product, which paves the way for creative and effective design.

**Q2. What are the four main steps in the discovery phase of the design process?**

- Learning about your users. Design is user centered, so user research should be at the center of the design process. Learning about the needs, characteristics, and preferences of your users allows you to identify what unmet needs should be attended to.

- Modeling your users. Once you have data about your users, you should analyze that data for common patterns. From there you can create user personas that represent differentiated groups of users who have similar needs. User models help designers understand and prioritize their target audience. 

- Analyzing your users’ tasks. Task analysis is important to understand what your users goals actually are and why those goals are important to them. Knowing what is important to your users is necessary to determine the scope of your design and create something that users will care about.

- Eliciting and defining clear product requirements. This step is important because as a designer you are responsible for setting constraints and requirements for your product. By having these factors defined, you are able to focus on what is important which stimulates efficient creative thinking.

**Q3. What is the design phase of the design process?**

This phase is based in creating models, receiving feedback, developing new ideas, and redesigning. These steps are iterative meaning they should be completed in multiple rounds. Throughout this process, you should be thinking about whether the changes made properly addressed user concerns.

**Q4. What are the three main steps in the design phase of the design process?**

- Developing conceptual models. This step includes modeling how the user would interact with your design and how this interaction can be streamlined. 

- Solving key design problems through ideation. In ideation, an open-mind is rewarded. It is always helpful to generate alternative solutions and think creatively about how to solve problems.

- Doing detailed design. In this step, the design is refined and prototyped in high detail. However, this is not the end: user feedback and trials are incredibly important in this phase. With that feedback, you should return to ideation and modeling. The design phase is a loop of brainstorming, prototyping, receiving feedback, and solving problems.

**Q5. What is the difference between the scientific method and the design method?**

The scientific method works to solve existing problems in nature which tend to be well-defined or externally structured. On the other hand, design is focused on creating things of value that did not previously exist. This means design thinking is inherently creative and constructive, while not being as analytical as scientific problem-solving. In practice, however, there is a lot of overlap. While design thinking does not have understanding the system as its primary goal, it often results in that sort of understanding, and the understanding can drive more effective designs. Additionally, a lot of the day-to-day work in many sciences (e.g., troubleshooting experimental setups) involves the sort of solution-focused, iterative tinkering that we call design thinking.

**Q6. What is the “define” step in design thinking, and how does it bridge the “empathize” phase with the subsequent stages of the design process?**

The “define” step in design thinking is where insights gathered from the “empathize” phase are distilled into a clear, actionable problem statement. This phase is a transition from broad understanding to focused clarity, enabling designers to pinpoint the specific challenge they aim to address. By synthesizing user observations and insights, we produce a concise definition of the problem that highlights the users' needs and the unique opportunities for innovation. This problem statement provides guidance for the subsequent stages of ideation, prototyping, and testing, ensuring that the design efforts are consistently aligned with the users' perspectives and the core challenge at hand.

**Q7. Why is iteration such an important part of an effective design process?**

The primary value of iteration and prototyping is that the gaps between iterations/prototypes are valuable opportunities to assess, learn, and pivot. For this reason, writeups are much more compelling when they contain narratives that describe moments when a particular iteration leads to an insight, which leads to a significant shift in the project.

## Guided reflection (proficiency checklist)

1. Have you received and used user-based feedback?
2. Have you identified improvements to your original design and acted on them?
3. Have you gathered multiple perspectives on optimizing your design?
4. Have you included documentation of your design process in your work?
5. Have you clearly explained how the design has shifted from one iteration to the next, for example by identifying how user feedback was incorporated or describing why certain changes were implemented?
6. Have you reflected on the value of your design process, indicating which phases of the process led to which key improvements and subsequent iterations?

## Common pitfalls

1. The application does not include documentation of the design process.
2. The application does not effectively respond to user-based feedback, leading to a work product that does not reach the target audience.
3. The application is a first draft or otherwise has not been optimized.
4. The application shows no attempt at gathering multiple perspectives.

## Applying the HC at Minerva

1. You can use #designthinking when creating a slideshow for any audience. Start with defining your audience and their preferences through research and brainstorming. Then you can start getting feedback from your intended audience on your first prototype. Perhaps the feedback informs you that the colors clash, the font does not fit the theme, and the visual does not add to the slide. Now you go back to the drawing board with these problems in mind, reworking your prototype, and then asking for user feedback on the refined design. This process should be iterative and focused on creating a human-based design.
2. In the Computational Sciences, you might develop some sort of program or app. If anyone other than you is ever going to use it, you need to think about the user experience, and #designthinking is the best way to approach this.

## Applying the HC outside Minerva

Architects use #designthinking principles in their professional practice. In designing new buildings, they must clearly understand the surrounding area and the people who will be using the space. Once they know the preferences and needs of the building’s audience and the space constraints, they can think of creative and aesthetic ways to meet those needs. They can program a virtual prototype of the building and ask for user feedback on the design. Once main problems are identified, they can create multiple alternative solutions, and again ask for feedback. This human-centered design ensured the architecture is connected to the user's needs, not just the architect’s preferences.

## Key resources

1. Gabriel-Petit, P. (2010, July 19). Design is a process, not a methodology. UXmatters. https://www.uxmatters.com/mt/archives/2010/07/design-is-a-process-not-a-methodology.php
- This resource is a comprehensive description of the different phases of the design process. While there are variations on how the design process steps are articulated across different design fields and firms, they are often very similar.
2. Cross, Nigel (1982). Designerly ways of knowing. Design Studies, 3(4) pp. 221–227
- This is an academic journal on design from a foundational scholar of 'design thinking.' In it, Cross argues that there are specific, distinguishing ways of thinking like and acting like a designer.
3. Norman, D. (2018, August 10). Principles of human-centered design (Don Norman). YouTube. https://www.youtube.com/watch?v=rmM0kRf8Dbk
- A short video that explains the principles of human-centered design.
4. The Hasso Plattner Institute of Design at Stanford. (2010). Bootcamp bootleg. https://static1.squarespace.com/static/57c6b79629687fde090a0fdd/t/58890239db29d6cc6c3338f7/1485374014340/METHODCARDS-v3-slim.pdf
- This resource includes an overview of many tools useful in the design process. It outlines the model of the design thinking process: empathize, define, ideate, prototype, test.


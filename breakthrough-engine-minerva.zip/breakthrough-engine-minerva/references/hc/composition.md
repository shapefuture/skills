# #composition — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/composition/](https://my.minerva.edu/academics/hc-resources/hc-handbook/composition/)
> **Habit of Mind** · Cornerstone course: Multimodal Communications · Competency: Communicating Effectively → Using language
> Taught in: Multimodal Communications | Semester One · Unit: Writing as a Craft
> Big Question: What might a perfect society look like?

## Definition

**#composition** — Communicate with a clear and precise style.

> **Pitch:** Do not utilize the most complex and convoluted mechanisms of saying things; instead, communicate parsimoniously!

Effective communication requires a clear and precise style that reflects an authentic and genuine voice of the communicator while being appropriate for the intended audience. As a general helpful rule, communicators should use the fewest words necessary (they should respect the principle of “parsimony”) and should select words carefully to be as clear as possible and to facilitate transitions from one idea to the next. Strong composition requires avoiding passive voice, stilted diction, elaborate structure, and imprecision; write and speak simply, directly, and sincerely. Effectively applying these principles ensures we structure sentences to appropriately paraphrase, quote, or summarize information into our communications. Mastering these principles also involves knowing when to deliberately “break” a rule in order to convey intentional meanings to audiences.

## Worked example

You are visiting your aunt at her new house. She leaves a 5-minute long, convoluted voicemail about how to find her property, in which she tells you to drive on one road for “a while,” then turn “toward the property that just got sold by Kristin, who just had a child and is moving to New York” and take a right at the Millers’ farm. You have no way to know which property was recently sold or where the Millers live, and have no interest in knowing why Kristin sold her property. She then retracts some directions and suggests a detour around “the road with the Starbucks” to avoid construction. You realize en route that your cell phone’s battery is dead and you can no longer communicate with her, not knowing which of the five Starbucks in your proximity she meant. You try to follow her instructions, but quickly get lost. You wish her communications had been clear, precise, parsimonious and relevant.

> **Footnote:** The aunt's messages exemplify a poor use of composition, as the messages are not clear and concise, using elaborate and indirect ways that could not be followed even by an attentive listener. It added irrelevant information and used diction that was not best suited for its purpose (“property” instead of “house” or “building”).

## Is it this HC?

Is #composition the right HC? If the answer to the following questions is yes, #composition could be useful:

- Are you attempting to communicate clearly and precisely?

- Are you choosing words purposely for your communication, keeping parsimony in mind?

- Are you examining how to arrange your sentences and paragraphs best?

- Are you analyzing how the composition of a work created a certain meaning?

Depending on the work product, there might be other HCs to consider. ….

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#connotation](connotation.md) | identifies and uses connotations, tone, and style, an application of this HC may be complemented by applying #composition. |
| [#critique](critique.md) | actively and critically engages with texts and other forms of communication; an application of this HC may be complemented by applying #composition. |
| [#organization](organization.md) | effectively organizes communications; this HC tends to apply to the holistic organization throughout the work, while #composition is applied to choices made at the level of the sentence and paragraph construction. |

## Self-study Q&A (5 questions)

**Q1. What is parsimony, and why is it important?**

Parasimony is a principle that guides us to utilize more straightforward explanations over more complex ones as long as it portrays the same meaning. This concept is essential in literature because complex and indirect composition tends to increase as academia rises; however, this should not necessarily be the case. There is a stereotype that to write about complicated things, your writing must be equally complex and confusing, however, writing in this manner does not make you seem well-informed, it just alienates the audience. Sometimes when you write about more complex topics, you will need more complex sentences for a proper explanation. However, you should not use more complex sentences when more straightforward sentences are possible. Utilizing parsimony allows you to say what you need to most effectively for your audience.

**Q2. How can you write concisely?**

(note that this list is non-exhaustive)

- Eliminate redundant pairs

- Delete unnecessary qualifiers

- Identify and reduce prepositional phrases

- Locate and delete unnecessary modifiers

- Replace a phrase with a word

- Identify negatives and change them to affirmatives

- Vary sentence structure

**Q3. What is the passive voice?**

When writing a passive sentence, the object comes first, and the subject appears at the end of the sentence. The sentence may be passive if a form of “be” and a past tense verb are paired. The passive often leads to writing more words than necessary and to unclear sentence subjects. For example, “The Flying Cloud ship was built in 1851,” employs passive voice. When you write it in an active voice you also prompt yourself to add information about who built the ship. “Donald McKay built the Flying Cloud ship in 1851” employs an active voice.

**Q4. When is the passive voice appropriate?**

Composing sentences in the passive voice can disengage the audience, however, doing so can also be helpful! The passive voice is not a grammatical error, and sometimes sentences sound smoother when the passive voice is utilized. As with other stylistic matters in writing, it’s a good idea to attend to discipline-specific norms. For example, scientific papers are often written in a passive voice. The passive voice may be a good fit if there is no need to include the sentence's subject. By understanding and recognizing the passive voice in your writing, you can use your best judgment to decide whether or not it is valid. A good rule of thumb is to write the sentence in both the active and passive voice and compare which fits best in the literary context.

**Q5. When should you paraphrase, use direct quotations, or summarize?**

You will want to summarize or paraphrase when the meaning of the source is more important than the source's wording. Paraphrasing is restating the source in detail while summarizing is condensing the source. You can also keep your style and composition aligned with the rest of the work by paraphrasing or summarizing. For those reasons, paraphrasing and summarizing are often favored over quotations. In both cases, you should still cite your resources to ensure that your writing is #evidencebased. However, a direct quotation is the best option when the source's wording is important or there is no more parsimonious or straightforward way to word the information. You should weave the quotation into your sentence smoothly, maintaining the work’s style and composition as best as possible. When quotations are just dropped into work, they tend to disrupt the flow of the piece and feel unnatural to readers. In general, it’s a good idea to avoid starting or ending a paragraph with a direct quotation, as they require your own commentary and explanation to work as support for your point of view.

## Guided reflection (proficiency checklist)

1. Have you communicated with a clear and precise style that utilizes nuances of language to transmit messages in a particularly parsimonious or subtle manner?
2. Have you effectively explained or justified an evaluation of the clarity and precision of a communication?
3. Have you avoided passive voice, stilted diction, elaborate structure, and imprecision?
4. If you broke any common compositional 'rules' did you do so with intentionality and explain and justify your choices in your footnote?
5. Have you written and spoken simply, directly, and sincerely with your intended audience in mind?
6. Have you considered when to use paraphrase, quotation, or summary to incorporate necessary information smoothly into your communication?
7. Have you considered alternate sentence or paragraph structures and justified why your compositional choice is preferred?
8. Have you endeavored to tailor your stylistic decisions to discipline-specific norms of writing?
9. If you used AI tools or peer feedback to help edit your writing, did you carefully review and edit this to be specific and reflect your own authentic ideas, voice, and style?

## Common pitfalls

1. The application does not attempt to communicate with clarity and precision when prompted or does so ineffectively.
2. The application does not fully explain or justify its evaluation of a work’s composition.
3. The application uses excessive passive voice, stilted diction, elaborate structure, and imprecision without justification.
4. The application does not consider the intended audience, leading to unclear and indirect communication.
5. The application does not consider any other compositional choices.
6. The application relies on vague and generic language that does not reflect genuine and authentic ideas.

## Applying the HC at Minerva

1. In business, you may investigate what a short tagline says about a brand. For example, you may compare the slogans: "We build a better world. Together.” with "Building a better world together." These slogans seem to have the same meaning but are composed differently. The first slogan includes a period between “world” and “together,” which seems to emphasize the importance of “together.” In contrast, the second slogan has no full stops, which gives the impression that all the words are equally important. Both of these slogans seem to lack detail because the intended audience would need significant background information to understand how the company plans to build a better world with them. By analyzing the #composition of the slogan options, one can suggest improvements in the clarity and precision of the phrase.
2. In science, you may use #composition to ensure you communicate your findings in the most parsimonious way. The details of the scientific study may be complex; however, when writing your report, you try to explain the mechanisms and results in the simplest way possible, allowing your audience to know more than just what your results were but to grasp why and how you found those results. To do this, you follow the principle of parsimony, avoid run-on sentences, and reduce your use of the passive voice. Your writing becomes more efficient now that you have prioritized your audience’s understanding and compositional choices. You tag #composition to justify why you made those choices and how they elevated your work.

## Applying the HC outside Minerva

You can use #composition in your daily communications too! Many people spend time each day sending texts. However, not many people think about how to compose such messages so they are understandable. Taking the extra second to ask yourself if the message you are about to send could be misinterpreted may save you from conflicts. Of course, your texts do not need to be the most parsimonious and beautifully crafted writing. However, avoiding ambiguity and confusion would still be helpful. People tend to avoid punctuation or only use it for emphasis, making texting a hard place to navigate compositionally. However, sometimes punctuation changes the meaning of a sentence, e.g. “did you eat, grandma?” vs. “did you eat grandma?” One sentence asks a simple question, and one implies cannibalism! Apply #composition to your casual writing whenever possible.

## Key resources

1. University of North Carolina at Chapel Hill. (n.d.). Writing Concisely. The Writing Center. https://writingcenter.unc.edu/tips-and-tools/conciseness-handout/
- This is a good resource for specific tips in #composition--read it and get a handle on which ones seem especially pertinent to your own writing.
2. Orwell, G. (1946, April). Politics and the English Language. The Orwell Foundation. https://www.orwellfoundation.com/the-orwell-foundation/orwell/essays-and-other-works/politics-and-the-english-language/
- Written in 1946, Orwell’s famous essay laments the decline of the English language due to the laziness and bad habits of its speakers. He outlines the bad habits he wishes to see eliminated and explains how lazy writing both leads to and is a result of lazy thinking. Orwell believes that these bad habits not only limit language, they also contribute to political and cultural decline. Although most of Orwell’s sample words and phrases are no longer current, one can apply his ideas to today’s writing in order to improve communication.
3. Publishing, U. of M. L. (2015). Chapter 7: Refining Your Writing: How Do I Improve My Writing Technique? Mlpp.pressbooks.pub. https://mlpp.pressbooks.pub/writingsuccess/part/chapter-7-refining-your-writing-how-do-i-improve-my-writing-technique/
- This publicly accessible chapter focuses on compositional techniques beyond grammatical correctness, concision, and precision. With sections on parallelism, coordination and subordination, and sentence variety you can work to refine and polish your writing techniques. The chapter also includes practice exercises.
4. Decide when to Quote, Paraphrase and Summarize - University of Houston-Victoria. (2023). Uhv.edu. https://www.uhv.edu/curriculum-student-achievement/student-success/student-resources/a-d/decide-when-to-quote-paraphrase-and-summarize/
- This short resource explains what paraphrasing, summarizing, and quoting are and when each method is most appropriate to integrate sources into your work.


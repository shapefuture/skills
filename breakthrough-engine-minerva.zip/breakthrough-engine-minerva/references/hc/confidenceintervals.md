# #confidenceintervals — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/confidenceintervals/](https://my.minerva.edu/academics/hc-resources/hc-handbook/confidenceintervals/)
> **Foundational Concept** · Cornerstone course: Formal Analyses · Competency: Thinking Critically → Analyzing data
> Taught in: Formal Analyses | Semester One · Unit: Probability and Statistics
> Big Question: What does it mean to be random? & How can data help us discover what is true?

## Definition

**#confidenceintervals** — Apply and interpret confidence intervals.

> **Pitch:** Why would you give just a single number as your estimate? Show me the confidence interval!

A confidence interval specifies upper and lower values that are likely to bracket an unknown population value—typically the true mean of the population. The difference between the upper and lower bounds specifies the level of certainty of the parameter estimate, with larger ranges indicating less certainty about where the mean actually lies. The size of the interval varies depending on how precise one desires the estimate to be.

## Worked example

Mark likes to gamble on local elections. In the latest poll, the current mayor’s approval rating was slightly higher than that of his closest competitor. In addition to these point estimates, Mark knows to pay close attention to the “margin of error” — usually expressed as a confidence interval for each estimate. The intervals presented for the elections have a 95% confidence level. This probability refers to the reliability of constructing the interval in the frequentist perspective: if the sampling procedure were repeated many times, with different point estimates obtained for each sample and different confidence intervals formed, then we expect 95% of these intervals to contain the true approval rating for the population. Interestingly, the candidates’ confidence intervals for approval rating overlapped, meaning that the standard error was large enough to suggest that there is no statistically significant difference between the ratings. He understood that while based on the poll’s sample statistics, the current mayor’s rating was higher, the overlapping intervals mean that the true approval ratings for each candidate in the population could actually be the other way around. Therefore, he should wait for a clearer gap before betting on one versus the other to increase the odds of winning the bet.

> **Footnote:** A population parameter, approval rating, which is the proportion of the population that approves of a candidate, is estimated using confidence intervals: the approval rate based on a sample plus/minus the margin of error. The intervals for two candidates are interpreted correctly and are used to inform the betting strategy, noting the implications for statistical significance.

## Is it this HC?

Is #confidenceintervals the right HC? If the answer to the following questions is yes, #confidenceintervals could be useful: 
- Are you estimating a population parameter (e.g., mean or proportion) and striving to indicate the precision of your estimate using margins of error or upper and lower bounds? 

- Are you interpreting a confidence interval in the context of a study to draw useful inferences? 
However, depending on the focus of the work, there might be other applicable HCs to consider. Other HCs may use #confidenceintervals as part of their focus. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#estimation](estimation.md) | Estimates a quantity of interest using calculations from inexact or incomplete information. Confidence intervals are a specific estimation strategy in the context of making inferences about unknown population parameters. |
| [#significance](significance.md) | Conducts or interprets a hypothesis test to evaluate if a sample contains strong evidence for a genuine difference or pattern in the population. Confidence intervals may be constructed to complement hypothesis tests and add further support for statistical inferences. |
| [#distributions](distributions.md) | Evaluates properties of distributions, which could apply when constructing a confidence interval and examining the distribution of sample data to observe whether conditions for inference (e.g., normality, skew) are met. Depending on the application, one must work with an appropriate sampling distribution (normal distributions and t-distributions are common) to properly calculate the margin of error for the confidence interval (using z-scores or t-scores). |

## Self-study Q&A (16 questions)

**Q1. What is a point estimate of a population parameter? What are some examples of parameters we may obtain point estimates for?**

A point estimate of a population parameter is a single value that is used to estimate an unknown parameter of a population based on sample data. It provides an approximation or best guess for the value of the parameter. We may obtain point estimates for parameters such as means, proportions, and medians.

**Q2. What is the margin of error? How is it calculated?**

The margin of error is a measure of the variability regarding the amount of random sampling error. It is calculated by multiplying the critical value for a certain confidence level, which could be the t or z value, and the standard error. The standard error (SE) represents the amount of variability associated with the point estimate. It takes into account the variability within the sample and provides a measure of how much the sample results might differ from the true population value. Note that the formula for calculating the SE depends on the parameter. For example, the standard error of the sample mean is equal to σ / √n, where σ is the population standard deviation and n is the sample size. It’s common to estimate this using the standard deviation of the sample, s.

**Q3. In general, there are three main ingredients to construct a confidence interval. What are they?**

Formula: (Sample Statistic) ± (z or t-score) * (SE).
The three ingredients are the following: 
- the point estimate (e.g., the sample mean, proportion, or other sample statistic), 

- critical t or z value for the given confidence level (e.g., z=1.96 for 95% confidence), and 

- the standard error (e.g., the SE of the mean is σ / √n)
Alternatively, the formula of a confidence interval can be noted as the (sample statistics) ± (margin of error), where margin of error can be further broken down into the critical t or z-score multiplied by the standard error.

**Q4. Elaborate on what 95% confidence really means. Provide the correct interpretation and one possible misinterpretation. Given the situation of estimating the population mean weight of newborns with a 95% confidence interval of [5.5, 9.0] lbs, correctly interpret this result.**

It means that if we were to repeat the sampling many times and construct many confidence intervals, 95% of them would contain the true population mean. 

The following are the potential misinterpretations that you may make, and why: 
- A 95% confidence interval means that for a given interval calculated from sample data, there is a 95% probability that the population parameter lies within the interval. 
- This statement seems to indicate that we can assign a probability to the population parameter. However, adopting the frequentist notion of probability, the population parameter is fixed. Once an experiment is performed (a sample is taken), it is a binary outcome whether the population mean is in the interval or not. As we have actually collected our sample, we can no longer make probabilistic statements about the population parameter. Instead, the 95% probability refers to the reliability of the method of constructing confidence intervals: it works 95% of the time. 

- A 95% confidence interval means that 95% of the sample lies within the interval. 
- The interval is about estimates of population parameters, not about the spread of the sample. It's true that 95% of the sampLING distribution lies within the interval, but not 95% of the sample distribution. 

- A confidence interval of 95% calculated from an experiment means that there is a 95% chance that, if the experiment were repeated, the new point estimate would also fall within this interval. 
- The level of confidence describes the probability of capturing the population parameter, not the next point estimate from a sample. 

For the given situation, we can be 95% confident that the true population mean weight of newborns falls within the range of 5.5 to 9.0 pounds. This means that if we were to imagine repeating the process of sampling and constructing confidence intervals, 95% of those intervals would contain the true population mean weight.

**Q5. Draw a general sampling distribution and shade in the region corresponding to the 95% confidence level.**

*No example answer was provided in the source.*

**Q6. What are the percentiles corresponding to the upper and lower bounds of a 95% confidence interval? Hint: use the drawing above to help you.**

See drawing for the self-study question above. The percentiles are 2.5% and 97.5%. We need to remember the definition of percentile (the probability to be less than or equal to a certain value) and then see that there's (100-95)/2 = 5/2 = 2.5% in each tail.

**Q7. What is the critical z-score value for a 95% confidence level? How do you find the critical z value for other confidence levels?**

1.96. For general confidence levels, we can find the corresponding z-score using statistical software, tables, or online calculators. It is not possible to determine analytically. 

In Python, use the command from the scipy stats package: stats.norm.ppf(percentile). It's important to note that the ppf function converts PERCENTILES to z-values, not confidence levels. The upper bound of a 95% confidence interval corresponds to a 97.5% percentile. In general, the percentile for the upper bound of a given confidence level is conf_level + (1-conf_level)/2.

**Q8. How would you find the critical t value for a given confidence level?**

The critical t value cannot be found analytically. You can use statistical software, tables, or online calculators. In Python, you can use the stats.t.ppf() function from the scipy.stats module in Python. The t.ppf() function calculates the quantile of the t-distribution given a probability and the degrees of freedom. For a given confidence level, conf_level, use: stats.t.ppf((1 + conf_level) / 2, degrees_of_freedom).

**Q9. When would we use t-scores instead of z-scores in the calculation of confidence intervals?**

Typically, z-scores would be the appropriate choice when constructing confidence intervals for proportions, while t-scores would be a better choice for constructing for means, especially if the population standard deviation is unknown.

**Q10. What are the conditions that need to hold to compute a confidence interval for a mean?**

The following conditions help ensure the sampling distribution of the mean is nearly normal (by virtue of the CLT) and the estimate of the standard error is sufficiently accurate.
- The data should be obtained through random sampling. 

- The sample observations are independent. Two processes are independent if knowing the outcome of one provides no information about the outcome of the other. 
- If the observations are from a simple random sample and consist of fewer than 10% of the population, then they can be considered independent. 

- The sample size is sufficiently large. 

- Assumption of normality – the population distribution is not strongly skewed. 
- In cases of an existence of an outlier, the sample size should be larger.

**Q11. For two different samples with different standard deviation but the same point estimate, how will their confidence intervals differ?**

The width of a confidence interval is affected by the standard deviation of the sample. A smaller standard deviation indicates less variability in the data, which results in a narrower confidence interval. Conversely, a larger standard deviation indicates more variability, leading to a wider confidence interval.

**Q12. If the sample size increased, would you expect the confidence interval to widen or narrow?**

It would probably get narrower. The margin of error would decrease because the standard error is inversely proportional to the square root of the sample size.

**Q13. How can the width of a confidence interval indicate the strength of a conclusion?**

The width of a confidence interval can provide an indication of the precision or uncertainty associated with an estimate, and therefore, it can influence the strength of a conclusion drawn from the data. A narrower confidence interval generally suggests a more precise estimate. This means there is stronger evidence to support a conclusion, while a wider confidence interval indicates more variability and weaker evidence.

**Q14. How can a confidence interval be used to suggest statistical significance?**

In the context of suggesting statistical significance, the confidence interval can be used to support a hypothesis test. If the confidence interval does not include the null value (e.g., zero for a mean difference), it suggests that the null hypothesis can be rejected. This provides evidence supporting a genuine difference or relationship in the population. The full hypothesis test and corresponding p-value (or other measure of statistical significance) should be completed alongside the confidence interval.

**Q15. Which interpretation of probability is being used to construct #confidenceintervals? Explain why.**

The frequentist perspective. This interpretation relies on the law of large numbers and hypothetical thought experiments. When a frequentist says that the probability of a coin landing heads is 50%, they mean that if one were to toss the coin many times, the proportion of tosses that land on heads would converge to 50%. Similarly for confidence intervals, when we say that there’s a 95% probability of capturing the population parameter, it means that if we were to repeat the sampling process many times, taking many different samples from the population, each with its own confidence interval, 95% of the intervals would contain the true population parameter. Reviewing the frequentist perspective of probability in the Minerva guide (see Key Resource).

**Q16. Confidence intervals have a non-intuitive interpretation and are often misinterpreted, which may make them seem like they're not useful. What ARE they useful for? Why do we construct these?**

When estimating parameters from an unknown population, confidence intervals are more informative than simply providing a point estimate alone. Confidence intervals provide information about the precision of an estimated parameter. A narrow interval suggests a more precise estimate, while a wider interval indicates greater uncertainty. This information is crucial for understanding the reliability of the estimated parameter.

## Guided reflection (proficiency checklist)

1. Have you correctly constructed your confidence intervals, clearly indicating the process and explaining what each term is?
2. Have you specified which distribution you are using to calculate the confidence intervals and explained why?
3. Have you evaluated whether the conditions for valid confidence intervals are satisfied?
4. Have you interpreted your confidence intervals correctly, being careful to avoid possible misinterpretations listed in the Common Pitfalls?
5. Have you interpreted the interval in a way that demonstrates why it’s meaningful or insightful for the purpose of the work, e.g., using it to address a research question?
6. Have you checked whether the null value lies inside the interval and explained what this suggests about statistical significance in the given context?
7. Have you considered complementing your confidence interval with other inferential statistics analyses, such as hypothesis tests to indicate statistical and practical significance?
8. Have you correctly explained the meaning of the confidence level (e.g., 95%) using an appropriate interpretation of probability?

## Common pitfalls

1. The calculation of the confidence interval is incorrect, possibly because: 
- an incorrect formula for the standard error is used 

- an inappropriate distribution was used (e.g., normal vs t) 

- The critical t or z value was computed incorrectly, possibly resulting from misunderstanding percentiles vs confidence levels, neglecting that confidence intervals have two tails, and/or using the t or z-score computed from sample data for a hypothesis test.
2. The application does not sufficiently evaluate the conditions that need to hold to validate the confidence interval.
3. The application interprets confidence intervals incorrectly. Common misinterpretation includes: 
- For a given 95% confidence interval, there’s a 95% probability that this interval contains the population parameter. 

- 95% of the samples lie within the confidence interval. 

- 95% of the population distribution is contained in the confidence interval. 

- If the experiment were repeated, the new point estimate would also fall within this interval.
4. The application fails to identify meaningful insights from the confidence interval that are relevant for addressing the research question under study, possibly pertaining to statistical inferences.
5. The confidence interval is stated with numerical values only, neglecting to identify the units corresponding to the upper and lower bounds.

## Applying the HC at Minerva

Across several fields, including social sciences, natural sciences, or business, #confidenceintervals would be generally helpful when making statistical inferences from data. Whenever you want to estimate an unknown population parameter and you only have sample data, this HC is going to allow you to be extra informative with the inferences you can make. Providing a single #descriptivestat alone cannot paint the full picture! With this HC in your toolbox, not only can you supply an individual point estimate for the unknown population parameter, you can create a confidence interval to demonstrate the precision of the estimate and provide a certain level of confidence for your estimate. The confidence interval can also be paired with hypothesis tests to assess statistical significance. 
- For example, in business applications, you might be interested in consumer preferences for a certain product, so you collect user ratings for a sample of customers and take the mean. This point estimate for the mean will probably not be exactly equal to the true mean user rating in the population. To capture this, you can calculate the margin of error and construct a 95% confidence interval to demonstrate the precision of the estimate. A wide interval would indicate low precision whereas a narrow interval would indicate a more precise estimate. 

- Going further, you may wish to compare user ratings for two different products by constructing two 95% confidence intervals. Then, you may observe that the intervals for the products do not overlap, which suggests that there may be a statistically significant difference between the ratings for these products. You can support this result by executing a hypothesis test and quantifying the statistical and practical significance of the difference in mean ratings.

## Applying the HC outside Minerva

1. Confidence intervals are often used to report polling projections for elections. Rather than report just the proportion of voters that support the candidate based on a single sample, we can provide a confidence interval to demonstrate how precise the estimated sample proportion is. See the general example above to bring this to life.
2. Software developers use confidence intervals to assess the performance or efficiency of code. For example, consider algorithms that have variability in their runtime. Companies usually strive to make their code run faster while maintaining the desired outputs. Creating a confidence interval for the runtime can help coders determine whether changes they’re making to the code are significantly improving or degrading the runtime. A code change that results in a slower runtime, but still falls within the 95% confidence interval, might be ok to push forward, but a code change that results in a worse runtime that falls beyond the upper bound would warrant further review. In this way, the confidence interval becomes a tool to help developers evaluate the impact of their code updates.
3. Policymakers can use confidence intervals to support implementing certain policies. Here’s one example in the context of sustainability and world hunger: 'Bycatch' is the term for the unwanted fish or other marine animals that are caught by commercial fishing operations as they pursue other species. It is a significant concern for both the sustainability of fishing grounds and the economic interests of the fishing industry. When bycatch quotas are violated, fishing companies receive enormous penalties and the entire fish harvest may be wasted and thrown away (to die). The individual fishermen are not always the ones doing the reporting, but rather, government agencies often have an agent aboard large fishing vessels whose job it is to report on this. Nonetheless, it may only be possible to collect a small sample of bycatch reports from which to base inferences. If we know the sample mean bycatch weight, we can use it to construct a 95% confidence interval to estimate the true mean bycatch weight of all boats. The interval could then be used to justify enforcing stricter bycatch sanctions on boats. Suppose, for example, the resulting 95% confidence interval was [8693 kg, 11307 kg]. The fact that the lower bound of our interval is over 8600 kg reinforces the severity of the problem. One might consider heavily penalizing boats that surpass the upper bound of 11300 kg.

## Key resources

1. Terrana, A. (2022, Oct 2022). What is Statistical Inference? Minerva University. https://docs.google.com/document/d/1-WZpMTLNOerZpfi4o9kNgmANrf7IpbsdxwfacUx84pE/edit# 
- This resource provides a clear picture of where confidence intervals are used within statistical inference.
2. Khan Academy. (n.d). Confidence intervals: Confidence intervals for means. AP Statistics. https://www.khanacademy.org/math/ap-statistics/xfb5d8e68:inference-quantitative-means 
- This resource provides a comprehensive explanation for concepts within confidence intervals, as well as sets of practice questions.
3. Diez, D., Barr, C., & Cetinkaya-Rundel, M. (2015). Sections 4.1, 4.2, 4.3 and 6.1. OpenIntro Statistics (3rd ed.). https://drive.google.com/file/d/0B-DHaDEbiOGkc1RycUtIcUtIelE/view 
- This resource provides a comprehensive explanation for concepts within confidence intervals, as well as sets of practice questions.
4. Magnusson, K. (n.d.). Interpreting confidence intervals: An interactive visualization. RPsychologist. http://rpsychologist.com/d3/CI/ 
- This visualization is valuable for reinforcing the correct interpretation of confidence intervals aligning with the frequentist interpretation of probability.
5. Wilkins, J. (Oct, 2020). Interpreting probabilities. Minerva University. https://docs.google.com/document/d/1ikOunBGOK_D8rGUOcC2b1q4AJ8r6X58cK8UwZDdB_I4/edit?usp=sharing 
- This resource explores frequentist and Bayesian perspectives on probability. Reviewing the frequentist perspective can be helpful to comprehend how to correctly interpret “95% confidence” and avoid common misinterpretations.

## Custom HC guides

- [What is Statistical Inference?](https://docs.google.com/document/d/1-WZpMTLNOerZpfi4o9kNgmANrf7IpbsdxwfacUx84pE/edit)
- [Inference for the Population Slope in Linear Regression](https://docs.google.com/document/d/1dXvCZ0X5Z4ScIZ9Z_GzbfkJxDcfvOMc_lq1hvvv9PaQ/edit)

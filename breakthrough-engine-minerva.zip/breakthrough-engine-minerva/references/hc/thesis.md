# #thesis — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/thesis/](https://my.minerva.edu/academics/hc-resources/hc-handbook/thesis/)
> **Habit of Mind** · Cornerstone course: Multimodal Communications · Competency: Communicating Effectively → Using language
> Taught in: Multimodal Communication | Semester One · Unit: Writing as a Craft
> Big Question: What might a perfect society look like?

## Definition

**#thesis** — Formulate a well-defined thesis.

> **Pitch:** A paper without a thesis is like a joke without a punchline.

When developing an argument, written and spoken communications should present a clear, well-defined central claim. The thesis statement should be concise, arguable, substantial, precise, set up the forthcoming evidence, and relevant (CASPER). The thesis statement should summarize the work in one to two sentences. As the guiding message of the work, the thesis should serve as the organizing principle of communication.

## Worked example

You are struck by the number of homeless people you see on the streets of San Francisco and decide to investigate further and write an article in an undergraduate journal. While you may feel outraged by the poor social and economic support you find in the city for this population, you realize that you need to do more than express your outrage in your article. You must present a clear and specific claim about conditions contributing to this problem. As such, you end the introduction of your essay with a clear, arguable, and precise thesis based on your findings: Investing in homeless shelters is merely a temporary relief to homelessness in San Francisco because doing so fails to address underlying causes in terms of housing unaffordability, low wages, and rising inflation.

> **Footnote:** The thesis lays out precisely what the paper will argue, provides a clear indication of the significant reasons you'll offer in support of that argument, and explains the relevance of your argument. The statement is arguable, precise, and clear.

## Is it this HC?

Is #thesis the right HC? If the answer to the following questions is yes, #thesis could be useful:

- Are you writing a research paper or persuasive appeal in which you advance a claim backed by reasons and evidence?

- Do you include a roadmap for the argument?

- Do you provide a clearly defined, concise, detailed, and arguable main idea?

- Do you connect sub-arguments and conclusions to your main idea?

However, depending on the focus of the work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#purpose](purpose.md) | states or analyzes a company, product, or institution, taking note of its guiding principles, values, and mission. |
| [#organization](organization.md) | considers using other organizational elements in addition to, or in place of a well-structured thesis. |
| [#hypothesisdevelopment](hypothesisdevelopment.md) | the process of researching multiple explanations for a phenomenon and making a plausible and testable explanatory claim. |
| [#evidencebased](evidencebased.md) | identifies and supports claims with vetted, well-cited, relevant evidence and clear explanations. |
| [#breakitdown](breakitdown.md) | identifies a big problem and breaks it down into actionable subproblems. |

## Self-study Q&A (4 questions)

**Q1. What main qualities should all thesis statements have?**

All thesis statements should be concise, arguable, substantial, precise, sets up evidence, and relevant (CASPER).

**Q2. What does it mean for a thesis to be a) substantial, b) precise, c) relevant, d) arguable, e) concise, and f) sets up evidence?**

Concise: The thesis should avoid excessive verbiage that obscures the main point. Although the length of a thesis statement might depend on the field of study or the report's length, aiming for a one-sentence summary is a helpful heuristic to ensure a reader knows your main idea and how you will develop your argument. 

Arguable:A thesis should not just be a summary, a fact, or an observation. It should be an argument, which could be an analysis or an interpretation someone could dispute and defend in mutually illuminating ways.

Substantial: For a thesis to be substantial, it should be thoughtful, connected to substance, and backed by reasons and/or evidence. The thesis should answer the "how" and "why" of the argument to ensure the argument is not too open-ended. A substantial thesis informs the reader where the paper is going, what it'll focus on, and what the importance of the claim is.

Precise: A thesis should be clear and specific, giving a roadmap of the argument and ruling out other similar, alternate ways of making the argument. It should pass the "So what?" test; otherwise, you must clarify your argument further. You should be more specific if your thesis includes a vague term, such as good or successful.

Sets up Evidence: The thesis should effectively guide your paper, which means it should set up forthcoming evidence. Evidence should be included in the order it will appear in the work, so the thesis enhances organization.
Relevant: The thesis is significant in the context and for the intended audience. When a prompt is given, it responds to the prompt.

**Q3. How is precision different from concision?**

In a concise thesis, all words are necessary and contribute to the statement's meaning, meaning almost nothing can be edited out. In a precise thesis, the vocabulary is chosen with close attention to connotation to portray the main idea with utmost accuracy and clarity.

**Q4. How is #thesis related to #organization?**

A strong thesis simultaneously states an argument and concisely maps out how that argument will be supported. Therefore, the thesis statement is an integral organizing feature of any argument. For example, if you wrote a paper supporting a government bill and wrote three arguments in favor and one counter-argument against the bill. The sequence in which you place the arguments in your thesis should follow the order in which they appear in your paper. Doing this ensures your paper has a clear structure guiding your audience.

## Guided reflection (proficiency checklist)

1. Have you ensured your thesis 
- is substantial, precise, relevant, arguable, concise, and sets up the forthcoming evidence?

- is appropriate in terms of scope?

- is supported by the evidence of your work?

- references what type of evidence you will use to give the reader an idea of how you will support your claim?

- is a one to two sentence statement of your main claim?
2. When applicable, have you provided a detailed justification for a thesis critique or suggested a non-trivial improvement?
3. Have you revised your thesis when you've finished a complete first draft to tailor it to the evidence and reasoning you provided?

## Common pitfalls

1. The application's thesis is too vague or opened-ended.
2. The application's thesis is too long or mentions too many topics.
3. The application's thesis does not take a stance.
4. The application's thesis states a claim with no reasoning. For example, the thesis says A is B but does not mention A is B because of X, Y, and Z.
5. The application's thesis provides a claim and reasoning but neglects to mention the importance of the claim. For example, the thesis states A is B because of X, Y, and Z but does not include that A is B because of X, Y, and Z, which is important for D.
6. The application has a strong central idea, but the thesis is not stated clearly or easily found within the paper.
7. The application lives within a paper that has yet to identify its main points, which makes it hard to write a precise thesis.
8. The thesis is not revised throughout the process of writing and researching, so it does not match the scope or accomplishments of the work.

## Applying the HC at Minerva

1. When writing reports essays, you will have to write a thesis to clarify your thoughts and help the reader understand your point. Writing a solid thesis takes time and iteration, so refer to the Writing Resource on #Thesis for concrete examples of ways to improve your thesis statements for classwork.
2. Capstone projects involve writing a substantially and regularly revisited and revised thesis throughout the proposal, research, and writing process. During long-term projects, it's especially important to see the thesis-writing as a part of your broader research process, functioning both as a guide for work you plan to complete and as a way to communicate findings and conclusions based on work completed.

## Applying the HC outside Minerva

1. A thesis can be spoken, too. If you are negotiating with someone and want to ensure they understand your main point, you might start by saying, "I think A because of X, Y, and Z."
2. You might practice the same skills you used when writing a thesis - summarizing, prioritizing information, and being clear with language - when coming up with an elevator pitch for a research proposal, business idea, or TV series.

## Key resources

1. Minerva Academic Team. (2023). Thesis. https://my.minerva.edu/academics/curriculum/foundation-year/cornerstone-summer-preparation/resources/writing-resources/
- Minerva’s Cornestone Summer Prep Writing Resources include a guide on #thesis. As stated in the summer preparation material, the guide focuses on formulating a substantial, arguable, precise, and relevant thesis statement that can be used to project the paper's central argument.
2. Minerva Academic Team. (2023). Writing an Argumentative Essay. https://my.minerva.edu/academics/curriculum/foundation-year/cornerstone-summer-preparation/resources/writing-resources/
- You can find a guide on organizing an argumentative essay by clicking the “Writing An Argumentative Essay” tab in Minerva’s Cornestone Summer Prep Writing Resources. Refer to the section titled “Thesis: The Driving Argument” for more.
3. Foss, N. J., & Saebi, T. (2016). Fifteen years of research on business model innovation. Journal of Management, 43(1), 200-227. Available from https://drive.google.com/file/d/1OFIiKbq9l3xN_kwc4HZeuNOh90ILnXCi/view
- This resource contains model theses and their feedback. The theses were written for literature reviews made by first-year students.


# #selfawareness — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/selfawareness/](https://my.minerva.edu/academics/hc-resources/hc-handbook/selfawareness/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Working with others
> Taught in: Complex Systems | Semester Two · Unit: Prudence and Effective Interactions
> Big Question: How can we be the authors of our own life's story?

## Definition

**#selfawareness** — Identify and monitor your strengths and weaknesses; mitigate behaviors and habits that impair effective performance.

> **Pitch:** “Knowing yourself is the beginning of all wisdom” – Aristotle

Humans generally form overly optimistic assessments of their own characteristics and performance, and ignore evidence to the contrary. Part of “knowing yourself” is to assess your abilities and characteristics accurately and to identify bad habits and bad behavior that prevent you from achieving goals. To do this, you must first determine your blind spots by learning to “know what you don’t know” and form habits to avoid ignoring evidence regarding your behaviors and their effects. This requires objectivity, intellectual courage, and lack of arrogance so that you can form an accurate appraisal of your strengths and weaknesses as well as develop strategies for self-improvement. Being self-aware has the added benefit of making you more sensitive to the degree to which others have accurate self-assessments, so that you can adjust your interactions with them accordingly.

## Worked example

For your first group assignment, you and your teammates have decided to evenly split the work, ensuring that each of you are assigned to the parts that touch more on your strengths. Since you are aware of your strength in writing and your weakness in coding due to your lack of experience, you decided to take the parts that require more writing and spearhead the proofreading and formatting. Once you received your evaluation from your group members, you were surprised to learn that even though you did what you were tasked with, your groupmates did not feel like the work split was fair. You realize that coding was difficult for them as well, and that in avoiding the challenge of practicing what you are less skilled at, you missed an opportunity for learning and growth. You realize that by focusing on your strengths, you were too focused on the fear of failure and not sufficiently attentive to the needs of the group and your teammates. For your next group assignment, you make an effort to contribute to the coding even though you are not assigned to do much of it. Upon receiving your evaluation from your group members, you are happy to notice the difference in such feedback compared to the feedback you received from your first assignment.

> **Footnote:** You use your knowledge of yourself in combination with feedback from others to re-evaluate your own motivation and learn something about yourself. The knowledge is then applied as you work to avoid your blind spots in the next assignment.

## Is it this HC?

Is #selfawareness the right HC? If the answer to the following questions is yes, #selfawareness could be useful:

- Do you analyze how different factors cause and shape behavior, influence one’s perception of the self, and promote self-knowledge?

- Do you describe strategies to gain self-knowledge or metacognition (i.e. social comparison, introspection, etc)?

- Do you generate an unbiased self-assessment?

- Do you identify gaps in metacognition and use those to inform what kind of knowledge to seek out?

However, depending on the focus of the work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#psychologicalexplanation](psychologicalexplanation.md) | details how psychological factors influence behavior, considering relevant theories of psychology or neuroscience. Analyzing how such factors influence self awareness might be an application of this HC. |
| [#emotionaliq](emotionaliq.md) | analyzes instances where individuals identified and managed their emotions. Awareness of one’s own emotions is part of #emotionaliq, while #selfawareness is about awareness of one’s knowledge and thinking. |
| [#biasidentification](biasidentification.md) | outlines a specific, scientific mechanism for a cognitive bias. The identified bias can occur at a systems level too. Biases can be based on our underlying judgments or misinformation, which is where it might overlap. |
| [#biasmitigation](biasmitigation.md) | seeks to mitigate a bias irrespective of whether the bias can help the individual gain self-knowledge or improve one’s position in a complex system. explains or proposed a mechanism or cognitive framework to avoid or mitigates a certain bias. Some strategies for mitigating biases can be awareness strategies. |

## Self-study Q&A (6 questions)

**Q1. What are different sources of self-knowledge?**

One can acquire self-knowledge from various sources. For example, you can gain insights from the outer world:

- through social comparison when a person compares oneself to others or the physical world.

- reflected appraisal (i.e., the opinions of others) External feedback is often crucial in finding your weaknesses which is why it is helpful to interact with forward people to receive critical feedback. It is also important to look for patterns the past feedback has revealed. 

The inner world is another source that helps you become more self-aware through: 

- introspection (i.e., noting how one feels about oneself),

- self perception (i.e., explanations of the causes of one’s own behavior).

**Q2. Why might people say that Socrates was wise for saying: “I know that I know nothing”? And what strategy of self-awareness might be prompted by this insight?**

Admitting that you should be skeptical of much of what you “know” makes it easier to spot errors and gaps in your understanding. It is a good starting point of metacognition to treat your understanding as provisional, subject to change based on new information.

A Socratic strategy coming from this would be radical wonder - or putting everything up to scrutiny. We learn new things when we wonder about the world, and this might work best when we admit that we are ignorant about most of it!

**Q3. Imagine a friend of yours displays a passive-aggressive behavior towards you (for some reason), and you decide not to bring it up to not make a big deal out of it. How might #selfawareness be useful in analyzing and adjusting your reaction to the situation?**

If you think deeply about it you might realize that you do not want to look a particular way, or be in a situation where you accuse your friend of something they have not actually done, because you do not understand why they would act like that in the first place. That might prompt you to think about your behavior towards them and whether there might have been something you did that made them feel bad. Regardless of whether you reach a conclusion or not, thinking about the situation helped you rationalize it and realize that a discussion, in the worst case, will make your friend feel awkward, because they did not expect such a direct approach. However, in this case you will demonstrate to them that you hope to be made aware and are ready to adapt your behavior.

Self-awareness is not #emotionaliq. Therefore, the main emphasis here is not the specific emotions you are feeling, but how to challenge underlying assumptions and knowledge.

**Q4. What is the illusion of explanatory depth?**

The "illusion of explanatory depth" is a cognitive bias that refers to the tendency of people to believe that they understand a concept or object more deeply than they actually do. There is a discrepancy between our perceived understanding and our actual knowledge. This bias can be seen in various contexts, from technical systems to political policies. Research has shown that people tend to overestimate their knowledge and are surprised by their inability to explain things they thought they understood well. Recognizing this bias means you will work harder to understand systems or problems. You should avoid making superficial and ineffective judgments based on an illusion of a deep understanding. For example, if you ask “do you know how a toilet works,” people will say yes, but if you ask them to explain it in detail, they will not get far.

**Q5. How might biases impede your #selfawareness?**

To positively bias self-assessments, individuals can engage in biased social comparison, only exposing oneself to favorable feedback, or self-handicapping (by not giving oneself a chance to succeed in order to have excuses for suboptimal performance), or avoiding difficult tasks. Specific biases include the “positivity bias,” an associated halo effect for one’s peers (ie you rate yourself above average; you also tend to rate your friends as above average as well), the illusion of explanatory depth, and the Dunning-Kruger effect. What are some other biases that are relevant to #selfawareness?

**Q6. What is the habit cycle?**

The habit cycle and its associated framework for change explains how habits are formed and how we can use self-awareness to identify and modify our own habits for better outcomes.

## Guided reflection (proficiency checklist)

1. Have you identified what you are and what you aren’t capable/knowledgeable of?
2. Have you considered the factors that might improve or worsen your ability to be self aware?
3. Have you clearly identified a specific strategy and/or bias?
4. Have you considered how you or someone else being self-aware influences the outcomes for the entire system/group?
5. Have you clearly identified the outcome and explained why this is significant in the specific context?
6. If you chose a particular strategy to promote self improvement, did you explain why that strategy will be effective by providing an example/mechanism?
7. When you were trying to assess your behavior or capabilities in a specific situation, did you consider how that assessment might be biased?

## Common pitfalls

1. Believing you are self aware without a process is often a sign of not being fully aware at all; metacognition takes conscious effort and critical deliberation.
2. The application describes a state of #selfawareness, but does not address the steps taken and why they were the appropriate choice.
3. The application does not address a personal realization and the events that led to this realization, but appears to follow a generic narrative about #selfawareness, such as addressing basic strengths and weaknesses, but not describing specific traits of the individual.
4. The application showcases a strategy but does not address why a strategy for promoting #selfawareness is effective in the situation.
5. The application does not expand the scope of applying #selfawareness beyond stating the strengths and weaknesses of oneself, for example through explaining the implications of those strengths and weaknesses.
6. The application does not identify a clear strategy and/or bias.

## Applying the HC at Minerva

1. Presenting an argument: Whenever you present an argument and evidence, one must have metacognition about the topic. For example, understanding that your understanding of Confucianism is limited in your intro philosophy course will help you prepare a philosophical argument with appropriate confidence. Additionally, working to find out about your own strengths and weaknesses in terms of presentation/writing will help you choose an appropriate medium, language, tone, etc.
2. Teamwork: Not only is it important to understand your own strengths, weaknesses, working style, etc. to be an effective team member, it is also helpful to understand how others are aware of themselves and provide them with the right sources of feedback to cultivate a higher level of self-awareness. For example, if someone is unsure and perfectionist about their contribution, you can encourage them by cheering their successes of the past and in doing so help them achieve a more accurate and helpful self-image!
3. History: How has the self-awareness of historical figures either helped or hindered their success? How has that ended up influencing historical events?
4. Artificial Intelligence: How can you make an artificial intelligence model “self-aware”? Consider what functions do humans use to analyze (metacognition) and correct their own behavior and how that could potentially be used in a neural network where the algorithm is supposed to adjust itself to inputs.

## Applying the HC outside Minerva

You are working your way in a political structure. You stand firmly behind your values, which include treating everyone, your voters and colleagues, equally; in addition, they include honesty and hard work, rather than attempting to talk your way to the top. You clearly realize that a lot of your competitors are not going to be as noble; nevertheless, you still believe in the value of your qualities in the long term. You decide that since you chose a different strategy of partaking in politics than a lot of other people, you will have to find an original way to win voters’ trust, while not letting your opponents use your honest approach to their advantage. Consider which characteristics of yours might most easily be misinterpreted by your competitors to the public; then consider how you can improve those things about yourself, or if that is not possible, outsource them to a trusted individual who will support you in your campaign.

## Key resources

1. Fact Sheet: Metacognitive Processes (2019, February). https://lincs.ed.gov/state-resources/federal-initiatives/teal/guide/metacognitive
- This reading defines metacognitive processes, explains their importance, and provides instructions for teaching those skills.
2. Fernbach, P. (2013, November 14). Phil Fernbach: The illusion of understanding. https://www.youtube.com/watch?v=2SlbsnaSNNM
- This video provides some common examples of how people might overestimate their understanding of a topic and discusses strategies to mitigate this effect.
3. Galef, J. (2016, February). Why you think you're right -- even if you're wrong. TEDx. https://www.ted.com/talks/julia_galef_why_you_think_you_re_right_even_if_you_re_wrong
- This video discusses a historical example of confirmation bias and explains how people's thinking patterns create and reinforce that bias.
4. Looser, C. E. (2019). Forum Magic. Minerva University. https://docs.google.com/document/d/182DpMpDXjmp9ohd8fZ9GeB3DG2Hmanj5xQe_IF5GEMs/edit
- This source uses cognitive psychology to explain how attention and perception shape your behavior and interactions on Forum. Practicing #selfawareness and using intentional metacognition will help you evaluate your attention span and take measures to elevate your engagement during class.


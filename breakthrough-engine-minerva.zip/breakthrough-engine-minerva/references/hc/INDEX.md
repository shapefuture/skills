# Minerva Cornerstones HC — Master Index

**76 HCs** (39 Habits of Mind + 37 Foundational Concepts) · **555 self-study Q&As with answers** · **407 related-HC mappings** · **295 key resources** · **45 custom guides** ([catalog](../guides.md)).

Each HC page contains: definition + pitch, full description, worked example with footnote, "Is it this HC?" diagnostics, a related-HC selection table, self-study Q&A **with answers**, proficiency checklist, common pitfalls, applications at/beyond Minerva, key resources, and custom-guide links.

| Cornerstone course | HCs |
|---|---|
| Formal Analyses | 17 |
| Empirical Analyses | 21 |
| Complex Systems | 21 |
| Multimodal Communications | 17 |

Grouped by the official Cornerstone Course field. Cross-listed HCs: #utility (also Complex Systems), #dataviz (also Formal Analyses), #evidencebased (taught in Empirical Analysis), #responsibility (Foundation Week).

## Formal Analyses (17)

### Algorithms and Simulation

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#optimization](optimization.md) | FC | Evaluate and apply optimization techniques appropriately. | 7 |

### Decision Theory

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#decisiontrees](decisiontrees.md) | HoM | Apply and interpret decision trees to explore the consequences of alternative choices. | 7 |
| [#gametheory](gametheory.md) | FC | Apply and evaluate game-­theoretic models. | 12 |
| [#utility](utility.md) | FC | Use utility to represent preferences and analyze purposeful decision-making. | 23 |

### Logical Thinking

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#algorithms](algorithms.md) | FC | Apply algorithmic thinking strategies to solve problems and effectively implement working code. | 12 |
| [#deduction](deduction.md) | FC | Analyze and apply deductive reasoning. | 15 |
| [#estimation](estimation.md) | HoM | Use estimation and approximation techniques appropriately. | 7 |
| [#fallacies](fallacies.md) | FC | Identify and correct logical fallacies. | 11 |
| [#induction](induction.md) | FC | A method of reasoning where probable conclusions are drawn based on specific evidence and observations. | 9 |

### Probability and Statistics

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#confidenceintervals](confidenceintervals.md) | FC | Apply and interpret confidence intervals. | 16 |
| [#correlation](correlation.md) | FC | Apply and interpret measures of correlation; distinguish correlation and causation. | 12 |
| [#descriptivestats](descriptivestats.md) | HoM | Calculate and interpret descriptive statistics appropriately. | 8 |
| [#distributions](distributions.md) | FC | Identify different types of distributions and make inferences based on samples from distributions appropriately. | 19 |
| [#probability](probability.md) | FC | Apply and interpret fundamental concepts of probability, including conditional and Bayesian probabilities. | 15 |
| [#regression](regression.md) | FC | Apply and interpret regression. | 14 |
| [#significance](significance.md) | FC | Apply, interpret, and distinguish practical and statistical significance. | 15 |

### Problem Solving

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#variables](variables.md) | HoM | Identify and classify the relevant variables of a system, problem, or model. | 13 |

## Empirical Analyses (21)

### Biases

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#biasmitigation](biasmitigation.md) | HoM | Identify methods to mitigate the effect of biases and determine when it is appropriate to do so. | 7 |

### Complex People

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#biasidentification](biasidentification.md) | FC | Identify and explain how cognitive biases result from psychological mechanisms or use of heuristics. | 7 |

### Probability and Statistics | Scientific Method

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#dataviz](dataviz.md) | FC | Interpret, analyze, and create data visualizations. | 15 |

### Problem Solving

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#analogies](analogies.md) | FC | Use analogies in problem solving appropriately. | 6 |
| [#breakitdown](breakitdown.md) | HoM | Organize problems into tractable components and design solutions. | 5 |
| [#constraints](constraints.md) | FC | Identify and apply constraint satisfaction as a way to solve problems. | 3 |
| [#gapanalysis](gapanalysis.md) | FC | Identify and evaluate whether there are suitable existing solutions to a problem or whether a creative new solution is required. | 5 |
| [#heuristics](heuristics.md) | HoM | Identify when to use heuristics and when to avoid them. | 9 |
| [#rightproblem](rightproblem.md) | HoM | Characterize a complex problem in detail to really understand it. | 4 |
| [#scienceoflearning](scienceoflearning.md) | HoM | Evaluate and use effective strategies to learn or teach specific types of material. | 5 |

### Research Design

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#casestudy](casestudy.md) | FC | Design and interpret case studies | 6 |
| [#comparisongroups](comparisongroups.md) | FC | Identify and evaluate appropriate comparison groups for empirical study designs. | 3 |
| [#interviewsurvey](interviewsurvey.md) | FC | Design and interpret primary research performed as interviews or surveys (individually or in groups). | 14 |
| [#sampling](sampling.md) | FC | Design effective sampling methods and evaluate the interpretation of results accordingly. | 9 |

### Scientific Method

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#hypothesisdevelopment](hypothesisdevelopment.md) | FC | Evaluate the link between hypothesis-driven research and the theories or observations that motivate it. | 5 |
| [#interventionalstudy](interventionalstudy.md) | FC | Design and interpret experimental studies. | 3 |
| [#modeling](modeling.md) | FC | Recognize how models can be used to describe a system, explain a set of data, and generate predictions. | 10 |
| [#observationalstudy](observationalstudy.md) | FC | Design and interpret observational studies. | 5 |
| [#plausibility](plausibility.md) | HoM | Evaluate whether hypotheses are based on plausible premises or assumptions. | 3 |
| [#studyreplication](studyreplication.md) | FC | Evaluate and incorporate replicability in empirical study designs. | 4 |
| [#testability](testability.md) | HoM | Evaluate whether hypotheses lead to testable predictions. | 5 |

## Complex Systems (21)

### Characteristics of Complex Systems

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#complexcausality](complexcausality.md) | FC | Identify ways that multiple causes interact to produce complex effects. | 4 |
| [#emergentproperties](emergentproperties.md) | FC | Understanding nonlinear effects of complex systems. | 3 |
| [#levelsofanalysis](levelsofanalysis.md) | HoM | Analyze characteristics or behavior of a complex system, integrating explanations found at different levels of analysis and their interactions. | 11 |
| [#networks](networks.md) | FC | Analyzing the structure of connections to understand system-level outcomes. | 4 |
| [#systemdynamics](systemdynamics.md) | FC | Use the tools of phase spaces--including attractors, critical points, and basins--to describe and predict the ways a complex system changes over time. | 3 |
| [#systemmapping](systemmapping.md) | FC | Guided by an explanatory challenge, develop simplified representations of complex systems by conceptualizing their components and relating them to one another. | 5 |

### Complex Agents

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#differences](differences.md) | HoM | Identify and be responsive to people’s different skills, abilities, traits, attitudes, beliefs, and social position. | 6 |
| [#psychologicalexplanation](psychologicalexplanation.md) | FC | Analyze the interacting factors across levels of analysis that explain and shape the behavior of complex agents. | 4 |

### Complex People

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#emotionaliq](emotionaliq.md) | HoM | Use emotional intelligence to interact effectively. | 5 |

### Ethics and Justice

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#purpose](purpose.md) | HoM | Articulate a mission statement that coherently connects fundamental values with long and short term goals, as well as the operating procedures that advance these goals in light of the values. | 6 |

### Individuals in Society

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#conformity](conformity.md) | FC | Identify and analyze social norms, their features, origins and development; evaluate the appropriateness of conformity and contrarianism and apply strategies of social change when applicable. | 4 |
| [#powerdynamics](powerdynamics.md) | HoM | Recognize different sources of power and use them to analyze situations and influence others. | 5 |

### Prudence and Effective Interaction

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#leadprinciples](leadprinciples.md) | HoM | Apply principles of effective leadership. | 5 |
| [#strategize](strategize.md) | HoM | Diagnose the problem at hand and develop a plan to achieve your goals by finding leverage and exploiting relative strengths. | 4 |

### Prudence and Effective Interactions

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#ethicalconsiderations](ethicalconsiderations.md) | HoM | Identify ethical considerations relevant to a situation or decision and explain them by appealing to values and/or ethical theory. | 6 |
| [#ethicalcourage](ethicalcourage.md) | HoM | Identify and analyze psychological, social, and material costs of acting in accordance with one’s considered ethical judgment; devise strategies to act ethically in the face of such costs. | 8 |
| [#ethicaljudgment](ethicaljudgment.md) | HoM | Articulate and justify ethical positions, addressing opposing positions and counterarguments. | 5 |
| [#selfawareness](selfawareness.md) | HoM | Identify and monitor your strengths and weaknesses; mitigate behaviors and habits that impair effective performance. | 6 |

### Prudence and effective interaction

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#shapingbehavior](shapingbehavior.md) | HoM | Analyze how incentives, disincentives, and choice architecture influence the behavior of agents in a complex system and utilize them to interact effectively in social systems. | 4 |

### Prudence and effective interactions

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#negotiate](negotiate.md) | HoM | Use a structured approach to negotiation to reach desired objectives. | 5 |

### Purpose and Responsibility

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#responsibility](responsibility.md) | HoM | Follow through on commitments; be proactive and adaptable. | 6 |

## Multimodal Communications (17)

### Bringing it all together

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#expression](expression.md) | HoM | Interpret, evaluate, and utilize nonverbal communication. | 4 |

### Close Reading

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#connotation](connotation.md) | HoM | Understand and use connotations, tone, and style. | 9 |
| [#critique](critique.md) | HoM | Actively and critically engage with texts and other forms of communication. | 5 |
| [#interpretivelens](interpretivelens.md) | HoM | Be mindful of how prior experiences, expectations, and judgments affect inferences drawn from different forms of communication and react accordingly. | 6 |
| [#professionalism](professionalism.md) | HoM | Follow established guidelines to present yourself and your work products professionally. | 6 |
| [#sourcequality](sourcequality.md) | HoM | Distinguish between categories and types of information to determine source quality. | 7 |

### Design As Process

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#designthinking](designthinking.md) | HoM | Apply design research processes and iterative design thinking to conceive and refine products or solutions. | 7 |

### Interpretation

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#communicationdesign](communicationdesign.md) | HoM | Apply principles of perception and cognition in oral and multimedia presentations and in design. | 6 |
| [#context](context.md) | FC | Situate a work in its relevant context (e.g., historical, disciplinary, cultural). | 5 |
| [#medium](medium.md) | FC | Describe, analyze, and utilize distinctive characteristics of communicative and expressive mediums at the level of form and structure. | 5 |

### Multimedia

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#multimedia](multimedia.md) | FC | Analyze or craft communications with layered modalities. | 6 |

### Persuasion

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#persuasion](persuasion.md) | HoM | Craft and interpret communications that create a favorable disposition or move audiences to do something. | 7 |

### Problem Solving

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#evidencebased](evidencebased.md) | HoM | Identify and appropriately structure the information needed to support an argument effectively. | 5 |

### Writing as a Craft

| HC | Type | Definition | Q&A |
|---|---|---|---|
| [#audience](audience.md) | HoM | Tailor oral and written work by considering the situation and perspective of the people receiving it. | 6 |
| [#composition](composition.md) | HoM | Communicate with a clear and precise style. | 5 |
| [#organization](organization.md) | HoM | Effectively organize communications. | 5 |
| [#thesis](thesis.md) | HoM | Formulate a well-defined thesis. | 4 |

## By core competency

### Thinking Critically (29)

[#biasidentification](biasidentification.md) · [#biasmitigation](biasmitigation.md) · [#breakitdown](breakitdown.md) · [#confidenceintervals](confidenceintervals.md) · [#context](context.md) · [#correlation](correlation.md) · [#critique](critique.md) · [#decisiontrees](decisiontrees.md) · [#deduction](deduction.md) · [#descriptivestats](descriptivestats.md) · [#distributions](distributions.md) · [#estimation](estimation.md) · [#evidencebased](evidencebased.md) · [#fallacies](fallacies.md) · [#gametheory](gametheory.md) · [#gapanalysis](gapanalysis.md) · [#induction](induction.md) · [#interpretivelens](interpretivelens.md) · [#plausibility](plausibility.md) · [#probability](probability.md) · [#psychologicalexplanation](psychologicalexplanation.md) · [#purpose](purpose.md) · [#regression](regression.md) · [#rightproblem](rightproblem.md) · [#significance](significance.md) · [#sourcequality](sourcequality.md) · [#testability](testability.md) · [#utility](utility.md) · [#variables](variables.md)

### Thinking Creatively (17)

[#algorithms](algorithms.md) · [#analogies](analogies.md) · [#casestudy](casestudy.md) · [#comparisongroups](comparisongroups.md) · [#constraints](constraints.md) · [#dataviz](dataviz.md) · [#designthinking](designthinking.md) · [#heuristics](heuristics.md) · [#hypothesisdevelopment](hypothesisdevelopment.md) · [#interventionalstudy](interventionalstudy.md) · [#interviewsurvey](interviewsurvey.md) · [#modeling](modeling.md) · [#observationalstudy](observationalstudy.md) · [#optimization](optimization.md) · [#sampling](sampling.md) · [#scienceoflearning](scienceoflearning.md) · [#studyreplication](studyreplication.md)

### Communicating Effectively (10)

[#audience](audience.md) · [#communicationdesign](communicationdesign.md) · [#composition](composition.md) · [#connotation](connotation.md) · [#expression](expression.md) · [#medium](medium.md) · [#multimedia](multimedia.md) · [#organization](organization.md) · [#professionalism](professionalism.md) · [#thesis](thesis.md)

### Interacting Effectively (20)

[#complexcausality](complexcausality.md) · [#conformity](conformity.md) · [#differences](differences.md) · [#emergentproperties](emergentproperties.md) · [#emotionaliq](emotionaliq.md) · [#ethicalconsiderations](ethicalconsiderations.md) · [#ethicalcourage](ethicalcourage.md) · [#ethicaljudgment](ethicaljudgment.md) · [#leadprinciples](leadprinciples.md) · [#levelsofanalysis](levelsofanalysis.md) · [#negotiate](negotiate.md) · [#networks](networks.md) · [#persuasion](persuasion.md) · [#powerdynamics](powerdynamics.md) · [#responsibility](responsibility.md) · [#selfawareness](selfawareness.md) · [#shapingbehavior](shapingbehavior.md) · [#strategize](strategize.md) · [#systemdynamics](systemdynamics.md) · [#systemmapping](systemmapping.md)

## Alphabetical quick list

[#algorithms](algorithms.md) · [#analogies](analogies.md) · [#audience](audience.md) · [#biasidentification](biasidentification.md) · [#biasmitigation](biasmitigation.md) · [#breakitdown](breakitdown.md) · [#casestudy](casestudy.md) · [#communicationdesign](communicationdesign.md) · [#comparisongroups](comparisongroups.md) · [#complexcausality](complexcausality.md) · [#composition](composition.md) · [#confidenceintervals](confidenceintervals.md) · [#conformity](conformity.md) · [#connotation](connotation.md) · [#constraints](constraints.md) · [#context](context.md) · [#correlation](correlation.md) · [#critique](critique.md) · [#dataviz](dataviz.md) · [#decisiontrees](decisiontrees.md) · [#deduction](deduction.md) · [#descriptivestats](descriptivestats.md) · [#designthinking](designthinking.md) · [#differences](differences.md) · [#distributions](distributions.md) · [#emergentproperties](emergentproperties.md) · [#emotionaliq](emotionaliq.md) · [#estimation](estimation.md) · [#ethicalconsiderations](ethicalconsiderations.md) · [#ethicalcourage](ethicalcourage.md) · [#ethicaljudgment](ethicaljudgment.md) · [#evidencebased](evidencebased.md) · [#expression](expression.md) · [#fallacies](fallacies.md) · [#gametheory](gametheory.md) · [#gapanalysis](gapanalysis.md) · [#heuristics](heuristics.md) · [#hypothesisdevelopment](hypothesisdevelopment.md) · [#induction](induction.md) · [#interpretivelens](interpretivelens.md) · [#interventionalstudy](interventionalstudy.md) · [#interviewsurvey](interviewsurvey.md) · [#leadprinciples](leadprinciples.md) · [#levelsofanalysis](levelsofanalysis.md) · [#medium](medium.md) · [#modeling](modeling.md) · [#multimedia](multimedia.md) · [#negotiate](negotiate.md) · [#networks](networks.md) · [#observationalstudy](observationalstudy.md) · [#optimization](optimization.md) · [#organization](organization.md) · [#persuasion](persuasion.md) · [#plausibility](plausibility.md) · [#powerdynamics](powerdynamics.md) · [#probability](probability.md) · [#professionalism](professionalism.md) · [#psychologicalexplanation](psychologicalexplanation.md) · [#purpose](purpose.md) · [#regression](regression.md) · [#responsibility](responsibility.md) · [#rightproblem](rightproblem.md) · [#sampling](sampling.md) · [#scienceoflearning](scienceoflearning.md) · [#selfawareness](selfawareness.md) · [#shapingbehavior](shapingbehavior.md) · [#significance](significance.md) · [#sourcequality](sourcequality.md) · [#strategize](strategize.md) · [#studyreplication](studyreplication.md) · [#systemdynamics](systemdynamics.md) · [#systemmapping](systemmapping.md) · [#testability](testability.md) · [#thesis](thesis.md) · [#utility](utility.md) · [#variables](variables.md)

> Source: Minerva University HC Handbook — https://my.minerva.edu/academics/hc-resources/hc-handbook/ (per-page URLs preserved in each file). Machine-readable exports: `references/data/*.csv`.
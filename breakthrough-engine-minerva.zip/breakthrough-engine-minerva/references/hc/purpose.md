# #purpose — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/purpose/](https://my.minerva.edu/academics/hc-resources/hc-handbook/purpose/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Thinking Critically → Analyzing decisions
> Taught in: Complex Systems | Semester Two · Unit: Ethics and Justice
> Big Question: How should power be used and distributed?

## Definition

**#purpose** — Articulate a mission statement that coherently connects fundamental values with long and short term goals, as well as the operating procedures that advance these goals in light of the values.

> **Pitch:** A journey of a thousand miles begins with a single step. Make sure that the first step is in the right direction.

Projects and initiatives frequently fail when they lack a clear and principled purpose. Identifying the purpose of an individual or group (including, but not limited to, formal organizations) is critical for evaluating their actions—or one’s own. To construct an individual’s or group’s purpose, it is useful to articulate the underlying values that guide and constrain our goals. Moreover, successful outcomes also depend on articulating operating procedures, or guiding principles, consistent with the values and goals.

## Worked example

The purpose of the non-profit organization that you want to volunteer in is “to create a radically inclusive, just and loving community, mobilized to alleviate suffering and break the cycles of poverty and marginalization.” As you interrogate the organization and talk to its founders, you learn that one of their core values is the notion that all people deserve to be respected and empowered equally (‘radically inclusive’), as well as a commitment to kind and pleasant interactions (‘loving community’). Another core value is an egalitarian conception of social justice, according to which the way to respect and empower everyone equally is to ensure there are social conditions in place that prevent people from succumbing to poverty (‘breaking the cycle of poverty and marginalization’). These values underlie their monthly goal of serving at least 60,000 meals to those who may otherwise go hungry. Likewise, their operating procedures reflect these values and goals as they give out free meals daily to anyone who comes to their walk-in center.

> **Footnote:** The organization’s purpose was identified and further elaborated through the discussion of their values, goals, and operating procedures. To evaluate the organization’s operation the tight connection between the mission’s components is emphasized.

## Is it this HC?

Is #purpose the right HC? If the answer to the following questions is yes, #purpose could be useful:

- Are you describing the values, goals, and operating procedures of a company, organization, or (individual) effort?

- Are you explaining how these different parts of a strategy are connected? 

- How do your operating procedures advance your goals and values?

- How do your values inspire your goals?

- What are potential mismatches?

However, depending on the focus of the work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#responsibility](responsibility.md) | Focuses on the ways in which we follow through on commitments. Useful to apply once you have thought through what commitments align with values and goals. |
| [#strategize](strategize.md) | Develops a plan to achieve goals by finding leverage. Helpful when moving from goals to operating procedures but sometimes applied with goals that aren’t necessarily related to a mission. |
| [#leadprinciples](leadprinciples.md) | Applies principles of effective leadership to reach a group’s goals. A leader will benefit from an understanding and embodiment of #purpose. It relates to leading by example, but also, a leader might want to align people’s goals. But there are more qualities a leader might have that do not immediately relate to #purpose, such as charisma. |
| [#gapanalysis](gapanalysis.md) | Analyzes whether existing solutions can sufficiently help you solve a problem. It might overlap with #purpose when you analyze how to move from goals to operating procedures and how other organizations do this. |

## Self-study Q&A (6 questions)

**Q1. What are SMART goals? Explain the need to which each responds.**

Specific - What? Who? How? The more precise your goal is, the more likely you will work towards it and feel able to know what to do.

Measurable - A quantifiable target will help you track your progress and celebrate milestones.

Attainable - If your goal is achievable, you will be more motivated to work towards it. Working on attainability also helps you identify gaps between what you hope to and can achieve.

Relevant - Ensuring your goal relates to your overarching mission or value is essential to #purpose. Thinking about how your goal addresses an actual problem is essential!

Time-bound - Having a team be on the same page for a deadline will help create accountability.

**Q2. Name one overarching advantage and pitfall to implementation as a strategy for setting goals.**

Possible advantages:

- It creates clear parameters for success that everyone can agree on. This makes you able to hold others accountable.

- It motivates people to track their goals and report progress since reporting on SMART goals is easier.

- It works like a spell-check for a goal -> to test if it is adequately phrased. It might be useful to apply once you already have an idea for a goal but to phrase it in a way that makes it precise and creates accountability.

Possible disadvantages:

- Setting goals too low. Aiming for attainability might reduce creativity and encourage people to set easy goals instead of working hard to try and reach challenging goals.

- Some goals might not fit the SMART format or will change fundamentally when doing so. Imagine you want to make an organization more diverse because doing so improves social equity and the output of your organization. Quantifying how many people of specific backgrounds you want within your organization can make you aim low. More importantly, you might look past crucial aspects of diversity, such as creating an inclusive/accessible environment and addressing discrimination.

- Merely focusing on short-term goals and losing track of values. Long-term goals and values can sometimes be too expansive to guide concrete next steps, but such goals are still valuable to expand our imagination about what’s possible. Wanting to make extraterrestrial life possible on Mars might not be very SMART, but it inspires people at SpaceX and can lead to many overspill innovations.

**Q3. What principle of #scienceoflearning also applies (to an extent) to a goal that generates the most effort?**

Desirable Difficulty. Research shows that effort is highest when goals are challenging to achieve, as long as they don’t exceed one’s current capabilities by too much. Note: in #scienceoflearning, this effort is what ensures deep processing. In #purpose, it is what supports high performance and the ability to reach goals.

**Q4. What are the four mechanisms that help people achieve goals? Tip: read the first resource in the Key Resources section.**

Directive - they direct attention to goal-related activity and away from irrelevant activity

Energizing - they inspire effort if motivational.

Persistence - they keep people on track for a more extended period.

Activate relevant knowledge/skills - goals contain language that directs people to the tools they already have to tackle those goals.

**Q5. PRACTICE - Below is a table with the Values, Goals, and Guiding Principles of Monsanto, the world’s most giant agrotechnological multinational. Their mission is “Health for all, Hunger for none.” Fill in the gaps to align values goals and principles: View the table here**

View the file for the table.

**Q6. Critique an operating procedure of Monsanto in day-day business in the light of the above values and goals. Offer an alternative. Choose from:
- Buying small plant labs 

- Patenting seeds discovered at educational institutions 

- Focusing on monoculture (cash crops) 

- Investing in new seed development facilities 

- Developing pesticides

- Keeping much research confidential or internal rather than publishing**

Buying up smaller small plant labs -> Counters innovativeness. Many small labs might lead to more innovation in the entire field. Instead, Monsanto focuses on monopolizing knowledge but reduces the amount of invention in the process. 

Instead, they should encourage smaller plant labs and provide services to them like consulting or incubators.
Patenting seeds discovered at educational institutions, farms, or smaller businesses -> Counters transparency, integrity, and innovation. Transparency because they do not share information on new crops or how to cultivate them so clients have to buy with Monsanto. Integrity because they profit off of the intellectual work of others. Innovation, because it limits the opportunities of innovators to further develop their discoveries. 

Instead, they might want to create strong incentives for more innovation at universities and safeguard open research so that researchers can build on each other’s research. This includes financial incentives for sharing research, such as prizes for worthwhile research.

Focusing on global monoculture crops (cash crops) -> limits sustainability and flexibility. Monoculture crops are more vulnerable to plagues, requiring more industrial approaches that are bad for biodiversity. 

Instead, if Monsanto was flexible, they would acknowledge that crops are environment-sensitive and encourage local crop development.

Investing in new seed development facilities -> This is actually good!

Developing pesticides -> Counters sustainability. Pesticides prove harmful to people and nature. Instead, they might want to develop biological resistance or protection (using nature to protect crops - like implementing wasps to avoid plagues).

Keeping much research confidential or internal rather than publishing -> Counters Transparency, Leadership, and Innovation. 

Instead, they might want to focus on collaboration between innovators, farmers, and policymakers to spur as much progress as possible.

## Guided reflection (proficiency checklist)

1. Have you identified the company, organization, or project's central values, goals, guiding principles, or operating procedures?
2. Have you considered the motivational aspect of your #purpose and made adjustments to your plans to improve your ability to stick with your goals?
3. Have you critiqued the current connections between values, goals, and operations or suggested improvements to align them better?
4. Have you thought about the effects of your defined goals and values on the work that the organization/group/individual does and then used that reflection to reshape your goals?
5. Have you defined what a successful outcome would look like and how the goals help you achieve this?

## Common pitfalls

1. Focusing on SMART goals and forgetting that goals should also be inspiring or engaging to create drive.
2. Trying to analyze or improve a complete set of values and goals instead of addressing one specific way to create better alignment and performance of those.
3. Focusing on establishing a clear set of values without connecting that to specific acts.
4. Seeing the values/goals as separate from the people having to exercise them. Individuals making up an organization: Their values and goals should be compatible with the organization’s.
5. Not thinking through the practical implementation. For example, without feedback systems, people might not stay on track with their goals.

## Applying the HC at Minerva

1. Businesses: Whenever you analyze or plan a business, you will find #purpose central in what ties together many parts of that business. For example, you could use this HC to critique a company’s operating procedures in light of their goals. You could compare their long to short-term goals or analyze what their values, as expressed through brand identity, actually mean for the company's workings. #purpose will help you in making business a field with, well, purpose.
2. Institutions: In Politics, Economics, and Sustainability, you will often investigate or work with institutions or nongovernmental organizations that have articulated mission statements. For example, the United Nations articulates that they work towards five main goals: 1) Maintain International Peace and Security. 2) Protect Human Rights. 3) Deliver Humanitarian Aid. 4) Support Sustainable Development and Climate Action. 5) Uphold International Law. An exciting application of #purpose is to investigate how these follow from the essential values that U.N. countries agree on or explain how some of these goals conflict in some contexts.
3. Movements, Collectives, Communities: In  History, Art, and Politics, you investigate groups of people that work together with a shared sense of values and goals, often without being clearly defined. You might think of #purpose as being emergent here and likely quite dynamic. Defining a movement's purpose, goals, and actions (and how they change over time) is challenging and a valuable application of #purpose. It is also worthwhile to critique a movement’s purpose, suggest improvements, or suggest a way to align the purpose throughout.
4. Individual: When applying #purpose on an individual level, you will find much more flexibility in defining a purpose or changing goals. You can do this, for example, around coaching or when working on your capstone. Setting a clear purpose for yourself can help you choose actions to focus on and help you prioritize the things that matter to you. In applying this HC in individual contexts, you might use the SMART framework to adopt goals and then describe a process of reaching a set of aligning missions, goals, and actions, explaining and reflecting on the adequacy of the means you adopted to achieve those goals.

## Applying the HC outside Minerva

1. Group Work - Setting shared values and goals with a group can be a great way to create a shared sense of purpose in your work. In many organizations, it unites a team to work together in the face of difficulties. You might reach such a shared sense of purpose from an inspiring leader or from having conversations and brainstorming about what connects you as a team. You can apply this HC when you articulate shared goals and use them to focus your strategies for implementation.
2. Planning your Life - Whether professionally or personally, having a strong sense of purpose will help you stay energized and focused on the things you do. As you discover what values you feel connected to, #purpose can help you transform those into a broader personal strategy to stay aligned with those values. Similarly, you might look at what you are doing and ask yourself: What goals is this connected to? Ikigai is a framework that you might come across and relates significantly to creating a meaningful life. It divides life - or a career - into four areas: doing what you love, doing what you are good at, doing what the world needs, and doing what pays. This framework helps imagine the wide variety of domains touched by adopting different kinds of #purpose.
3. Helping others find their purpose - Recognizing what their values are and suggesting to them how to put those into practice can be an effective way to build trust and understanding in your relationships. It can help share some of the burdens of making changes or adopting new habits. Sometimes, this might be sharing opportunities that align with someone’s long or short-term goals and, most important, values. In a professional context, people working in human resources or recruiting will benefit from identifying how someone else’s values and goals might align with the opportunities around them. Or, when someone is struggling with some sense of meaning, you might look closely at what misalignment causes this. Maybe one of their primary responsibilities in their work directly opposes one of their core values.

## Key resources

1. Locke, Edwin A., and Gary P. Latham. ‘Building a Practically Useful Theory of Goal Setting and Task Motivation: A 35-Year Odyssey’. American Psychologist 57, no. 9 (2002): 705–17. https://doi.org/10.1037/0003-066X.57.9.705.
2. Collins, Jim, and Jerry I. Porras. ‘Building Your Company’s Vision’. Harvard Business Review, 1 September 1996. https://hbr.org/1996/09/building-your-companys-vision.
3. Grote, Dick. ‘3 Popular Goal-Setting Techniques Managers Should Avoid’. Harvard Business Review, 2 January 2017. https://hbr.org/2017/01/3-popular-goal-setting-techniques-managers-should-avoid.


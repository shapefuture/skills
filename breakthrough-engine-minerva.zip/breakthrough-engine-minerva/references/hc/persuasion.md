# #persuasion — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/persuasion/](https://my.minerva.edu/academics/hc-resources/hc-handbook/persuasion/)
> **Habit of Mind** · Cornerstone course: Multimodal Communications · Competency: Interacting Effectively → Negotiating and persuading
> Taught in: Multimodal Communications | Semester Two · Unit: Persuasion
> Big Question: What is involved in persuasive communication?

## Definition

**#persuasion** — Craft and interpret communications that create a favorable disposition or move audiences to do something.

> **Pitch:** Persuasion techniques are similar to fallacies, they may not be logically sound, but they can still be effective.

Persuasion techniques appeal to human’s emotional range and tendency to reason in particular ways. To craft effective persuasions, one must understand their audience’s motivations and social attitudes as well as their likelihood and ability to engage in particular kinds of reasoning. If not executed carefully, persuasions can even backfire, causing audiences to do the opposite of the intended persuasion. Emotions in particular are deeply involved in decision-making, so directly appealing to an audience’s feelings (e.g., pleasure, humor, surprise, fear) can amplify a persuasion.

## Worked example

You are trying to convince your family to start taking their reusable cups out for coffee. They claim to care about the environment, but they don’t think the benefit of using a reusable cup outweighs the inconvenience of carrying it. You create a presentation for them where you quantify how much harm they cause by not using a reusable cup and how many of their favorite animals they could help by using it. You show them photos of cute otters huddling together among plastic debris. You remind them that you are majoring in Natural Sciences and study exactly this type of issue in class, establishing yourself as a credible source. You then present the fact that they can also get a 10 cent discount in many cafes if they use their own cup. You make sure to explain that the baristas in coffee shops can rinse your cup for you so you don’t need to wash the cup prior. You then remind them of how much work they’ve done for the environment and their passion for conservation. After your presentation, your family realizes it would be hypocritical of them to not take their reusable cup but claim to be environmentalists. Because it is a simple thing to adopt, they try taking reusable cups out with them.

> **Footnote:** Several persuasion techniques are utilized, including an appeal to authority (when you state your credibility) and emotion (guilt when seeing the cute otters suffering), increasing cognitive dissonance (by pointing out their hypocrisy), an appeal to logic (because of the financial incentive adding to benefits and the lowering of costs by explaining the practicality of having your cup rinsed) and a push to change their attitude instead of their commitment to environmentalism (by reminding them of the reason for their passion) to get your family to shift their behavior.

## Is it this HC?

Is #persuasion the right HC? If the answer to the following questions is yes, #persuasion could be useful:

- Does the work try to influence the audience in some way, with a goal of changing their beliefs or actions?

- Does the work lean on one of the four theories of persuasion to send its message?

- Does the work critique how a work persuades its audience?

- Does the work appeal to the audience’s emotions?

However, depending on the focus of your work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#organization](organization.md), [#sourcequality](sourcequality.md), [#evidencebased](evidencebased.md), [#induction](induction.md) | These HCs can make your #persuasion more effective, particularly if you are following the central route in the elaboration likelihood model. |
| [#conformity](conformity.md) | Identify and analyze social norms, their features, origins, and development, sometimes with the intent to influence others to conform. Particularly relevant to social judgment theory. |
| [#psychologicalexplanation](psychologicalexplanation.md) | Knowledge of these psychological tendencies helps one persuade more effectively. |
| [#medium](medium.md), [#audience](audience.md), [#context](context.md) | Use these HCs along with #persuasion to identify which type of persuasion would be most effective for your communication. |
| [#fallacies](fallacies.md) | Use #fallacies if the focus is on how to eliminate or mitigate the fallacy. |
| [#shapingbehavior](shapingbehavior.md) | Use #shapingbehavior if you are changing factors in the outside world (like incentives) to change behavior. Use #persuasion if you are trying to change someone’s perceptions or beliefs in order to change their behavior. |
| [#emotionaliq](emotionaliq.md) | Understanding and managing both your own and others’ emotions can make your message more compelling. By recognizing emotional cues, you can adapt your tone, framing, and delivery to better connect with your audience and influence their response. |

## Self-study Q&A (7 questions)

**Q1. What is Social Judgment Theory?**

This persuasion theory states that understanding the intended audience of one’s persuasion is essential to persuade effectively. People anchor themselves to their preexisting beliefs and make judgments from this “anchored” position. Therefore, one must know whether their audience’s anchor falls on the latitude of rejection, the latitude of acceptance, or the latitude of non-commitment concerning the persuasive goal. When audience members fall in that last category, persuasion may be effective. 
For example, the political parties in the US spend most of their resources on persuading Independents to vote for them by meeting Independents at their anchor points and working to move them towards accepting their candidacy and/or rejecting the opponent. This is a lot easier than trying to persuade voters who already firmly support the opposite party.

**Q2. What is the Elaboration Likelihood Model?**

This model illustrates how cognitive reasoning processes play an essential role in whether a persuasive appeal is compelling. This model consists of the central and peripheral routes. 

- The central (or elaborated) route uses information, data, logical argumentation, and evidence to persuade the audience in some way. Processing this type of persuasion takes cognitive effort, so it works best when the audience is already motivated and able to process the topic. A good example of the ELM-central route is academic/research papers.

- The peripheral route relies on surface-level cues rather than deep processing. These cues include things like authority (e.g., “Nine out of ten doctors recommend…”), liking or affinity, social proof (e.g., “Everyone is doing it”), scarcity, and repetition. This route is more effective when the audience is less motivated or less able to engage deeply with the content. While often associated with emotional appeals, it’s important to recognize that emotions can play a role in both central and peripheral routes. What matters here is the audience’s level of involvement and the nature of the cues used.

**Q3. What is Cognitive Dissonance Theory?**

This theory explains that people feel uncomfortable when their actions are out of sync with their beliefs. This theory is used to persuade people to resolve their feelings of dissonance by offering ways to align their actions with their beliefs. This type of persuasion is often used after someone has made a decision to convince them it was the right thing to do and aligns with their values. 
For example, electric vehicle companies may point out that people say they care about the climate, but then drive their gas-powered cars that pollute the environment. This way, companies persuade customers to buy their EVs, which resolves the conflict between their beliefs and actions.

**Q4. What is the Narrative Paradigm?**

This theory explains that people naturally use stories to make sense of their world; therefore, a good story can be more convincing than a good argument. A persuader can use a story to relate to and gain the audience's trust, which creates a strong foundation for effective persuasion. Emotional narratives are usually the most persuasive and are often used by persuaders to show the audience their values without telling them directly or offering distinct evidence. To apply this theory effectively, it's important to recognize the key elements of a narrative: plot, characters, and point of view. Ask yourself, what is the story being told? Who are the characters, and whose perspective is guiding us? 
For example, a politician might tell a story of a family with young children that struggled to avoid homelessness, influencing the audience to associate values of compassion and humanity with the politician.

**Q5. What is the boomerang effect?**

This effect occurs when an attempted persuasion uses the wrong kind of messaging or pushes too hard, resulting in the opposite effect than was intended. 
For example, you are trying to persuade your friend to support a bill introducing better national health insurance in your country. However, you present them with a strongly worded argument for higher taxes, universal human rights to healthcare, and taking from the rich to give to the poor. Instead of becoming more open-minded about the struggles of less privileged people and seeing healthcare as a human right, your friend becomes defensive and even more sure that they won’t support the bill. The aggressive presentation of the argument, in combination with the large discrepancies between the two beliefs, makes the friend close up even further and stick to their existing beliefs.

**Q6. What is the difference between persuasion and manipulation?**

In manipulative communication, the audience is unsuspecting and does not get the chance to decide for themselves. Often the information they were provided with was not truthful and generally misleading. In persuasive communication, the audience knows they are being urged to do something, the information provided is truthful, and the audience is able to decide for themselves. However, the line between persuasion and manipulation can become thin, so it is essential to persuade responsibly and be critical of the persuasion you face.

**Q7. What step-by-step process can be followed when applying #persuasion?**

When using persuasion as an analysis tool (rather than crafting a persuasive piece), you can follow this process: 
- Call out a persuasive theory and explain how it functions in general.

- Connect the theory to the situation at hand - the goal and mechanism of persuasion, and the audience you are persuading.

- Explain the response of the audience to the persuasion - what emotions they might feel, what caused those emotions, and how it contributes to the persuasion.

## Guided reflection (proficiency checklist)

1. Have you identified and justified which persuasive technique(s) best align with the audience and topic, demonstrating that you’ve considered alternative approaches?
2. Have you explained whether the audience’s beliefs align with their behavior and where the audience lies on the spectrum of acceptance and rejection?
3. Have you discussed how much the audience is motivated by, emotionally invested in, and educated on the persuasive topic?
4. Have you discussed how storytelling relates to and persuades the audience?
5. Have you identified the emotions the audience should feel in response to the proposed persuasion technique and how you might make the audience feel those emotions (#connotations, #expressions, #multimedia techniques, etc)?

## Common pitfalls

1. The application does not utilize any persuasion techniques.
2. The application claims to have used a particular persuasion technique when using another.
3. The application does not explain why certain persuasive techniques were utilized over others.
4. The application does not understand its audience, making the persuasion unrelatable and ineffective.
5. The application has crossed the line between persuasion and manipulation.
6. The application attempts to identify too many emotions at once, leading to a superficial analysis that lacks depth
7. The application vaguely claims that “emotions are evoked” without naming specific emotions or explaining the persuasive mechanisms that cause them.

## Applying the HC at Minerva

You may use persuasion to convince different audiences to care about a new green energy solution that could fight against climate change. Since climate change directly affects every person on earth and you need widespread support, you want to spread information about this clean energy development to multiple audiences. However, you understand that to convince each audience to care about your development, you must use different routes of the elaboration likelihood method for different audiences. 
- You utilize the central route of the elaboration likelihood model for your peers in the scientific field. This audience is already educated about climate change and energy developments and is motivated to learn more. You provide this audience with all the data your team has gathered that supports the effectiveness of your solution to provide efficient energy and reduce greenhouse gas emissions.

- You turn to local news outlets to educate the general public about your findings. You decide to use the peripheral route of the elaboration likelihood model because this audience is not necessarily motivated to care about climate change or your energy solution. You establish yourself as a credible source of authority by listing your credentials and high-profile team. You recruit well-known people who are not experts in science but are generally trusted by the public for their excellent judgment and character to support your findings, promote clean energy, and appeal to the audience’s affinity. Finally, you appeal to scarcity by explaining that time is running out to combat climate change, so the audience must act now by supporting your clean energy solution.

## Applying the HC outside Minerva

You see persuasion all the time in advertisements in person and online. Knowing about persuasion theory can help you combat unwanted influence from such advertisements. Ask yourself: 
- Does the information that there are only two more Harry Styles posters left at this price actually change whether or not you need another poster of Harry? Probably not. However, this information does appeal to your sense of scarcity and may make you more willing to buy unneeded decor!

- Does that message that your airline donates money to offset carbon emissions give you the extra push to buy a ticket when you could take public transportation? Maybe, but it probably shouldn’t! You know that message was designed to cure the dissonance you feel when your flying patterns are out of line with your environmental values.

## Key resources

1. Carter, C. & Yang, M. (2023, January). A Brief Guide to Persuasion. https://docs.google.com/document/d/1KnrDuBmptY7SC4-AonDuJ2B2uYv4Bg3fNqFpNKlf-Z8/edit
- This resource provides an overview of persuasion principles and theories.
2. Noggle, R. (2021, April 8). How to tell the difference between persuasion and manipulation: Aeon ideas. Aeon. https://aeon.co/ideas/how-to-tell-the-difference-between-persuasion-and-manipulation  

- This resource breaks down the difference between persuasion and manipulation.

## Custom HC guides

- [A brief guide to persuasion](https://docs.google.com/document/d/1KnrDuBmptY7SC4-AonDuJ2B2uYv4Bg3fNqFpNKlf-Z8/edit)

# #critique — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/critique/](https://my.minerva.edu/academics/hc-resources/hc-handbook/critique/)
> **Habit of Mind** · Cornerstone course: Multimodal Communications · Competency: Thinking Critically → Evaluating claims
> Taught in: Multimodal Communications | Semester One · Unit: Close Reading
> Big Question: How does language represent reality?

## Definition

**#critique** — Actively and critically engage with texts and other forms of communication.

> **Pitch:** A successful critique allows you to dive beneath the surface and discover the treasures and ruins that lay below.

Understanding a text or communication requires a deep examination of its claims, assumptions, ambiguities, and language. To critique is to analyze a work or its features, such as its logic, evidence, structure, or content. By paying close attention to these features, one should be able to identify a work’s strengths and weaknesses, and any possible ambiguities, implicit messages, or biases.

## Worked example

You are producing a research paper for your political science class on how recent shifts in voter trends among Indian citizens relate to laws regarding expanded rights for same-sex couples. You read an article by a political scientist claiming that Indian citizens do not think current laws offer enough protection to same-sex couples. First, you read the text carefully and slowly, capturing important details, anomalies, and questions and noting them in your annotations. You reread and look for patterns across your annotations. Some of the author’s words have slightly negative connotations, which you recognize as potentially effective in delivering the vivid thesis. Still, you note emotional language may be a sign of bias. While you find that the article stays precise and clear, you note an anomaly: the study bases its conclusion on three interviews conducted with same-sex couples from a small town in the country. Such a small sample size (n=3) is unusual in the context of political science research, which requires a rigorous scientific method. The sampling method was inappropriate, as it contained one small village but generalized to the whole country. By the end of your reading, your close analysis has illuminated some strengths in the paper – primarily its clarity and inclusion of personal interviews – but highlighted the main pitfall of sampling errors. You decide you can utilize the anecdotal data from the interviews to draw qualitative insights from individual experiences if you clearly state that these experiences are not generalizable.

> **Footnote:** Your critique of the article illustrates deep engagement with the text, including close reading, annotation, and pattern recognition. You find patterns in emotional language and clear composition but abnormalities in the research methods. You explain the strengths and weaknesses of the article based on your critique, justifying which aspects of the article could be used for your research paper.

## Is it this HC?

Is #critique the right HC? If the answer to the following questions is yes, #critique could be useful:

- Are you engaging deeply with a text or other work to conduct an analysis?

- Are you recognizing patterns and anomalies in the work or across works?

- Are you identifying a work's strengths and weaknesses by deeply examining its features?

Depending on the work product, there might be other HCs to consider. ….

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#connotation](connotation.md) | understands, identifies, and uses connotations, tone, and style; this may be an aspect of a work noted when applying #critique. |
| [#composition](composition.md) | communicates with a clear and precise style; this may be an aspect of a work that stands out when applying #critique. |
| [#context](context.md) | situates a work in its relevant context (e.g., historical, disciplinary, cultural); a #context application will inform your #critique analysis. |
| [#medium](medium.md), [#multimedia](multimedia.md) | often, when applying #medium and #multimedia to understand the message of a creative work, an application of #critique would complement the analysis. |
| [#evidencebased](evidencebased.md) | integrates relevant evidence into a work; evidence should be used to back up claims made in a critique of work. |

## Self-study Q&A (5 questions)

**Q1. What is close reading and annotating?**

Close reading is engaging deeply with a text, observing facts and details about the text as you go. It is often helpful to preview the work before diving into close reading; this means noticing any headers, graphics, or pictures that stand out as you skim the text and gain a general idea of its purpose. Then you start from the beginning and read carefully and slowly, paying attention to rhetorical features, structural elements, and cultural references. However, close reading can focus only on selected features that are most important to your writing or the center of your analysis, so be mindful. As you read, you annotate, noting important details or questions in the margins, underlining keywords and ideas, and summarizing dense sections. Once you have closely read the text, you must interpret those observations.

**Q2. How does one interpret observations gained from close reading?**

To interpret the insights gained from close reading, one must return to their annotations, looking for patterns (repetitions, contradictions, similarities) and making note of peculiarities. You should explore the structure of the text and language details, analyzing the author's style to portray their message. Examine what metaphors or other literary devices were used in the work and why or why not they were effective. Then you must ask questions including: 
- What is this getting at?

- What is the point?

- Are they trying to convince me of something?

- What is the author’s motive?
Look back at the text for more details if the answers to these questions do not stand out in your annotations. This process of interpretation and questioning leads you to a deep understanding of the text and puts you in the position to write a meaningful and analytical critique.

**Q3. What steps can be followed to apply #critique?**

- Pick a Specific Detail or Feature: Identify a concrete element that stands out in the work.

- Describe It Clearly: Provide a precise description of the chosen feature.

- Articulate Its Meaning or Implications: Explain its significance and what it conveys or evokes.

- Connect It to Broader Patterns: Relate it to other elements, themes, or motifs in the work.

- Link to a Larger Insight: Synthesize your analysis into a comprehensive conclusion about the work.

**Q4. Does an application of #critique require documentation?**

Yes. Since #critique is a process HC that requires a lot of work behind the scenes (close reading, annotation, questioning, interpretation, analysis), documentation of that process is provided in a strong application of #critique. For example, you may submit scanned images of the text with your annotations written clearly in the margins.

**Q5. How does #critique differ from #medium? (and maybe how can they be used together?)**

These two HCs both involve analyzing works on a deep level. If the analysis is medium-specific, evidence should stem from medium-specific elements. Applying #medium may also be more appropriate in cases where a medium is utilized across different works, and comparisons on the basis of medium are being made. However, #critique is not confined to the medium, so #critique applications tend to include other aspects of a work and analyze how they work together. When applying #critique, emphasis is put on looking for patterns and differences, either in that work or across works with similar messages. 

The question is whether your work applies one HC or the other or both particularly well -- and that depends on your purpose. Critique focuses on drawing to the surface something latent or nonobvious about a work to help readers or viewers understand the work's message, context, constraints, etc., more richly. Sometimes you can use medium-specific observations to support a critique. For example, when critiquing a sonnet, you would no doubt pay attention to the poetic features that distinguish sonnets from other poems to understand the author's choices and how they affect the poem and its reception. But you could also apply #critique without applying #medium by drawing to the surface features of a work that aren't medium-specific. For example, you might analyze a descriptive paragraph from an essay to better understand an author's tone or feeling toward a subject. But unless you connected your analysis of tone to something specific about the medium of an essay, you likely wouldn't apply #medium.

## Guided reflection (proficiency checklist)

1. Have you engaged in close reading or critical interpretation of the work(s) you are critiquing?
2. Have you annotated for essential details, questions, or anomalies that stood out to you?
3. Have you effectively selected a salient feature of a work for critique and justified your choice?
4. Have you effectively analyzed or evaluated a salient feature of a work's logic, evidence, structure, or content?
5. Have you clearly justified your selection, analysis, or evaluation of the work?

## Common pitfalls

1. The application does not analyze or evaluate a work's logic, evidence, structure, or content when prompted or does so mostly or entirely ineffectively.
2. The application does not engage in close reading but instead jumps to a surface-level analysis.
3. The application does engage with close reading but does not think critically about those observations or analyze them in any way.
4. The application criticizes the work rather than critiquing it; criticizing is judgmental and negative, while critiquing is descriptive and neutral (focuses on both strengths and weaknesses).

## Applying the HC at Minerva

1. The principles of this HC are valuable anytime you are engaging deeply with a communication, whether that be a novel, poem, scientific paper, or piece of code. Thus, this HC can be applied across all fields! Whatever mode of communication you are working with, your critique will be stronger by employing close reading strategies to actively think about the work and analyze it as you read. Slow down, notice details, and use annotations as you go (e.g., highlight, summarize, mark questions, etc.). Noticing small details is what helps you make non-obvious insights about texts as a whole. Meaningful applications will offer a substantive explanation of how your close reading strategies led to an effective analysis.
2. You may critique how one utopian work responds to another. The message of one work may be “the absence of feelings creates a perfect world,” and the message of the responding work is “the acceptance of all feelings creates a perfect world.” Since the second work directly responds to the first with a near-opposite claim, close reading, and annotation may reveal interesting patterns. For example, perhaps the second author actively uses the same words to describe the opposite utopia, matching the connotation of the first story but creating new meaning. Then you utilize the insights drawn from your annotation to critique how the two stories compare, highlighting the strengths and weaknesses of both messages and the literary methods used to illustrate them.
3. You critique a psychological study on leading by example and follower traits. To do so, you trim your broad arguments and align them with elements of the specific study that support your critique. First, you close read and annotate the study. You realize how confusion can result when studying leadership by example when the first participant is often the example to the others, whether or not they are an active leader. You note how this aspect of the study could significantly affect the results but is not mentioned as a limitation. However, you notice that the sample size is sufficiently large, and significance can appropriately be inferred from statistical tests, which you highlight as a strength. Overall, this critique of the study allowed you to analyze its strengths and weaknesses and empowered you to suggest improvements rather than accept the information at face value.

## Applying the HC outside Minerva

You may use this HC when critiquing a local politician's effective speech to analyze it deeper and determine why it was so effective. First, you would print and closely read the speech, including annotations. You will search for patterns in how words, tone, composition, literary devices, and other features were utilized or neglected. For example, you may find that emotionally loaded words were used to describe the topics the politician is passionate about, while examples of past work were utilized as evidence that the politician truly cares about those issues. You determine that the combination of “telling” with strong emotional connotations and “showing” with relevant examples made this politician's speech so successful.

## Key resources

1. Kain, P. (1998). How to do a close reading. Boston Latin School Association. Originally published for the Writing Center at Harvard University.https://www.bls.org/apps/search/how-do-close-reading
- This guide will explain how to close read and lead you through a model for further clarification. Close reading is an integral part of critical reading. When you close read, you examine the details of a text, and you use these details to discover inductively the piece's message and/or argument. — [link](https://www.bls.org/apps/search/index.jsp?q=kain#gsc.tab=0&gsc.q=kain&gsc.page=1)
2. Research Guides: Interrogating Texts: Reading Strategies. (2020). Harvard.edu. https://guides.library.harvard.edu/sixreadinghabits
- This set of guidelines and suggestions from Harvard Library gives you introductory tools for approaching complex texts. Critical reading is a vital foundational skill for every discipline. As the texts you tackle become more complex and esoteric, you will need good active reading strategies to decode and analyze a text systematically.
3. The Writing Center. (n.d.). A Short Guide to Close Reading for Literary Analysis. University of Wisconsin - Madison. https://writing.wisc.edu/handbook/assignments/closereading/
- This resource walks you through close reading by providing a sample close reading and brief analysis of the poem “Design” by Robert Frost.


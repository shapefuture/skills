# #context — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/context/](https://my.minerva.edu/academics/hc-resources/hc-handbook/context/)
> **Foundational Concept** · Cornerstone course: Multimodal Communications · Competency: Thinking Critically → Evaluating claims
> Taught in: Multimodal Communications | Semester One · Unit: Interpretation
> Big Question: How do we interpret artistic communication?

## Definition

**#context** — Situate a work in its relevant context (e.g., historical, disciplinary, cultural).

> **Pitch:** Misunderstandings arise when we fail to appreciate context.

When drawing and analyzing inferences about any expressive work—for example, a piece of writing, a sculpture, a symphony, a song, a speech, or even a scientific work—it is important to understand its context. To whom is the work addressed? What historical events shaped it? How is it responding to other works in its genre? What contributions does it make to its discipline? And how is it shaped by its culture? All of these questions are important to answer when developing an interpretation of a work.

## Worked example

Many casual listeners of the popular song “Chandelier”, by Sia, believe that the song is a party anthem about having fun. This interpretation arises from the repetition of the lyrics “I’m gonna swing from the Chandelier”, and “One, two, three, one, two, three drink”, which are emphasized in the chorus. As a popular song, people place it in context with popular culture — one that highlights partying and recreational drinking. However, placing it in such a context may lead to misinterpretation. The song is in fact about alcoholism. This is revealed by looking at the context of production: Sia has personally struggled with alcoholism in her past. Keeping authorial context in mind, and the context of the genre which is that artists often write about personal struggles in their music, a new interpretive lens is used to approach the song’s analysis, and one quickly finds out that these lyrics are meant to reflect the addictive and risky nature of alcohol.

> **Footnote:** The context of the genre allows for an understanding of why the song is misunderstood (the chorus is most emphasized) as well as supports the new interpretation given about the lyrics (pop songs are often ways to share personal struggles). This is further supported by the author’s personal context.

## Is it this HC?

Is #context the right HC? If the answer to the following questions is yes, #context could be useful:

- Are you analyzing a work within the circumstances it appeared?

- Are you investigating how a certain work came to be?

- Are you utilizing context to effectively interpret what a work means?

- Are you considering how an artist’s or author’s context shaped their work?

However, depending on the focus of your work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#interpretivelens](interpretivelens.md) | Recognizes how prior experiences, expectations, and judgments affect interpretation; this HC focuses on the individual level, while #context focuses on the group level of interpretation. |
| [#audience](audience.md) | Tailors work products to the intended audience; the intended audience of a work is important to consider when applying #context. |
| [#evidencebased](evidencebased.md), [#sourcequality](sourcequality.md) | These HCs are integral in finding and vetting sources and integrating those sources into your work; contextual claims must be backed up with rigorous argumentation and evidence from credible sources because such claims can not just be asserted. |
| [#medium](medium.md), [#multimedia](multimedia.md) | It is often best to apply #context along with #medium and #multimedia to understand how social and historical context shapes the message of a creative work. |
| [#critique](critique.md) | An understanding of #context will elevate your application of #critique, which involves actively and critically engaging with texts and other forms of communication. |

## Self-study Q&A (5 questions)

**Q1. Why do circumstances matter?**

Circumstances matter because understanding the context in which something occurs can affect our understanding, interpretation, and feelings about it. These factors are significant in history, social affairs, and any products of human culture. However, context also matters in work focused on the natural world because causes interact in complex ways to produce their effects. If, for instance, you want to propose new legislation promoting biodiversity offsetting, your arguments will need to draw from empirical evidence about the need for such measures and be attentive to the context that helped produce existing legislation. Thus, the richest understanding of a situation comes from a full appreciation of the circumstances in which it appears. For example, a yell in a place of worship may cause fright and draw attention because such places are traditionally quiet and calm. On the other hand, the same yell at a football match would be considered normal and part of fan culture. The circumstances give the sound meaning and inform the people around them how they should feel.

**Q2. What questions can one ask about a work’s context?**

(Note that this list is non-exhaustive)

- What cultural context was the work made in?

- What was the economic and political climate of that time? 

- What social movements were taking place? 

- What recent discoveries were made? 

- What is the creator’s background? 

- What does the creator care about?

**Q3. How can #context inform applications of #medium?**

To understand why a particular medium was chosen for a piece, #context can be extremely informative. Situating the work in its context deepens your understanding of the meaning embedded in the work’s medium. You may question what medium was most popular for the artist’s purposes and investigate the common ways of utilizing that medium at the time. Some anthropologists, like Clifford Geertz, argue that one cannot separate the formal elements of a work of art from its cultural context. This idea highlights just how integral #context is to understand the purpose and importance of a piece.

**Q4. How do applications of #context differ from applications of #interpretivelens?**

Apply #context, not #interpretivelens, when arguing that another person’s actions or views are shared by their social or historical context. The key difference is that #interpretivelens focuses on the individual level, and #context focuses on the group's cultural level. Therefore, #interpretivelens analyzes how personal experiences, expectations, and purposes impact one’s own or another’s interpretation, while #context analyzes how cultural norms and values impact interpretation and interaction. However, the two can overlap because cultural norms tend to shape personal experiences and expectations. For example, if you are researching the author of a work, you may be trying to situate the work in its context, but you may be trying to understand what shaping factors lead the author to take a particular perspective. Choosing which to apply can be tricky, so ask your professor for guidance if you are unsure which to apply.

**Q5. What is a “work” and how narrowly confined is it?**

A “work" is typically envisioned to be a single work of writing or art, but it can apply more widely in different courses and disciplines. Multiple works might be relevant to applying #context, particularly when tracking patterns in the development of an idea or theory, for example. It is important to discuss with your professor what they consider to be a “work” for particular purposes. For example, in an ethics class, you may be asked to apply #context to an idea; situating that idea in the social norms and questions of the time can reveal new insights. However, an idea may not be considered a work in other disciplines, so you should always ask for clarification when possible.

## Guided reflection (proficiency checklist)

1. Have you accurately identified and effectively analyzed multiple or subtle aspects of a work's relevant background, discipline, genre, or influences?
2. Have you based your interpretation of a work’s context on high-quality evidence? Have you cited all of your evidence?
3. Have you used aspects of a work's background, discipline, genre, or influences to produce a sophisticated interpretation?
4. Have you skillfully worked your analysis of contextual factors into your work so that it informs and elevates your applications of other HCs.
5. Have you explored how the interpretation would be different if situated in another context?

## Common pitfalls

1. The application tags #context when only the basic background information of the claim is presented without using contextual analysis to transform the argument or interpretation of the work.
2. The application does not recall or identify relevant background, discipline, genre, or influences of a work when prompted.
3. The application inaccurately or ineffectively identifies a work's relevant background, discipline, genre, or influences.
4. The application accurately identifies contextual factors but does not analyze how they influenced or interacted with the work.
5. The application of #context is based on broad sweeping generalizations, uncited work, or missing evidence.
6. The application of #context seems out of place and isolated from the rest of the work, adding no significant value to the work overall.
7. The application confuses #context with #interpretivelens, leading to an inaccurate or ineffective interpretation.

## Applying the HC at Minerva

1. You will likely have opportunities to apply #context in a wide range of core and concentration classes in which you use careful contextual research to help improve the quality of your interpretation of a work for an assignment. For example, when analyzing work written by Frantz Fanon in Arts and Literature or Philosophy courses you can apply this HC by digging into his historical context as a subject of France under colonial rule in Algeria, who supported the Algerian War. To apply the HC effectively, you would need to engage in careful research to dig beyond merely giving a background description of the author or his writings. Look for ways to use careful contextual analysis to support an argument about the way attending to the work’s context helps us better understand something about the work itself. For example, in this case, contextual evidence could be used to support interpretive or evaluative claims about Fanon’s arguments concerning the uses of violence as a tool for decolonization.
2. Perhaps you are leading a tutorial on how musical elements create meaning in the song Hotel California by the Eagles. To do this, you situate the song in the context of the United States in the late 70s, the period in which the song was made and released. You explain how the “American Dream,” or the idea that anyone can succeed, has long been a belief in the minds of many Americans, referring to a high-quality resource published by a social psychologist. Then, you engage in contextual research and identify three promising historical events that you argue affected pop culture at the time, forcing many people to realize that the “American Dream” only lived in their imaginations. For one, the Watergate scandal revealed widespread political corruption in the government, making the general public distrustful of the government. The U.S. finally pulled out of the Vietnam War, losing the war amidst high antiwar sentiment, decreasing Americans' pride in their country. Mass consumerism was on the rise, and people’s material possessions began to impact their idea of self-worth. These contextual factors all blended together to create a new generation of people who actively questioned the government, patriotism, and capitalism and recognized that the “American Dream” was becoming an American nightmare. The Eagles recognized this shift in pop culture and wrote Hotel California in response. Therefore, the song represents the backsliding of the “American Dream,” and the Eagles skillfully crafted the elements of musical medium to capture this meaning. You then dive into a medium analysis of Hotel California, which is appropriately informed by the song’s context.
3. Applications of #context are relevant in any discipline, so make sure to think creatively about what contextual analysis adds to your work in each field. For instance, you could be engaged in research for a capstone project in which you explore how mathematics is used to encode cultural and personal symbols. You could use both mathematical and social/cultural evidence to defend a claim about commonly overlooked practices of mathematics in some parts of the world, showing ways that mathematics practices are embedded in cultural practices. There are also several examples of custom tutorial and capstone LOs that reflect ways to specify the application of #context for each discipline, including #artcontext, #sciencecontext, and #mathcontext. When in doubt, reach out to your instructor or advisor for help in deciding whether the HC #context or a more narrowly tailoring/custom LO might serve your purposes better.

## Applying the HC outside Minerva

You may want to apply #context when you are bombarded with advertisements. By situating those ads in the appropriate context of the producing company's economic strategy, you learn to look past the persuasion such companies use to convince people they need certain products. For example, razor companies try to convince people that body hair is unattractive, uncomfortable, and something people should be ashamed of. By doing this, the razor industry created social norms that kept them in business, as people began to internalize these messages. However, before razor companies existed, no one had a problem with their body hair because it is a natural part of humanness. Therefore, when faced with an advertisement for razors that guilts you into thinking your body is not good enough, you can use this context to help inspire you to fight back. The social norms may change slowly, but you can recognize that the razor company is trying to exploit your insecurities for money and decide not to buy into it.

## Key resources

1. Geertz, C. (1976). Art as a Cultural System. Modern Language Notes, 91(6) Comparative Literature, 1473-1499. Available in JSTOR Essentials
- Clifford Geertz was a celebrated American cultural anthropologist. His work still influences the fields of anthropology and communications. In this seminal article, Geertz argues that we cannot separate the formal elements of a work of art (e.g., color, line, imagery, rhythm, etc.) from its cultural context. Or, in his own words, “the means of an art and the feeling of life that animates it are inseparable” (p. 1477). He argues that to understand a work of art, we must go beyond analyzing the aesthetics of a piece and consider why a particular culture may have valued those aesthetics. This is a difficult and complex article; don't expect to understand all of it on your first read.
2. Suski, J. (2022, June 6). Complete Guide of Context Analysis [2022] | Brand24. Brand24. https://brand24.com/blog/context-analysis/
- This resource dives into how context can be richly applied in business fields.
3. Tennant, J. (2017, September 29). Why “context” Is Important for Research – ScienceOpen Blog. Scienceopen.com. https://blog.scienceopen.com/2016/05/why-context-is-important-for-research/
- This resource breaks down the context of the word context and then dives into how context can be effectively utilized in scientific fields.
4. Contextual Analysis. (2017, March 15). Art History Rules; Art History Rules. https://arthistoryrules.wordpress.com/essays/contextual-anal/
- This short resource breaks down contextual analysis in art fields, including a list of questions to ask about the artist, their background, and the social environment of the time.
5. Warwick, J. (2011). The Motown Effect- Short Documentary, Motown and Civil Rights [Video]. YouTube.
- This video fills in the historical context of Motown records. It is best to listen to songs produced by Motown and then watch this video. It offers social, musical, and historical #context to shape how we think about Motown music. As you watch, think about how this history lesson changes how you hear songs produced by Motown and how the context of the civil rights shaped Motown music in particular.
6. Simon, S. (2019, January 5). American Anthem: 'Dancing In The Street.' npr.
- This podcast discusses the social, political, and historical context (and relevance) of the song 'Dancing in the Street.' This is a song produced by Motown, listen to it closely, identifying the interactions you find between #context and #medium-music.


# #negotiate — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/negotiate/](https://my.minerva.edu/academics/hc-resources/hc-handbook/negotiate/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Negotiating and persuading
> Taught in: Complex Systems | Semester Two · Unit: Prudence and effective interactions
> Big Question: How can conflicts be resolved?

## Definition

**#negotiate** — Use a structured approach to negotiation to reach desired objectives.

> **Pitch:** Master the negotiation for mutual satisfaction.

Effective negotiation involves give and take among stakeholders to reach agreements. Negotiating successfully requires a structured approach, which includes clearly identifying interests and areas of common ground, agreeing on a process, developing BATNAs, and being prepared to sacrifice some objectives to achieve others. Negotiators must prioritize objectives but remain flexible and open to compromise as the situation evolves. Approaching negotiation as a structured process raises the likelihood of a successful resolution.

## Worked example

Your company has assigned you to negotiate the construction of a new factory in Asia with the city government. The city officials don’t agree to outsource the cement work to the offshore contractor, because they want local employment. They also disagree on your choice of heavy machinery supplier because they believe you can find cheaper options locally. You consider your alternatives to a negotiated agreement in each dimension, and are willing to concede the offshore contractor because the company they prefer has comparable pricing and quality, but you know that only this specific machinery supplier has exactly what you need. You remind them that for the factory to succeed, you need the material from this particular supplier. You then remind them that it is in both of their interests to use quality material from the start, because not only will the factory’s presence inject capital into the local economy, but it will also avoid having construction issues and expenses that both parties would have to deal with down the line. You also keep in mind that if this agreement doesn’t work, you could always build the factory in a nearby town which would be a little less ideal but would fit your constraints, and the city government would incur a loss of employment as well as capital from the factory’s success. This alternative would be less ideal logistically but would be a larger financial loss for the city officials than you. This gives you the confidence to negotiate for the heavy machinery supplier to maximize gains in the negotiated agreement. By first making a concession about the cement work, they are more willing to take your offer and resolve the “small” detail of the equipment supplier. You eventually reach a satisfactory agreement using principled negotiation.

> **Footnote:** By focusing on interests instead of positions throughout the negotiation, the final agreement is adapted to fit each stakeholder’s priorities. A multidimensional BATNA is kept in mind, which provides the confidence and upper hand needed to push on the choice of heavy machinery supplier to maximize net gains from the negotiation.

## Is it this HC?

Is #negotiate the right HC? If the answer to the following questions is yes, #negotiate could be useful:

- Are you approaching a negotiation with an intentional structure?

- Are you mediating a dispute between parties?

- Are you analyzing a negotiation among other parties?

Depending on the work product, there might be other HCs to consider. ….

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#strategize](strategize.md) | Constructs a strategy by considering one's own or other’s strengths and weaknesses to achieve a goal. Structured negotiation can also involve a strategy. |
| [#powerdynamics](powerdynamics.md) | Uses the analysis of power dynamics to guide interactions. Understanding the sources of power among parties in a negotiation can be used to set realistic objectives and identify effective approaches. |
| [#persuasion](persuasion.md) | Crafts communication using different methods of persuasion to influence the audience. You can use persuasion techniques as a negotiator. |
| [#emotionaliq](emotionaliq.md) | Involves recognizing, understanding, using, and/or managing emotions to interact effectively. Understanding others and managing one’s own emotions is crucial for successful negotiations. |

## Self-study Q&A (5 questions)

**Q1. What are the four principles of principled negotiation according to Fisher and Ury? Explain each by contrasting to the positional negotiation approach.**

According to Fisher and Ury, the main characteristics of principled negotiation are: 

- Separate the People from the Problem: in principled negotiations, parties focus on the problem rather than personal emotions and interests. It avoids creating environments where people’s egos are threatened making it challenging to reach an agreement. In contrast, the positional approach can frame negotiations as a contest between the parties. 

- Focus on Interests, Not Positions: negotiators' interests and needs are prioritized to understand the true motivation behind the position. On the other hand, the positional approach may consider the position as the end goal. 

- Invent Options for Mutual Gain: principled negotiation aims to generate multiple options to address the needs and interests of all the parties involved. This may involve thinking of non-primary factors. For example, if you are negotiating salary, the agreement can be reached by discussing health insurance, or parental benefits. The positional approach will often consider the matter along a single dimension and fixate the options. 

- Insist on Using Objective Criteria: prioritize objective criteria such as market value, scientific data, government guidelines, etc. instead of subjective preferences. This means that negotiators should be open to reason. Contrary, the positional approach would result in one party imposing their will on the other.

**Q2. How can one achieve procedural common ground?**

Successful negotiation requires parties to agree on the procedure before reaching a mutually satisfying agreement. Every decision a negotiator makes can affect the procedure, however, it can be agreed upon in advance. For example, stating that you want to fully explain your position before answering any questions is an attempt to reach a procedural common ground. You can also agree on which issues are a higher priority. Furthermore, the decisions of the time and location of the negotiation also require agreement and can affect the outcome of the negotiation.

**Q3. What are some ways to protect yourself from undesirable outcomes of negotiation?**

A bottom line is the worst possible acceptable outcome. Having a bottom line can protect you from accepting an offer you will later regret, however, it can also limit your options as it reduces the incentive to invent solutions. Another method is to have BATNA: Best Alternative to Negotiated Agreement. Knowing your BATNA can help you be less committed to reaching the agreement (thus less likely to make costly compromises) or prevent you from being too optimistic about the alternative choices. “The better your BATNA, the greater your power”.

**Q4. In what circumstances can mediation be a more effective approach than negotiation?**

The involvement of mediators, i.e., impartial third parties, can become necessary under a number of circumstances, such as: when disputant parties cannot agree on the procedure (e.g., timing or location) of the negotiations, parties’ emotions towards the situation or each other make it impossible to have a calm discussion, differences over values divide disputants, etc.

**Q5. Example application: How can the principles of negotiation be applied to resolve conflicts in a multi-stakeholder environmental project, where parties have differing priorities, such as economic development, environmental protection, and community welfare?**

Entering the negotiation with the will to find common ground and prioritize interests instead of positions is always a good start. These conflicts have in common that they can all be broken down into different subfields and indicators. Often, some progress in one direction is better than no progress at all. Nonetheless, having a clear BATNA can protect you from disadvantageous outcomes. It is important to remember that these negotiations will most likely not be an isolated event. Parties may come together and negotiate multiple times, often with new information coming in at different stages. Maintaining a good relationship and a cooperative environment might be crucial. 

Of course, this is not an exhaustive list of important considerations. There could be many more possibly relevant factors depending on the conflict at hand.

## Guided reflection (proficiency checklist)

1. Have you justified your approach to the negotiation given the context?
2. Have you conducted research prior to the negotiation to inform your decisions?
3. Have you discussed the procedure in advance?
4. Have you reached a mutually beneficial agreement?
5. How well have you achieved your goals in the negotiation?
6. Have you analyzed the dynamics of negotiation (e.g., how did the positions change? Was the agreement reached?)
7. Have you applied the negotiation-related concepts to deepen your analysis of the application?

## Common pitfalls

1. The selected approach is not justified using context-specific information.
2. The analysis of the dynamics of the negotiation is superficial.
3. The techniques of negotiation are ineffective and miss the goal of negotiation.
4. Does not provide specific examples to demonstrate their knowledge of the concepts.
5. Superficial analysis of BATNA.
6. Does not consider power dynamics between the parties.

## Applying the HC at Minerva

1. You will apply this HC in business assignments to devise effective business strategies. For example, in M&A (mergers and acquisitions) case studies, you will need to assess per-share price of a company to adjust your minimally agreeable terms accordingly. BATNA is also relevant if the market is getting fierce and your competitors are starting to acquire other companies or if there are other companies that may offer similar/more benefits when acquiring.
2. Students taking SS courses, especially those related to political science, will use this HC when engaging in debates, analyzing the international diplomacy case studies, and suggesting a more effective approach to negotiation depending on the context. Students can also use this HC to come up with a negotiation strategy for trade agreements in assignments.
3. You may need to negotiate the scope of the project and task assignment with the civic partners in different rotation cities which you can reflect on in IL assignments.

## Applying the HC outside Minerva

1. Professionals who represent companies or nations (e.g., UN delegates) are required to have good negotiation skills, as they need to participate in decision-making that has large-scale impacts.
2. This HC can be used when one needs to negotiate salary and other benefits at the workplace. Developing your BATNA will help you make better decisions between the offered positions.
3. Negotiation is part of our daily lives. For example, you may need to negotiate with your partner about whose family to visit during holidays or which neighborhood to live in. Finding common ground and reaching mutually beneficial agreements is especially important when negotiation takes place among people in close relationships, as they need to maintain trust between each other and avoid resentment.

## Key resources

1. Kenney, N., McAllister, K. et al (2019). Understanding Common Ground in Negotiation. https://docs.google.com/document/d/1m7g5Oez8JeIKG-7MNNdXHX5rMC-EWFq9SBpYZ6dXcGM/edit
- This whitepaper describes how we will approach the concept of common ground in this course.
2. Fisher, R. & Ury, W. (2011). Getting to yes, Introduction and Chapters 1-6. New York: Penguin Books. https://www.amazon.com/Getting-Yes-Negotiating-Agreement-Without-ebook/dp/B0051SDM5Q/ref=tmm_kin_swatch_0?_encoding=UTF8&qid=&sr=
- This classic text on negotiation distinguishes between positional and principled negotiation and discusses strategies for successfully employing the latter approach. Chapter 6 describes the concept of a BATNA.
3. Fisher, R. & Ury, W. (2011). Getting to yes, Chapter 6 (pp. 99-108). New York: Penguin Books. https://www.amazon.com/Getting-Yes-Negotiating-Agreement-Without-ebook/dp/B0051SDM5Q/ref=tmm_kin_swatch_0?_encoding=UTF8&qid=&sr=
- This chapter ("What If They Are More Powerful?") describes the concept of a BATNA and explains why developing BATNAs, including for other stakeholders, is preferable to simply having a bottom line.
4. Moore, C. (2014). The mediation process: Practical strategies for resolving conflict (4th ed.). San Francisco, CA: John Wiley & Sons, Inc. Available in EBSCO E-Books
- This book provides a helpful overview of mediation from a practitioner's standpoint, but it is grounded in the academic literature on conflict resolution. Relevant pages: 3-18 and 181-186
5. Hopmann, P. T. (1995). Two paradigms of negotiation: Bargaining and problem-solving. The Annals of the American Academy of Political and Social Science, 542(1), 24-47. Available in: JSTOR Essentials Collection. 
- This is a useful overview of the negotiation literature and places ideas from Getting to Yes in a larger context of negotiation theory. Relevant pages: 31-35 (the concept of relative v. absolute gains) and 39-45 (reasons for choosing one paradigm over another or a combination for a given negotiation scenario).

## Custom HC guides

- [Common Ground](https://docs.google.com/document/d/1m7g5Oez8JeIKG-7MNNdXHX5rMC-EWFq9SBpYZ6dXcGM/edit)

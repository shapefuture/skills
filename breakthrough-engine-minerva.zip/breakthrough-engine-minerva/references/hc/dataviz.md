# #dataviz — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/dataviz/](https://my.minerva.edu/academics/hc-resources/hc-handbook/dataviz/)
> **Foundational Concept** · Cornerstone course: Empirical Analyses · Competency: Thinking Creatively → Facilitating Discovery
> Taught in: Formal Analyses | Empirical Analyses | Semester One · Unit: Probability and Statistics | Scientific Method
> Big Question: What does it mean to be random? How can data help us discover what is true? | How can we mitigate human-caused climate change?

## Definition

**#dataviz** — Interpret, analyze, and create data visualizations.

> **Pitch:** A picture is worth a thousand words. An effective data visualization is worth a million.

Typically, one can understand data best by looking at it from multiple perspectives, which can be facilitated by data visualization techniques—this is because the human brain did not evolve to be able rapidly to scan and make sense of columns of data. Histograms, bar graphs, line graphs, scatter plots, and many other types of graphics can provide insights into how to ask and answer questions about the data. Different types of graphics can shed light on different aspects of the data. For instance, histograms are used to visualize frequency distributions, while line graphs allow one to visualize the change in a variable over time. One must consider properties of the data and the questions of interest when deciding how best to use these tools.

## Worked example

Your marketing firm is working with a company that is trying to increase product sales from existing customers. You have access to a range of data and create a few graphs to highlight potential areas of opportunity. You wonder if there are seasonal trends, so you construct a line graph of monthly sales, which show that sales substantially dip during winter months. A line graph is appropriate because of the temporal relationship the time series data have.

Next, you wonder if particular demographic groups drive sales, so you create a bar graph to compare those groups. A bar graph is appropriate because the demographic group's membership is a categorical variable.

Last, you wonder if income levels may relate to product sales, so you construct a scatter plot with income levels on the x axis and product sales per customer on the y axis. A scatter plot is appropriate because the two variables are continuous variables and you want to evaluate the relationship between them. For each graph, you ensure that you have proper axis labels with units, and a brief but informative caption. The insights the data visualizations provide help guide the marketing strategy.

> **Footnote:** The purpose of visualizations, the information being communicated and the justification of the different types of graphs are assessed to select the most appropriate visualization type for the different purposes. Good practices of data visualizations are recognized and implemented to ensure clarity and fidelity.

## Is it this HC?

If the answer to the following questions is yes, #dataviz could be useful:

- Are you creating a graph to display data?

- Are you plotting a function to analyze its features?

- Are you interpreting or analyzing a data visualization to extract information?

- Are you focusing on the plot’s style, labels, colors, and legends?

- Are you adding data points to a basemap?

- Are you critiquing an existing data visualization?

Depending on the work product, there might be other HCs to consider. Not all visualizations are data visualizations! Check the table below for possibly related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#modeling](modeling.md) | uses a data visualization to evaluate the implications or predictions of a model. uses a non-data visualization (e.g. a causal diagram or illustration) as a “conceptual model” – an abstract representation of a real-world system. |
| [#evidencebased](evidencebased.md) | produces a data visualization to support an argument effectively. uses data visualizations from existing studies, rather than creating one from scratch. |
| [#communicationdesign](communicationdesign.md) | analyzes how specific cognitive processing principles guide good design and how visual elements, such as the choice of color, size or style of font, and position on the page, work together to abide by the cognitive principles. |
| [#variables](variables.md) | examines the types or roles of the variables being visualized. Note that understanding the types and roles of variables is often required to construct an appropriate and effective data visualization. |
| [#multimedia](multimedia.md) | examines how more than one medium, possibly including visualizations, coexist in a work and how the combination of different media affect each other as well as the overall message of the piece. |

## Self-study Q&A (15 questions)

**Q1. What are the essential elements of a graph?**

Answer: 
(Note: You do not necessarily need to have everything listed here! For example, a title is not appropriate in a visualization for a scientific paper. Use these elements only if applicable.)

- Title

- Axis Labels

- Units

- Caption

- Legend (if applicable).

**Q2. What are the types of data visualizations?**

Answer: 
(Note that this list is not exhaustive)

- Line plots

- Scatter plots

- Histograms

- Bar charts

- Contour plots (heat maps)

- Box plots

**Q3. What type of graph is appropriate to show the temporal changes of a continuous variable?**

Answer: A line graph.

**Q4. What type of graph is appropriate to show the frequency of values for quantitative variables?**

Answer: A histogram.

**Q5. What type of graph is appropriate to show the frequency of values for qualitative variables?**

Answer: A bar chart.

**Q6. What type of data is plotted using scatter plots, and what is the purpose of scatter plots?**

Answer: Quantitative bivariate data. It means numerical data on two variables, paired together. Each value on one variable is paired with a value on the other variable. Suppose one variable was X = {x1, x2, x3} and the other was Y = {y1, y2, y3}. The paired data would be (X,Y) = {(x1, y1), (x2, y2), (x3, y3)}. Scatter plots assess trends such as linear correlations or non-linear associations, thus showing the relationship between the variables X and Y.

**Q7. What are the characteristics of good captions?**

Answer: Captions should highlight important trends of the data visualization. They shouldn't repeat content from the main text, or offer new information that cannot be directly inferred from the visualization. Captions are usually not considered as part of the main text, but they should be straightforward and concise; not to be abused for word count purposes.

**Q8. How can you check if your visualization is clear?**

Answer: Imagine that your reader has not looked at the main text. Can they understand what the visualization is about with only the caption? Keep in mind where/how the visualization will be accessed and who the audience is (e.g., Is it printed in black and white? Is it understandable to individuals with color blindness?).

**Q9. Give an example in which knowing the type of variable (qualitative vs quantitative, continuous vs discrete) is essential for choosing how to display the data.**

Answer: Some examples: (1) continuous variables in mathematical functions can be plotted with smooth curves, (2) discrete variables in a dataset may contain overlapping points, so jitter should be added to distinguish the dots on a scatter plot, (3) ordinal variables should not be treated as quantitative, so histograms and scatter plots are not advisable.

**Q10. What separates a model from a data visualization?**

Answer: 
A data visualization describes patterns in a dataset - it requires data. In contrast, a model describes an abstraction of a real-world system, which may be in the form of visuals. For example, one can create an infographic or a causal diagram without any data, making them conceptual models.

However, good visual models require attention to elements of both #modeling and #dataviz. For example, a physicist may model planetary orbits using a system of mathematical functions, which makes it a mathematical model. While the plot is not a data visualization, the general rules of #dataviz apply: axes with appropriate units and labels, a title, and a caption describing the model. 

As an HC, #dataviz includes the fundamentals of visualizations in general. If you believe you spent sufficient effort on the elements of #dataviz, it's okay to tag this HC for models too.

**Q11. Is it okay to draw data visualizations by hand?**

Answer: 
Typically, you would process actual data using computational tools, such as Python or Google Sheets. It is often logistically unrealistic to plot a data visualization by hand with large numbers of data points (imagine plotting 200+ points on a piece of graph paper!). In addition, data visualizations generated by computers are more accurate.

In contrast, if you’re creating a conceptual model using a graphical representation, it is okay to hand-draw the model. Such models are usually seen in qualitative analyses, such as explaining economic dynamics (see figure below). Make sure the visual is clear and professional-looking. 

Like other textual representations, there are discipline-specific norms and strategies in data visualizations, and you should carefully follow guidelines based on specific class applications.

**Q12. Is it appropriate to include a title on top of a visualization?**

Answer: Within scientific contexts, the answer is usually no. It is better to include the title as the first sentence of the caption, which is below the visualization. The reason behind this rule is that captions usually contain all the necessary information, and the addition of titles will consume much space in documents (like academic journals). 

However, depending on the medium and audience, sometimes it’s more appropriate to include a title. For example, a scientist creating a poster or an oral presentation for a research symposium, or a journalist including a data visualization in an article might use titles to make it immediately clear to the audience what is being shown.

**Q13. Why are pie charts generally inefficient?**

Answer: The answer draws from the cognitive communication principles of #communicationdesign: 
- Salience: 

- While exploding a wedge draws attention, exploding more than one wedge disrupts the wedge boundaries so much that these wedges are not salient anymore.

- When exploding a wedge with more than 25% proportion, the explosion does not really draw attention to the separated wedge.

- Limited capacity: When comparing the same corresponding parts from multiple pie charts, the spatial proportions may vary greatly and do not represent the actual proportions.

- Perceptual Organization: If the wedges are not arranged in a simple progression, the brain will struggle to find a general trend. It can be challenging to compare two different wedges by spatial reasoning.
A poor application of #communicationdesign makes it difficult for readers to understand your data visualization’s patterns, which can indirectly lead to a poor application of #dataviz.

**Q14. Are tables a form of data visualization?**

Answer: Tables are technically a form of data visualization, though often it is much better to make a plot. The fundamentals of #dataviz apply: column headings, concise captions, and easy to follow.

**Q15. How do I choose colors and other style elements of a visualization?**

Answer: There is no universally agreed upon color scheme or style, even within a particular discipline. The choice will highly depend on your purpose, the audience, and field-specific conventions. To align with the general purpose to clearly communicate the data, it's best to choose colors, line thicknesses, and marker styles, such that all trends are easily discernable. One common recommendation is to use a color palette that is accessible to individuals with color blindness. This blog post explains accessibility considerations and gives recommendations.

## Guided reflection (proficiency checklist)

1. Have you made your visualization clear and easy to read?
2. Have you chosen an appropriate visualization for the type of data and/or type of variable?
3. Have you made a visualization that is relevant to your purpose, adds value to your work product, and/or supports your overall argument?
4. Have you included the essential elements of a graph?
5. Have you added a figure caption that concisely describes the visualization trends?
6. Have you analyzed or interpreted the data visualization? In particular, did you discuss specific interesting features like overall trends, outliers, skew, heteroscedasticity, and/or symmetry? This may require drawing on the principles of other HCs, like #descriptivestats, #distributions, or #regression.
7. When writing your footnote or annotation, 
- Have you justified the choice of visualization for the given variable(s), purpose, and context in your footnote?

- Have you justified specific choices concerning bin width, data manipulation, color, scale, thickness, etc?
8. Did you include the code and/or raw data in the appendix (if required)?

## Common pitfalls

1. The application tags #dataviz for visualizations that do not involve the principles of this HC (i.e., not all visualizations are data visualizations).
2. The application misses one or more of the essential elements of a graph when required, or has elements that are uninformative or ambiguous.
3. The application does not have complete labels (e.g., no units in an axis label).
4. The application’s caption is either undescriptive or inaccurately describes what can be seen in the visualization.
5. The caption is misused as a main text substitute.
6. The application’s visualization is not appropriate for the type of variable or data.
7. The application’s visualization does not contribute to the overall message of the work.
8. The application’s visualization attempts to present too much information, such that it is hard to follow.
9. The application’s inferences about the visualization extrapolate information (overinterpretation).
10. The application uses axis scales that are inappropriate (too zoomed in or zoomed out). For example, the domain of the independent variable is small, not allowing the reader to see the complete relationship between dependent and independent variables.
11. The application makes design choices that are not optimal for the data. For example, the use of too many bins in a histogram can prevent readers from noticing nuances between a range of values.

## Applying the HC at Minerva

1. This HC is used for all natural sciences courses! When reading academic papers, readers have to decipher trends and patterns from data visualizations. When collecting data for a research study, you would need to visualize data for further discussion, with careful consideration of the elements (e.g., color contrasts).
2. In the computational sciences, being able to create effective graphs is essential to complement any mathematical or computational work. A graphical analysis of a mathematical function is often helpful to analyze its features or indicate solutions to a problem. You may also use graphs to demonstrate the implications of a mathematical model by plotting an analytical or numerical solution. Even if the visualizations do not display empirical data from a dataset, the fundamental principles of #dataviz are still essential to effectively make use of these graphs.

## Applying the HC outside Minerva

1. You can use these skills to evaluate and interpret any visualization that you see in non-academic settings, such as in media sources. For example, when a politician presents a data visualization to build an argument, you can evaluate the visualization to check if the data visualization is misleading (e.g., by using improper axis scaling, not normalizing the data if appropriate, etc).
2. Example: Air Quality Heatmap

Context: This interactive heatmap is taken from IQAir. Users can rotate the globe to see the air quality at different regions. The legend shows the US Air Quality Index (AQI), in which the cooler the color, the better the air quality is. The white lines indicate the atmospheric airflow direction.

This screenshot shows the air quality of North America during the 2023 wildfire season. From this data visualization, we can clearly infer that the air quality in the Northeast region (e.g., New York) is much poorer (higher AQI). Another interesting feature is the dark blue region in the West (e.g., Denver), which deviates from the general trend. This could spur interesting research questions.

## Key resources

1. Minerva Academic Team. (2021). HC Guide for Visuals. https://docs.google.com/document/d/1EHG_5zT2kOF0RTFoC1jMMaCVmi60Q_RG7VfqvGUWYn0/edit
- This guide can help you understand how to effectively apply #dataviz and other visualization-related HCs in your work products.
2. Caprette, D. (1997). Using figures - the basics. Experimental Biosciences Resources. http://www.ruf.rice.edu/~bioslabs/tools/data_analysis/using_figures.html
- This source provides an overview of scientific figure types, including the anatomy of a figure and the associated vocabulary.
3. Caprette, D. (1997). Graphic examples. Experimental Biosciences Resources. http://www.ruf.rice.edu/~bioslabs/tools/data_analysis/graphic_examples.html
- This source provides an overview of common types of scientific figures, including common mistakes and resolutions.
4. Department of Biology, Bates College. (2002). Almost everything you wanted to know about making tables and figures. How to write a paper in scientific style and format. https://web.archive.org/web/20210211023150/http://abacus.bates.edu/~ganderso/biology/resources/writing/HTWtablefigs.html
- This article provides some guidelines for tables and several considerations for figures under different contexts.
5. Egger, A. E., & Carpi, A. (2008). Using graphs and visual data in science. Visionlearning, (1). https://www.visionlearning.com/en/library/Process-of-Science/49/Using-Graphs-and-Visual-Data-in-Science/156
- This source covers various applications of data visualizations across disciplines.
6. keenblog. (2019, July 16). Accessibility Considerations in Data Visualization Design. Keen. https://keen.io/blog/accessibility-in-data-vis/
- This short article addresses ways to create data visualizations for people with visual disabilities (e.g., color blindness).
7. McCandless, D. (2010, July). The beauty of data visualization. [Video]. TED. http://www.ted.com/talks/david_mccandless_the_beauty_of_data_visualization?language=en
- This 18-minute video presents many interesting examples of data visualization by modifying the variables, thus showing the importance of data processing.
8. Vox. (2020, April 28). How coronavirus charts can mislead us [Video]. YouTube. https://www.youtube.com/watch?v=O-3Mlj3MQ_Q
- This 5-minute video uses the pandemic as an example of how data processing influences trend interpretations.


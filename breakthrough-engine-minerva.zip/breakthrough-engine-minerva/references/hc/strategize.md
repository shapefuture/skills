# #strategize — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/strategize/](https://my.minerva.edu/academics/hc-resources/hc-handbook/strategize/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Working with others
> Taught in: Cornerstone Course | Semester Two · Unit: Prudence and Effective Interaction
> Big Question: How should power be used and distributed?

## Definition

**#strategize** — Diagnose the problem at hand and develop a plan to achieve your goals by finding leverage and exploiting relative strengths.

> **Pitch:** Make sure you know where you're going, how you plan to get there, and what you'll do when your plan doesn't work.

Choosing how to act requires strategizing - analyzing the situation at hand and making a plan that would guide future decisions and action. A strategy crucially relies on a diagnosis, a simplification of reality that identifies key leverage points where one can do most with what they have. One aspect of the diagnosis is to appreciate the relative strengths and weaknesses of one’s position relative to that of others. At the heart of the strategy is a guiding policy, a principle capable of guiding action that draws on the diagnosis and formulates a plan with regard to the identified pressure points. Lastly, a strategy includes a set of coherent actions, derived from the guiding policy.

## Worked example

You are running for a local office, and are participating in a candidates’ debate. You know that you are relatively inexperienced in politics, which is your main weakness, and you understand a threat you face is that your opponent will try portraying you as naive due to your little experience. On the other hand, you know that your opponent, who has been an elected official for a while, has many times compromised your party’s positions for the sake of forming coalitions with opponents from the other party. Given this diagnosis, you come up with the idea to present yourself as an ideologically pure outsider candidate, not stained by the corruption of the old system. You prepare and rehearse the argument that your lack of political experience is in fact an advantage, and use your years of experience as a lawyer and community activist to demonstrate your ideological commitment. You also memorize parts of your opponent’s record which show him voting for bills that contradict your party’s ideological commitment and his own professed commitments.

> **Footnote:** You effectively employ SWOT analysis to understand the situation and potential opportunities. From this diagnosis, you further develop a guiding policy to shape your approach, and coherent actions to bring about the desired effect.

## Is it this HC?

Is #strategize the right HC? If the answer to the following questions is yes, #strategize could be useful:

- Are you devising or analyzing a strategy that thinks about how to achieve long-term, large-scale goals?

- Are you using SWOT analysis, counterstrategic thought, means-to-end analysis, or another form of strategic thinking?

- Are you thinking about leveraging circumstances or turning a difficult situation around?

Depending on the work product, there might be other HCs to consider.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#gametheory](gametheory.md) | Models an interaction of decisions/strategies as a game. Game theory is a purely rational version of counterstrategical analysis, using concepts like the prisoner’s dilemma or Nash equilibrium. On the other hand, #strategize might consider factors that are difficult to quantify or explain rationally (like history, culture, and stories). |
| [#purpose](purpose.md) | Formulates and aligns long-term goals with guiding principles and short-term actions. #purpose often informs strategy when you move from why to how. #purpose also focuses on values and vision, whereas #strategize is more directly practical. |
| [#powerdynamics](powerdynamics.md) | Analyzes sources of power and how it is distributed and interacts. SWOT analyses are a type of strategic thinking where looking at the kinds of power you or your opponent has or lacks is beneficial. #strategize is answering 'how to utilize those?' |
| [#negotiate](negotiate.md) | Uses or analyzes strategies of negotiation. Negotiation is usually a minor part of a more extensive strategic operation (tactics), so they apply well together. |
| [#gapanalysis](gapanalysis.md), [#breakitdown](breakitdown.md), [#constraints](constraints.md), [#analogies](analogies.md) | Overcomes some problems by using creative thinking. For example, you might examine how your strategic problem was solved before (#gapanalysis) or in an analogous situation. |
| [#ethicaljudgment](ethicaljudgment.md), [#ethicalcourage](ethicalcourage.md) | Makes and executes ethical judgments. Ethics should be central to a strategy to ensure true success. Applications of #strategize should try to achieve goals while maintaining moral integrity and executing an ethical strategy that addresses material and other costs. |

## Self-study Q&A (4 questions)

**Q1. What does SWOT stand for?**

Strengths - analyzing your own (relative) strengths in achieving your goal

Weaknesses - analyzing your own (relative) weaknesses to attain your goal

Opportunities - analyzing possible options to achieve your goal

Threats - analyzing potential threats to achieving your goal

**Q2. What is the end of a means-end approach to strategy?**

Setting a large, ambitious goal. It should be hard to obtain for the entire organization long-term. You then decide your strategy (your means) based on this goal.

**Q3. What is the difference between the above and counterstrategic approaches? And when is counterstrategy important?**

A counterstrategic approach sees strategy as a reaction to the opponent's strategy, which depends on interaction. It is important when 

1) You have a clear opponent and 

2) Your opponent is significantly stronger! In this case, making their strategy fail is better than focusing purely on their goals.

With a strategy like this, an essential component of #strategize is understanding the opponent's motivations/goals/strategy, which is what the famous quote "Know your enemy" from Sun Tzu refers to. This also shows a clear link with #gametheory, in which the same lens of analysis is used. Sun Tzu wrote about war, where counterstrategy means appropriate timing, surprise, deception, and clever maneuvers. What might it mean in a different context?

Read the whitepaper from the key resources for more insight on counterstrategy. It gives the background for the counter-strategic approach described by Sun Tzu in the famous strategy book 'Art of War'.

**Q4. When applying strategies, the end often justifies the means. But you might have ethical reasons to avoid some strategies, even if they would be efficient. How can you incorporate a strategic view that rules out specific means?**

Using ethics HCs/normative reasoning to constrain particular actions. 
If you plan on achieving a goal and are comparing approaches, you could set ethical standards for the desired means. Having (ethical) constraints on strategy is quite common in, for example, war, where certain weapons or methods are forbidden, frowned upon, or sanctioned. You can apply #ethicalconsiderations and #ethicaljudgment to argue which strategic approach respects important values or is most ethical, and you can use #ethicalcourage to address potential strategic drawbacks of acting ethically. Acting ethically can become a strategic goal in and of itself, for example, because an image of moral integrity will increase the likelihood of other actors siding with you.

## Guided reflection (proficiency checklist)

1. Have you identified a realistic and large-scale/long-term goal, and have you provided justification to back up your selection of a goal?
2. Have you explained why a particular strategic framing is helpful to achieve your goal?
3. Have you considered your Strengths, Weaknesses, Opportunities, and Threats (SWOT)?
4. Have you compared and weighed strategic alternatives?
5. Have you gone all the way from identifying your goal to identifying what specific actions you should take?
6. If there are other actors involved, have you analyzed what their strategy is or what their response to your strategy might be (counter-strategic thinking)?
7. Have you explained and justified what is expected to be lost or gained from a strategy?

## Common pitfalls

1. Only analyzing a strategic position without explaining what to do.
2. Seeing SWOT and other strategic analyses in isolation of other actors’ positions/goals.
3. Not addressing possible significant effects or interactions of your strategy.
4. Failing to account for the potential difficulty of costs of a suggested strategy.
5. Offering superficial explanations of why you think a goal is realistic or appropriate to the problem without providing evidence.

## Applying the HC at Minerva

1. Business: Depending on the context, you will find various aspects of #strategize helpful in evaluating companies in your coursework or suggesting different approaches. It is vital to understand the business context. If there are opposing partners or competitors, it is essential to identify their relative position and work towards understanding their strategy. If you specify one weakness or threat, it is vital to identify creative solutions that leverage that position in another way or make that weakness a strength. When analyzing or suggesting a means-to-end strategy, it is important to know the costs associated with the means and how that relates to ethics, your resources, and the principles behind the company’s long-term goals. Finally, you might find some LOs overlapping with the HC #strategize. Inform professors if you are unsure which LO/HC to apply and tag or how to do so effectively.
2. History: Analyzing the strategies of different historical parties will help you understand why things happened the way they did. To fully grasp a strategy, it is important to have a contextual understanding of the position of an actor. Why was a particular characteristic a strength in the time and place that the strategy was devised? What external pressures drove them to think in a certain way? What did they stand to gain or lose? How did it all feed into a larger overarching goal? Be sure to distinguish between tactics (usually what you look at when thinking about specific events, such as the destruction of a city in a war) vs. the overall strategy that tactic was part of. Additionally, use an example from history to point out specific strategies. Imagine you want to create an understanding of why genocide happens in various contexts; Historical analysis could help you understand this “strategy” and how it is conducted.
3. Political Science: Applying #strategize in a political context will often look like #powerdynamics. #strategize uses specific strategic tools to lay out a strategy step-by-step, examining and using the relative power of a political actor. Similar things apply to political science as they do to history. When developing strategies in a contemporary context, it is helpful to understand the historical context that brought it forth. It is also essential to carefully map the strategic landscape, including which actors or contextual factors are relevant to your analysis. Since politics involves a complex combination of actors and factors at various levels that can be viewed through different lenses, it might be helpful to think about complex systems HCs (like #systemmapping) in conjunction.

## Applying the HC outside Minerva

1. Playing (Board/Video) Games: Nothing is as safe a playground to practice your strategic thinking as a game you play with others. It requires an exact understanding of the rules and what avenues of action they grant you, as well as a constant evaluation of your relative position to others (usually, games will make sure that the playing field is pretty equal!). Depending on the game, you will use various strategies, from verbal/persuasive techniques needed to convince others of actions that benefit you to planning skills and long-term thinking.
2. As an Activist: If you are trying to accomplish some political goal or create awareness as an activist, having a solid understanding of #strategize is useful. You might resort to disruptive tactics of various sorts, in which you have to evaluate how those might accomplish some goals. Suppose you intend to influence an institution or combat a political decision. In that case, you might target that in your actions and understand which actor you are against and their goals. But your action is often part of a larger movement with longer-term goals or a vision. Establishing such a vision can also help a movement act coherently, especially when your movement has more of an emergent strategy than a top-down strategy.

## Key resources

1. Kenney, N. (2022). Thinking Strategically. Minerva Guide. https://docs.google.com/document/d/1bQ74TpYcnzl9YMBY3j3b6j8ZHXtZC9FEvLs6EQ0wAxo/edit
- This is the principal guide to #strategize, and it will improve your understanding of what to consider when coming up with a goal and strategy, as well as the different types of strategic thinking that you could apply. Each section explains the various dilemmas of strategic approaches.
2. Gomer, J., & Hille, J. (2012). An Essential Guide to SWOT Analysis. http://mci.ei.columbia.edu/files/2012/12/An-Essential-Guide-to-SWOT-Analysis.pdf
- This is a very comprehensive guide to SWOT analysis, which gives clear definitions. It walks you through the steps to undertake (chronologically) when doing a SWOT. At the same time, it makes you think about which order is best for your purpose. It also includes examples of which actors might find SWOT helpful.
3. Rumelt, R. P. (2011). Good strategy/bad strategy: The difference and why it matters. New York.  http://dspace.vnbrims.org:13000/jspui/bitstream/123456789/4584/1/Good%20Strategy_Bad%20Strategy.pdf
- Especially important are Chapter 5, "The Kernel of Good Strategy," and Chapter 6, "Using Leverage." Focus on the three steps of strategic thinking (1 - diagnosis, 2 - guiding policies, 3 - coherent actions). There is a lot of overlap with thinking about #purpose in this resource, but note that purpose also has an element of values and mission very central. In contrast, those considerations are less prominent in a strategy that focuses on solving for a goal and position

## Custom HC guides

- [Thinking Strategically](https://docs.google.com/document/d/1bQ74TpYcnzl9YMBY3j3b6j8ZHXtZC9FEvLs6EQ0wAxo/edit)

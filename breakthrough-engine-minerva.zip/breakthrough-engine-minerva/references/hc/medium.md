# #medium — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/medium/](https://my.minerva.edu/academics/hc-resources/hc-handbook/medium/)
> **Foundational Concept** · Cornerstone course: Multimodal Communications · Competency: Communicating Effectively → Using nonverbal communication
> Taught in: Multimodal Communication | Semester Two · Unit: Interpretation
> Big Question: How do we interpret artistic communication?

## Definition

**#medium** — Describe, analyze, and utilize distinctive characteristics of communicative and expressive mediums at the level of form and structure.

> **Pitch:** The medium of a work is the foundation upon which its message is built.

When analyzing or crafting a creative work, one must pay close attention to its structure and the use of medium-specific tools in order to create a compelling work or to interpret what the author is trying to communicate. Linguistic mediums, such as poetry or nonfiction, utilize different characteristics of language to meet their expressive goals. Other mediums, including music and visual art, communicate in ways that are fundamentally different from linguistic communication. Some such works are abstract, and others use recognizable symbols or familiar images to represent something deeper for the audience. Additionally, because a medium may encompass a number of different genres, authors may apply different genre-specific techniques and characteristics to make the work more vivid and memorable. To draw inferences about a particular medium, one needs to understand the relevant norms of expression and acquire the vocabulary to describe, analyze, and organize them.

## Worked example

The announcer in a political ad warns of dire consequences if his candidate’s opponent is elected. He tells us that this evil person would make the world a more dangerous place. In the background, starting softly at first and then swelling to a crescendo is music in a minor key, which is generally known to reflect a more negative mood as opposed to major keys. The minor notes come to dominate, and are reinforced with a low droning cello, with a low pitch that brings the music’s mood even lower. The music becomes dissonant and by the end of the ad you are slightly on edge. You realize the music’s key combines with its instrumentation and dissonant harmony to evoke a sense of discomfort in you and make it more likely that you will dislike the candidate being spoken of, achieving its purpose.

> **Footnote:** The music’s distinctive features allow it to communicate emotional undertones to the audience through the use of nonverbal communication, transmitting the message that the candidate is not trustworthy due to the discomfort evoked in the audience.

## Is it this HC?

Is #medium the right HC? If the answer to the following questions is yes, #medium could be useful:

- Are you analyzing how a work’s medium impacts its message?

- Are you comparing two works with a similar message but with different mediums?

- Are you paying close attention to the elements and conventions associated with the medium you are working with?

- Are you intentionally incorporating a certain medium and paying attention to medium elements to elevate your work product?

- Are you attempting to communicate a message that would be hard to convey using a different medium?

Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#multimedia](multimedia.md) | analyzes how multiple mediums work together or conflict with each other to create a work of multimedia, with a result that is different from the sum of the contributions of each individual medium. |
| [#persuasion](persuasion.md) | discusses the design and execution of an argument. considers different theories and effects at play, like the assimilation effect from social judgment theory. |
| [#context](context.md) | situates a work in its appropriate context for analysis or argumentation. |
| [#communicationdesign](communicationdesign.md) | uses principles of communication design to connect with the intended audience. |

## Self-study Q&A (5 questions)

**Q1. What are the main elements of medium in a painting?**

Scale, composition, pictorial space, texture, pattern, line, form, light, and color. These elements will guide your formal analysis of a painting, allowing you to break down what you see.

**Q2. What are the main elements of medium in music?**

Harmony, melody, rhythm, tempo, meter, dynamics, form, timber, texture, and instrumentation. These elements will help guide your analysis of a piece of music by giving you the tools to dissect what you hear.

**Q3. What are the main elements of medium in poetry?**

Rhythm, the sound and patterns of words, strongly coordinated or contradicting connotations, repetition of words and phrases, figural language (metaphors, similes, images, symbols), rhyme, organizational or structural features (line length, line capitalization etc). All of these elements give you the power to analyze the choices a poet made or create your poetry in a deliberate manner.

**Q4. What is the difference between analyzing the #context and the #medium of an artistic piece?**

These two HCs often complement each other in art analysis, however they have quite different focuses. Applications of #context focus on the art’s historical background, the artist’s life and values, and other qualities of the piece that situate it in a certain period of time, but that often can not be seen just by looking at the work. On the other hand, #medium relies heavily on what can be experienced as a member of the audience. Applications of #medium focus on the artistic elements that actually make up a piece and how those elements create a message or feeling within the piece.

**Q5. What are the main elements and techniques of medium in creative non-fiction?**

- Vivid Openings: Engage readers with vivid descriptions and sensory details. 

- Truthful Narrative: Combine factual reporting with storytelling techniques. 

- Dramatic Method: Use scenes to show events, enhancing engagement. 

- Scene Writing: Build the narrative with engaging and vivid scenes. 

- Realistic Details: Employ specific, concrete details to evoke images and emotions. 

- Show, Don't Tell: Reveal traits and emotions through actions and details. 

- Active Voice: Use active voice and specific verbs for dynamism. 

- Captured Conversation: Incorporate actual dialogues for authenticity. 

- Style Elements: Consider the impact of diction, syntax, and tone. 

- Metaphor and Simile: Enrich the narrative with figurative language. 

- Strong Closings: Conclude with a memorable and fitting ending.

## Guided reflection (proficiency checklist)

1. Is the application creating or critiquing a work that employs a certain medium?
2. Does the application utilize a medium to create a holistic deeper meaning?
3. Is the choice and use of a medium described and explained clearly?
4. Has the application described the medium elements before analyzing them?
5. Does the application mention how a different medium would affect the work’s message?
6. Do you analyze a piece of work using medium specific terms?

## Common pitfalls

1. The application lays claim to one medium when a different medium was utilized.
2. The application utilizes medium, but does not explain how the medium adds value to their message.
3. The application analyzes the medium without first describing the medium, making the application shallow and susceptible to anchoring bias.
4. The application describes a work’s medium, but does not use medium-specific terms to create deep analysis.

## Applying the HC at Minerva

1. In psychology, you can use #medium to help you understand and even develop music therapy. Music moves people: some music leads to greater feelings of relaxation while other pieces can increase brain activity. By analyzing which musical elements lead to which psychological responses, you can apply medium to this field of work.
2. In business, #medium can be used to refine how you pitch ideas to possible investors. Sometimes such pitches will take the form of a speech, but in a competitive field, setting yourself apart can be advantageous. Utilizing #medium is a way to present your idea in a unique way, by making a graphic that uses compositional techniques to send your message.

## Applying the HC outside Minerva

1. Fashion is a medium too. Expressing yourself through clothing has a lot to do with #medium. What colors, fabric, and genre pieces you wear can send a strong message. Utilize #medium in the way you dress and present yourself to others. Fashion is an artform!
2. This HC is important for educators in connection with the #scienceoflearning. Different mediums are used in education to achieve different purposes. Textbooks offer structured, detailed information and are often used for self-study and reference. Lectures provide a direct way of delivering content through verbal communication and visual aids. Multimedia presentations can incorporate videos, animations, and interactive elements. A combination of these media and others can be used to enhance learning.

## Key resources

1. Minerva Academic Team. (2021). HC Guide for Visuals. https://my.minerva.edu/academics/hc-resources/additional-resources/
- Check this out as an additional resource for successful application of #medium and other HCs related to visual communication.
2. Harris, Dr. B., & Zucker, Dr. S. (2017, September 18). How to do visual (formal) analysis. Smarthistory. https://smarthistory.org/visual-analysis/
- This resource dives into the elements of visual art analysis.
3. University of New Mexico. (2022). Elements of fiction - University of New Mexico. Elements of Fiction. https://www.unm.edu/~hookster/Elements%20of%20Fiction.pdf
- This resource explains the medium elements of fiction.
4. Morris. (2020, September 2). Elements of music. YouTube. https://www.youtube.com/watch?v=t9Mo-bkl4ko
- This fun video clearly explains the elements of music.

## Custom HC guides

- [A #Medium Analysis with Prof Lawry](https://www.youtube.com/watch?v=NWPiXSlxWS0)

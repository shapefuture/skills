# #modeling — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/modeling/](https://my.minerva.edu/academics/hc-resources/hc-handbook/modeling/)
> **Foundational Concept** · Cornerstone course: Empirical Analyses · Competency: Thinking Creatively → Facilitating discovery
> Taught in: Empirical Analyses | Semester One · Unit: Scientific Method
> Big Question: How can we mitigate human-caused climate change? | How can we understand global pandemics?

## Definition

**#modeling** — Recognize how models can be used to describe a system, explain a set of data, and generate predictions.

> **Pitch:** Unlocking the secrets of the world using simplified representations.

Models are simplified representations of reality. These representations can take many forms, including conceptual models, physical models, mathematical models, and more. Models have crucial applications in science, allowing us to understand systems, explain data, and generate predictions. The development of a model is guided by theory and observation to know which components are relevant to characterize the system’s essential behavior. However, simplifying assumptions are needed to ensure the analysis is feasible and focused on the modeling objective. Simulations are employed to derive predictions from the model, often by varying the nature of the inputs to a model and observing its response. Computational simulations are especially useful when a mathematical model's implications cannot easily be derived analytically, but such computational implementations usually require further simplifications and adaptations to the model, before simulations can be performed.

## Worked example

You are a student extremely curious about astrophysics. You love looking at the night sky and trying to find planets through a telescope, but you wonder where the optimal place to point your telescope would be such that you can see Jupiter in the sky. You decide to build a computer model of the solar system to help you make a prediction of where Jupiter will appear. You enumerate the bodies that will compose your system, namely the planets and the Sun, and you incorporate the astrophysical laws that guide their movement, like Kepler’s Laws. Considering relevant variables and parameters of each of your agents, like their mass, distance from the sun, and speed, you create a robust system that accounts for the gravitational interactions between planets and the sun. You set your model to represent the current time of the year and consequently the current disposition of planets, which in turn helps you identify where Jupiter will be. You cross-reference that information with what you know about your current location on the Earth to infer where Jupiter will appear in the sky. Being computer-based, your model is capable of simulating how the passage of time will affect the orbits of planets in the solar system. Thus, you can now use it to predict the trajectory of any planet.

> **Footnote:** Based on the need to predict Jupiter’s location on the night sky, a model is incorporated based on known astrophysical laws and properties of planets (and the sun) within the solar system. The model is implemented in a computer simulation, which allows one to manipulate variables like the time of the year to obtain the required information: Jupiter’s position.

## Is it this HC?

If the answer to the following questions is yes, #modeling could be useful:

- Are you using a model to understand a real-world phenomenon?

- Does your work rely on a simplified representation of reality?

- Are you considering the assumptions, simplifications, or limitations of a model?

- Are you analyzing the implications, predictions, or other uses of a model?

- Are you proposing new ways to improve an existing model?

Depending on the work product, there might be other HCs to consider. Check the table below for possibly related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#dataviz](dataviz.md) | Generates data visualizations to show trends, which may either be empirical (observed) data or simulated (model-generated) data. |
| [#plausibility](plausibility.md) | Discusses the plausibility of assumptions in a model, using evidence from other studies or existing data. |
| [#interventionalstudy](interventionalstudy.md), [#observationalstudy](observationalstudy.md) | Designs a study that may or may not include a treatment. Models are often used to explain the data trends observed in a study. Changing parameters/variables in a model is NOT an intervention (e.g., changing the testing rate in an HIV model). |
| [#evidencebased](evidencebased.md) | Uses evidence to support model assumptions (see #plausibility). Uses simulation results as a form of evidence to infer about real-world systems. |
| [#algorithms](algorithms.md) | Uses algorithmic thinking to solve a problem, which in the context of modeling, can include creating computational models, using algorithms to run simulations of a model to derive its implications and predictions, and using machine learning algorithms to construct classification or regression models. |
| [#variables](variables.md) | Identifies and examines the types or roles of the variables being studied, which is critical when building or interpreting a model. |
| [#complexcausality](complexcausality.md), [#networks](networks.md), [#systemdynamics](systemdynamics.md) | Creates a causal/network/phase space diagram, which may be a conceptual model. |
| [#decisiontrees](decisiontrees.md), [#utility](utility.md), [#gametheory](gametheory.md) | Analyzes a decision or set of decisions by considering the context of the scenario and the preferences and personalities of agents. This often involves using descriptive or normative models of human behavior, as well as conceptual or mathematical models to represent the decision-making scenario. |
| [#regression](regression.md) | Creates a regression model that best fits empirical data (plots), which is a mathematical model. |

## Self-study Q&A (10 questions)

**Q1. What is a model?**

A model is a simplified representation of a system in the real world. It is used to analyze, understand, and/or predict a behavior of a natural system.

**Q2. What are the main types of models?**

- Physical model

- Uses physical replicas that reassemble the physical characteristics of the modeled system, usually at a reduced scale.

- Ex: A room-sized river model to understand the fluid dynamics of an actual river

- Conceptual model

- Uses abstract models to explain some basic properties of a natural system

- Ex: The “solar system” atomic model to explain the basic properties of subatomic particles and molecular interactions

- Computational model

- Uses mathematical equations/ algorithms to explain a natural system

- Ex: The heredity model, which is a regression model that predicts how likely a trait of an offspring is genetically inherited from its parents.

- Agent-based model

- Simplifies a complex system by setting simple rules on individual agents to study their interactions

- Ex: The Netlogo virus model, which attempts to simulate how the HIV virus spreads via human contact under different conditions

**Q3. What are the general aspects of modeling?**

- Define a system (draw the boundaries of the model)

- Determine the key variables and their relationships

- Make assumptions to simplify models and reduce the number of variables

- Run model tests

- Revise the model iteratively

**Q4. At what stage in the research process are models useful?**

- Models can be used during the exploratory phase to generate hypotheses. For example, molecular biologists use computational models to understand the interactions between drug molecules and target proteins, which may prompt a hypothesis to explain a cellular behavior.

- Models can also test predictions generated from a hypothesis. For example, to explore the hypothesis that mantle temperature determines lava composition, models can be used to generate hypothetical lava compositions across a range of mantle temperatures. Those hypothetical compositions can then be compared to the compositions of “natural” lavas; if they agree, it lends support to the hypothesis.

**Q5. How can we determine the validity of a model?**

The validity of a model rests on how well its predictions match empirical observations. Sometimes it’s possible to use empirical data from past events. For example, in 1991 Mt. Pinatubo exploded and released sulfuric acid, carbon dioxide, and volcanic ash, which led to a global cooling event. This then became a “test problem” for the General Circulation Models (GCMs) on climate (Egger & Carpi, 2008). Modern climate models (GCMs) have been able to recreate the temperature effects observed during the Mt. Pinatubo eruption, suggesting that the models are valid.  Note that General Circulation Models (GCMs) are mathematical models.
Similarly, we can iteratively use present observations and compare it with a model’s predictions. For example, we can measure the temperature of a particular region every day, then compare it to the predictions of weather models. Based on the number of times a model has predicted outcomes accurately (and the number of inaccurate predictions), we can calculate the accuracy of the model, hence the validity.

**Q6. How can we select key variables in a model?**

Depending on the research question, there are multiple ways to select key variables. For example, suppose we’re interested in the large-scale physical structure of a river and how it changes with key variables like water flow rate or sinuosity. In this case, we would likely choose to ignore aquatic animals (e.g., burrowing clams) that have little effect on these large-scale changes. In contrast, if we’re interested in modeling the aquatic ecosystem dynamics, we may prioritize biological variables over physical variables (e.g., river depth). Selecting key variables requires knowing how to eliminate variables to simplify the model.

**Q7. What are the limitations/challenges of models?**

- Models may not be able to give exact predictions. For example, during a pandemic, the disease spread models cannot exactly predict the number of cases in a given region on a given day, due to the complexity of human interactions. Nonetheless, we may be able to re-run a simulation multiple times to output a range of possible values that would be expected to  include the actual number of cases observed with some reliability. 

- All models are limited by the availability of data from the real system. A model that can be “trained” on a more robust data set is likely to be more accurate. Not all variables can be observed and measured. If we have limited observed data, it’s challenging to convincingly verify a model's validity; the model’s practical usefulness may thus be restricted.

- Models and simulations require simplifications and assumptions, and thus, cannot capture all complexities of the real-world. The assumptions need to be carefully thought out to ensure the model still has uses, even if it’s only in simplified scenarios. 

- Models usually have a limited domain of validity within which they can be expected to provide reliable predictions. For example, the Newtonian model of gravity works well near the Earth’s surface and for some applications within the solar system, but breaks down on large scales. 

- Modeling can pose ethical concerns. For example, using rabbits as physical models for skincare tests is considered unethical and illegal in certain countries.

**Q8. What is the difference between a simulation and a model?**

A model consists of “rules” that govern a system (e.g., differential equations, agent-based rules, physical components). A simulation is the process of running a model to derive its implications and examine its predictions, often involving a mathematical or computational process. Hence, when we refer to a simulation, we only talk about a specific trial from a model. We would “build a model” and then “run a simulation.” In some contexts (e.g., differential equations), it also makes sense to say that we use simulations to “solve” the model or derive “solutions” to the model.

**Q9. Why do we need to make simplifying assumptions for models and simulations?**

Our goal is to understand real physical systems, but it's impossible to take ALL of the complexities of the real world into account. Further, we are typically guided by a specific and well-defined modeling goal, which allows us to focus only on the aspects that are relevant to our purpose, and thus we don't need to take all real-world complexities into consideration. So not only would it be impossible, it would be unhelpful and distracting. Ideally, whatever simplifications we make, the model or simulation should still be enough to characterize the essential behavior.

**Q10. There are so many HCs related to #modeling! What exactly is this HC about?**

#modeling is mainly about understanding the real world using simplified representations and abstractions. This HC connects with so many other HCs because there are so many types of models! There are models of human behavior, physical systems, and everything in between. Keeping the principles of this HC in mind can help you elevate other HC applications. For example, if we want to understand the relationship between the number of hours of sleep per day and the course outcome score of Empirical Analyses, one of the many ways is to collect data from students and create a regression model. The principles of #regression help us understand the specifics of the regression model, such as the mathematical foundations for its construction, understanding the slope and intercept values, and checking for linearity and homoscedascity. The principles of #modeling help us view the regression equation as a model, facilitating considerations of the assumptions used to simplify the regression model, its usefulness in making predictions on future classes, and its limitations.

## Guided reflection (proficiency checklist)

1. Have you considered the various types of models, selected one appropriate for the explanatory challenge, and justified the selection?
2. Have you clearly defined the aspects of the model you are using?
3. Have you used the model to generate predictions of a real-world phenomenon?
4. Have you identified and justified the assumptions of the model, noting potential impacts or limitations on the analysis?
5. Have you justified the selection of key variables to be used (or which variables to be neglected) in the model?
6. Have you justified simplifications made when constructing the model?
7. Have you discussed the validity/usefulness/accuracy of the model (how well it represents the real world) for the purpose of your study?
8. Have you considered and explained ways to improve a model?

## Common pitfalls

1. The application creates a model but does not relate it to a real-world scenario.
2. The application does not discuss the assumptions of a model. A model is always a simplification of the real world; hence assumptions are always necessary.
3. The application considers many variables without any justification for selecting key variables.
4. The application uses a model that’s overcomplicated, attempting to account for too many real-world factors but muddling the essential characteristics of the system under study.
5. The application uses a model with an obvious design flaw (e.g., attempts to build a physical model to study planetary formation when the computational model is a more cost-efficient choice).
6. The core definition of a model is overlooked, neglecting to identify how exactly the application serves as a simplified representation of reality.

## Applying the HC at Minerva

1. Discounted cash flow (DCF) is a valuation method in finance that estimates the value of an investment using its expected future cash flows (how much money the investment will generate in the future. It simplifies the complex real world by quantifying variables such as company assets and the time value of money. Organizations then use the DCF model in decision making, most notably when they decide to make an investment or not. One must recognize that this model is built on simplified assumptions, such as choosing a discount rate between different metrics (e.g. risk free interest rates, WACC, internal rate of return), depending on the objective of modeling and its implications, thus limiting its usefulness in estimating a company’s intrinsic values. Nonetheless, it’s still useful to estimate essential components for investment valuation, such as the investment growth rate, as it provides multiple proxies that can be used across different circumstances.
2. In Empirical Analyses and Formal Analyses, we considered various types of models to simulate pandemics. For example, the SIR model (susceptible, infected, removed) is a mathematical model defined by a system of differential equations, which captures the dynamics of a pandemic over time at the population level. In contrast, agent-based models, such as the HIV model from Netlogo, use simple rules that apply on individual agents, and allows us to observe the emergent properties over time. It allows us to easily factor in contextual information in complex systems (e.g, infection testing rate). It’s important to understand that, while these models serve to represent the same physical system, they involve slightly different variables and parameters, different assumptions, rely on different methods to simulate (run) the model, and may lead to different predictions. Generally speaking, which model is “better” depends on the purposes of the models, the research questions that are being asked, and the constraints under which they operate. For instance, here, it might come down to whether the modeler is interested in asking questions about the individual behavior or group behavior.
3. Conceptual models are used to understand natural systems. For example, in NS courses, models are extensively used to explore dynamics in complex systems. Chemistry (and biochemistry), for example, rely on many models to predict how molecules might interact. In Earth Science courses, many conceptual models can be deepened into mathematical models when calculating fluxes of carbon from different reservoirs, for example. Physics uses all sorts of models to learn about the physical world around us. In particular, in mechanics, free body diagrams, which serve as conceptual models, are essential to depict all forces acting on a system of interest. The system needs to be simplifed (often represented as a point or box in the diagram) and only forces that act external to the system of interest are included in the diagram. Even though the diagram ignores many complexities of the real-world system, by following appropriate conventions and understanding the simplifying assumptions, free body diagrams are invaluable in characterizing the motion of a system. Ecology uses networks to understand the interactions among biotic and abiotic components in an ecosystem, thus generating predictions about population dynamics.

## Applying the HC outside Minerva

1. Simulation games are extremely powerful as computational models, which can in turn inform predictions about the real world. For example, Trinh played SimCity as a junior high student, which inspired him to pursue a career in urban planning (Roy, 2019). Indeed, SimCity is a simplified represenation of a real city – a model! Designing a metro system in SimCity helped him to understand the dynamics of public transportation, which helped him to make decisions as a senior transportation planner for Caltrans in Los Angeles.
2. Before embarking on a big home improvement renovation, computer models can be highly valuable! This way, you can visualize the outcome and test out different designs without spending too much time or money. Using computer software to create a model for this purpose will require some simplications, but if done with sufficient accuracy, can help you identify how much material to purchase, what color to use, and other important design choices.

## Key resources

1. Egger, A., & Carpi, A. (2008). Modeling in scientific research. In Visionlearning. http://www.visionlearning.com/en/library/Process-of-Science/49/Modeling-in-Scientific-Research/153/reading
- This article is a great introduction to #modeling. It outlines the general types of models and offers a few examples about the history of models (e.g., the atomic model).
2. Flora, T., Koloskov, N., & Terrana, A. (2022, Aug 15). Variables. Minerva University. https://my.minerva.edu/academics/hc-resources/cornerstone-custom-hc-guides/
- This whitepaper introduces the various types of variables, which may be relevant when selecting variables for a model. In addition, there is a section that discusses the differences between variables and parameters.


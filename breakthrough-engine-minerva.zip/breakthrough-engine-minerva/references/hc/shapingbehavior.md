# #shapingbehavior — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/shapingbehavior/](https://my.minerva.edu/academics/hc-resources/hc-handbook/shapingbehavior/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Interacting with Complex Systems
> Taught in: Complex Systems | Semester Two · Unit: Prudence and effective interaction
> Big Question: How should power be used and distributed?

## Definition

**#shapingbehavior** — Analyze how incentives, disincentives, and choice architecture influence the behavior of agents in a complex system and utilize them to interact effectively in social systems.

> **Pitch:** Humans are pretty darn complex, but you can somewhat predictably influence them!

Incentives, disincentives, rewards, punishments, and choice architecture are tools for shaping behavior. We divide the tools for shaping behaviors into three categories, each with distinct strengths and weaknesses: (dis)incentives, reward/punishment, and choice architecture. 

Incentives and disincentives change agents’ behavior by altering the expected utility payoff of the choices they face. Thus, incentives and disincentives rely on the model of rational agents who aim to maximize their expected utility and operate as promises (of reward) and threats (of punishment), aiming to encourage or discourage a behavior before it takes place. (Dis)incentives are successful if they motivate agents to engage or avoid certain behaviors. 

In contrast, rewards and punishments are administered after an action. Rewards and punishments aim to teach agents what behaviors lead to better and worse results, and they are successful when agents are more likely to engage in the rewarded behavior and less likely to engage in a punished one. 

Choice architecture influences behavior by manipulating the way options are presented. It uses psychological influence that ‘nudges’ humans separately from their utility calculations without altering the available choices. Choice architecture has a measurable and reliable impact with a large enough sample size. Choice architecture works by affecting agents’ choices in ways that they are not typically aware of, and therefore it raises ethical concerns.

## Worked example

You work for a city government and are tasked with reducing cigarette smoking in the city. You decide you have three realistic #shapingbehavior options to alter smoking behavior. You could increase the city tax on cigarettes $1 which reduces the utility of purchasing cigarettes by forcing smokers to forego the utility they could gain by spending the dollar they lose to tax (a disincentive). Alternatively, you could run an informational ad campaign that educates the public on the dangers of secondhand smoke. You hope the campaign would result in smokers facing social pressure not to smoke after they light up and that the social pressure will slowly condition smokers to change their preference for smoking over time (a social punishment that discourages the behavior). And finally, you consider passing a law that forbids cigarette vendors from displaying cigarette packs behind registers. Note that this law does not limit the ability of customers to purchase cigarettes, but makes the presence of cigarettes less salient when customers are making a purchasing decision (choice architecture). Weighing the costs and benefits of each approach, and considering the constraint that you can only choose one, you decide the tax is the best choice.

> **Footnote:** Three separate approaches that would plausibly alter behavior in the desired way are presented and the underlying mechanisms that explain how each approach might shape behavior are explained. After considering the context (and hopefully a review of relevant literature!) the most effective approach is chosen.

## Is it this HC?

Is #shapingbehavior the right HC? If the answer to the following questions is yes, #shapingbehavior could be useful:

- Are you employing or analyzing tools– such as punishments, reinforcements, (dis)incentives, or choice architecture – to influence some agent’s decision?

- Are you explaining why a certain tool might or might not be effective, considering who is making the decision and in what context?

- Are you defining and explaining the nature of a tool for behavioral change?

Depending on the work product, there might be other HCs to consider. ….

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#utility](utility.md) | Analyzes people’s preferences are formed or can be used to describe someone’s behavior. #shapingbehavior can modify the utility of different options, and nudges can change how someone views their own utility function. |
| [#persuasion](persuasion.md) | If you are trying to change someone’s behavior by altering their beliefs or perceptions, you are probably applying #persuasion. If you are affecting their behavior through external factors (like incentives) without changing their beliefs, you are probably applying #shapingbehavior. |
| [#fallacies](fallacies.md), [#biasidentification](biasidentification.md), [#biasmitigation](biasmitigation.md) | Analyzes how biases or fallacies affect decision-making. Common fallacies or biases can be activated or suppressed to shape people’s behavior. When focusing on the details of a bias or fallacy, you should consider applying those HCs, but if your work stays focused on the decision-making context and purpose, you might just apply #shapingbehavior. |
| [#gametheory](gametheory.md) | Analyzes how agents might operate when their decisions affect each other’s expected outcome. Their actions can be seen as interacting (dis)incentives. An intervention in a game can also be an element of #shapingbehavior. |

## Self-study Q&A (4 questions)

**Q1. What sets choice architecture apart from other methods of influencing someone?**

Choice architecture does not change the utility of that action, but instead frames the decision in a way that still (dis)encourages a behavior.

**Q2. What is the difference between punishment, negative reinforcement, and a disincentive?**

A punishment is a repercussion after an action to discourage someone from repeating that action. (For example, a sanction on a country after they break a treaty or go to war).

A negative reinforcement is removed when someone starts acting in a certain way, to encourage the repeating of that behavior. (For example, reducing the workload on students when they get higher grades to encourage planning and studying by oneself).

A disincentive is posed before an undesirable behavior, to reduce the appeal of that behavior. (For example, a national law that states a maximum amount of pollution on a certain metric that disincentivizes local governments to allow a new factory to be built if that would cause exceeding pollution, because there might be legal consequences for them).

**Q3. You want to encourage your kid to eat more vegetables, so you tell them clearly that they won’t get dessert if they don’t eat their vegetables. Still, your kid does not eat their vegetables, what might be causing your disincentive (and punishment) not to work?**

- The disincentive is not large enough: for your kid, the benefit of the dessert does not outweigh the discomfort of the vegetables

- Even though your kid would (seem to) gain from eating veggies and getting their dessert, they might feel a large discomfort in giving in to your requests, they want to decide for themselves. Maybe a disincentive is not the right way to go about it. An option is to not mention a disincentive and just reward them with something like watching a favorite cartoon after they eat their veggies.

**Q4. Put the example of a nudge with the right term from the nudge toolkit from this table of examples.**

View the file of the sorted table of examples here.

## Guided reflection (proficiency checklist)

1. Have you explained which decision someone is presented with (and what decision they ideally make)?
2. Have you compared a suggested tool for shaping behavior to other tools or not employing it?
3. Have you justified how a tool for shaping behavior will be (most) effective in the context of the decision and decision-maker, for example by including evidence?
4. Have you defined what kind of tool you are using specifically (what kind of choice architecture, or whether a punishment/reinforcement is positive/negative)
5. Have you explained the consequences on a person’s decision-making process of a certain tool?
6. Have you considered whether the behavior shaping is done ethically or manipulatively, and how to make a behavior shaping tool more transparent?

## Common pitfalls

1. Not supporting a choice for a certain behavior-shaping tool sufficiently, for example because you’re employing a novel method without proper psychological analysis.
2. Not understanding what type of behavior-shaping tool you are employing, and thus missing the nuanced effect of that tool compared to other tools.
3. Employing a behavior-shaping tool in a manipulative way and not addressing this aspect (sufficiently).
4. Missing the effect of unique features of the agent that is influenced or the context in which they are.

## Applying the HC at Minerva

1. Business: When designing a product or service, you can think about ways to influence your target audience when they interact with it. First of all, it is good to explain why a certain tool for shaping behavior will increase success of your product, for example by including evidence of similar tools working or by backing it up with some psychological analysis. Secondly, the concept of libertarian paternalism – or the ethics of shaping behavior more generally – will help you address concerns of manipulation. Explain why the option you are hoping your audience to opt for is beneficial to them, and why you are still leaving them with a choice. Lastly, make sure to explain the influence of specific features of the audience and context on your chosen tools or make a roadmap for how you expect (different) consumers to respond to the tools you employ..
2. Incentive Structures (i.e. in Politics/History/Law): Institutions and organizations that (self-)govern people often create “incentive structures.” These are often in the forms of laws, rules, regulations, procedures, protocols. If you are investigating a (change in) incentive structures, try to identify which types of behavior the system tries to promote or discourage. Also think about the different people they have influence over and how different responses to incentive structures might prove challenging (#differences). For example, a government might try to enable and incentivize people to take public transportation for necessary things like their job or caring for their family. They decrease prices, but this might at the same time incentivize people to unnecessarily take public transportation too often. Great applications might compare different incentive structures and explain why certain ones work better in a given context, taking into account the place and capabilities of the institution, as well as the kinds of people they’re trying to influence and the way they would respond in a variety of ways.

## Applying the HC outside Minerva

Raising kids (and other inter-family communication): There are many theories on how children should be raised. Forms of punishment that include violence are decreasing and research shows (unsurprisingly) that harsh and strict methods for raising children usually backfires or induces forms of trauma. “Gentle parenting” is an approach to parenting that emphasizes respect, empathy, and understanding in interactions with children. It seeks to create a nurturing and supportive environment that fosters the emotional, social, and cognitive development of children while maintaining their dignity and autonomy. Instead of relying on traditional disciplinary methods that might involve punishment or rewards, gentle parenting focuses on communication, cooperation, and problem-solving. With this method, incentives and disincentives are nuanced and focused on cultivating skills and adaptability in a kid, as well as allowing for natural consequences to teach children a lesson, instead of directly focusing on specific behaviors that you want to increase or decrease the frequency of.

## Key resources

1. Mcleod, Saul. (Updated July 24, 2023) ‘Operant Conditioning In Psychology: B.F. Skinner Theory’, https://www.simplypsychology.org/operant-conditioning.html
- This resource explains how behavior is psychologically encouraged or discouraged through operant conditioning: punishments and reinforcements. Note the differences between positive and negative reinforcement/punishment, and how response and extinction rates are affected.
2. McAllister, K. & Morgan, R. (2023). Nudge: A subtle tool for shaping behavior. Minerva Guide 12. https://docs.google.com/document/d/1leQc29b8RpOL7K4mUw5Vx_v--OkSD6tSv18Mey9MkzQ/edit
- This whitepaper introduces the concept of a “nudge,” discusses ethical perspectives that developed in response, and provides several illustrative examples. It includes: a definition of a nudge, 'the nudge toolkit,' and the ethical considerations (particularly those linked to the idea of 'libertarian paternalism').

## Custom HC guides

- [Nudge: A subtle tool for shaping behavior](https://docs.google.com/document/d/1leQc29b8RpOL7K4mUw5Vx_v--OkSD6tSv18Mey9MkzQ/edit)

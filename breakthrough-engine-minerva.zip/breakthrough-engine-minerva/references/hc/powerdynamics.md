# #powerdynamics — Minerva HC Handbook

> Source: [https://my.minerva.edu/academics/hc-resources/hc-handbook/powerdynamics/](https://my.minerva.edu/academics/hc-resources/hc-handbook/powerdynamics/)
> **Habit of Mind** · Cornerstone course: Complex Systems · Competency: Interacting Effectively → Working with others
> Taught in: Complex Systems | Semester One · Unit: Individuals in Society
> Big Question: How do we change society?

## Definition

**#powerdynamics** — Recognize different sources of power and use them to analyze situations and influence others.

> **Pitch:** Power is like seasoning. You may only need a little if you find the right kind for the context and deploy it effectively.

Power, in general, is one’s ability to get others to do what they otherwise wouldn’t do. Though we often associate power with formal authority or the threat of violence, there are various sources of power including information, relationships, expertise, and charisma. Understanding different approaches to influencing others can allow one to apply them effectively, as well as unpack and analyze group dynamics and social situations.

## Worked example

The city you live in has instituted participatory budgeting and you have decided to participate in the first meeting, where any citizen who wants can come, deliberate, and eventually vote on ways to spend a portion of the city’s budget. The mayor sits on the table on the stage of the packed auditorium and kicks off the discussion, offering a detailed plan for a celebration of the city’s 100th anniversary this year, with fireworks, musical performances, and the like. The mayor speaks for a long while until someone yells that the mayor should let others talk, which is followed by cheers of agreement from around the room. The mayor attempts to continue talking but gives up as he realizes that no one can hear him over the noise. Different citizens then take the opportunity to speak, including a well-known architect and an enthusiastic young biking advocate. The architect suggests the money should be put into earthquake preparation, citing the age of the buildings downtown and the dated set of construction regulations in the state. The bike advocate argues for improved bike lanes and traffic lights, peppering his presentation with jokes and anecdotes that the crowd seems to enjoy. At the end of the evening, there is a vote and the three proposals that get most votes are those that caught your attention. While the mayor is disappointed that his proposal only made it to the third place, you think it’s quite surprising it got votes at all given the importance of other issues raised. It seems to you that the mayor had some sway over the vote given his position of authority. The success of the bike lane proposal surprises you, and you believe it did better than other more important proposals because of its advocate’s charisma and humor. In the end, you are happy that the architect’s expertise helped her carry the day as her proposal gets most votes.

> **Footnote:** Identifies a variety of sources of power and how they were used, including noting the shifting relevance of different sources of power in a changing situation. The analysis of the relative power of individuals explains the group’s behavior in this situation and can be used to guide effective interactions in the future.

## Is it this HC?

Is #powerdynamics the right HC? If the answer to the following questions is yes, #powerdynamics could be useful:

- Are you looking at how humans can influence each other?

- Are you considering the origin and distribution of power in a system/group/organization?

- Are you looking at how different forms of power work (and can be utilized)?

- Are you using an understanding of sources of power to optimize your ways of influencing others? 

- Are you offering nuanced interpretations about sources of power as part of a social critique? 

Depending on the focus of the work, there might be other applicable HCs to consider. Consult the following table listing possible related HCs.

### When to choose a related HC instead

| Consider | Choose it when the work… |
|---|---|
| [#leadprinciples](leadprinciples.md) | Analyzes principles of effective leadership. Leadership always depends on understanding and exercising power, and power dynamics justify different leadership principles. |
| [#shapingbehavior](shapingbehavior.md) | Analyzes how rewards/punishments, (dis)incentives, and nudges affect behavior. Implementing these strategies is also a form of exercising power over other people. |
| [#conformity](conformity.md) | Analyzes social norms and contrarianism, and reasons to be contrarian or conform. #powerdynamics might apply when you explore how social norms arise from power structures and how they are used to exercise/reinforce power. |
| [#networks](networks.md), [#systemmapping](systemmapping.md) (and other complex systems HCs) | Analyzing how network structure affects system outcomes. Since the power of relationships/networks is one of the most important forms of power, you should analyze the design of the network and relationships to see how to operate most effectively within this system. #powerdynamics relates to how power (like information/expertise) is distributed. |
| [#strategize](strategize.md), [#negotiate](negotiate.md) | Uses insights about strategic thinking and negotiation approaches. With these HCs, you must understand your position relative to the actors you interact with to find leverage. Note that BATNA’s and SWOTs are examples of evaluating your sources of power or influence. |

## Self-study Q&A (5 questions)

**Q1. What are examples of sources of power (at an individual level)?**

Examples of a good starting point to an answer are power of: 
- Charisma - the influence generated by a leader’s style, persona, or archetype. Sometimes called “Referent Power.” 

- Position -the (formal) authority from a title or standing in a group or organization. Sometimes called “Legitimate Power.”

- Relationship - the influence that leaders gain through their formal and informal relationships both inside and outside of their organizations

- Network - similar to the power of relationships/position, but specifically about the power one derives from the place they occupy within a network of an organization or group, for example, as a central node vs. as a connector, and so on.

- Expertise - the influence that comes from developing and communicating specialized knowledge or ability (or the perception thereof).

- Information -  the control generated through the use (or withholding) of intelligence, the power in how evidence is deployed to make an argument.

- Punishment and Reward - the ability to sanction individuals for failure to conform to standards or expectations and reward or recognize them for adhering to them. This also includes the power to set those standards (often in the form of rules or laws) in the first place. Often called “Disciplinary Power.”

- Moral authority/reputation - the degree to which an actor, by their perceived moral stature, can persuade others to adopt a particular belief or take a specific course of action.

Discursive or Symbolic - the degree to which knowledge production and discourse are shaped by the language and symbols created and employed by those who hold this power. A frequent use of this source of power is in framing. This form of power broadly includes an understanding, service, or criticism of various social constructs.

**Q2. What are examples of the three faces of power, as described by Lukes?**

The first face of power - visible, direct, decisional power, is explained by the ability of one individual to influence the behavior of another individual, without changing their perception of the issue. It occurs when the first individual has greater resources that they use to make the other person do something they don’t want to do. An example of this would be paying someone to vote for you at the elections, offering them a job in turn for a vote, or threatening to report them to the police if they refused to do what you asked.

The second face of power - hidden, non-decisional, institutional power, is explained by the ability of one person/group to exclude the other person/group from the decision-making process, thus preventing certain issues from arising. A famous example of this would be the Jim Crow laws or the political party in power using institutions to systematically make it harder for a certain group of people to vote (e.g., poor people) by putting voting polls in places most poor people are unable to reach. This way the excluded group has no way of raising an issue, so it doesn’t need to be debated/decided upon (non-decisional) at all.

The third face of power - invisible, ideological, cultural, or sociological power, is explained by one agent’s ability to shape the other agent's preferences, by manipulating the subconscious way that society constructs meaning from social myths, language, and symbols. An example of this would be a government directly controlling information by regulating the way that history is narrated and taught in schools or spreading propaganda through media channels.

**Q3. What is the difference between more formal and informal sources of power, and which is usually more significant?**

Formal sources typically involve the ability to punish and reward, stemming from bureaucracy, structures, or institutions that allow you to determine certain things or a set of agreements or procedures that explain who decides what.

Informal power sources typically involve the power of adhering within relationships and networks of people, social power, charisma, social status, expertise and information, power in identity, persuasive power, and power to determine the discourse or language.

People respond reasonably to structures, punishments, rewards, etc.. Still, they are often more motivated by a person’s appeal as an authority in their relationship with that person or based on what a person has to offer and how their identity is perceived. So, don’t overlook the importance of analyzing informal power dynamics. 

Note that formal power structures influence how informal power structures are allowed to work and vice versa.

**Q4. Imagine the following examples: 
- Example 1: A relatively powerful country (such as Germany) is trying to influence its neighbors to adopt a progressive climate policy.

- Example 2: A new CEO of a medium-sized company is trying to get their employees to adopt an ecologically conscious approach.

Consider two ways of exercising their power to achieve their goals:

- Strategy A (formal power) - Using punishment and reward systems, encouraging the actions/policies they want to see, and using anything they can do to punish undesirable behavior (#shapingbehavior), but also talking to others and demanding specific changes (#negotiate).

- Strategy B (informal power) - Using soft power and setting a good example. For the country, this means adopting policies and publicly showing off the effect of these. For the company, the CEO will come to work on a bike and keep talking in informal conversations about how important he finds climate change and his responsibility as a CEO.

Which type of power will be more likely to be adequate for each situation?**

Of course, it depends, but B tends to be better. Still, they should use both strategies! Here is how I might play out for each situation:

Example 1: Since Germany is a formally powerful country, they have significant negotiating power, and the repercussions of working against its aims will be taken seriously. Adopting Strategy A could be highly effective given the right opportunities to exercise this kind of formal power, as they might have at a U.N. Climate Summit. However, such an approach might directly employ Germany’s ability to create change, and it is limited to the avenues of formal power they have and the opportunities for exercising that power that might arise. It also might encourage countries to respond more strongly by using their legal authority to counter what you advocate for. This is to be expected when Germany negotiates with a powerful oil-producing government, for example.

Alternatively, Strategy B would move beyond these formal uses of power. It takes time to build up the reputation of a climate-conscious country and build a network of publicity and cooperation that will help other countries adopt similar strategies. However, its result may be a more resilient power structure that depends on exchanging beneficial information, experience, and relationships. You might use as evidence the role Scandinavian countries have played in modeling progressive education systems and affecting education in other countries through these means.

Example 2: Since the company is medium-sized, not everyone will be in contact with the CEO. Strategy B might not inspire enough employees immediately since lower-level employees are not directly in the CEO’s network. However, informal sources of power can be very effective in creating a willingness to change among managers and investors, which could make it a promising strategy when employees are already ready to change. Bureaucracy and corporate structures might not allow for ideas developed at the level of managers to reach those in charge of the corporate networks. Similarly, if the question asked about a lower-level manager, adopting Strategy B in their department could be highly effective!

So, in our case, Strategy A might give the CEO more leverage to implement sustainability throughout the organization directly; it is essential to examine #shapingbehavior to find out whether punishments or rewards are effective for specific actions.

**Q5. What is oppression or domination?**

Oppression or domination are sometimes used interchangeably, but in many disciplines, they have specific conceptual uses that should be carefully delineated. Oppression typically refers to institutional or structural constraints on the self-development of people by their membership in a group. Members of oppressed groups might suffer from economic exploitation, social marginalization, or cultural imperialism. But, importantly, oppression is usually used to refer to people subject to these constraints by their group membership. Domination is often used to refer to structural or institutional conditions that can affect anyone, regardless of whether they are a member of an oppressed group. In both cases, oppression and domination refer to denials of a person’s agency; remedies focus on institutional and structural forms of empowerment. As with other complex concepts, using textual resources to bolster your interpretation and use of specific interpretations and to check with your instructor about course-specific norms is helpful.

## Guided reflection (proficiency checklist)

1. Have you considered a variety of types of power at different levels?
2. Have you explained which sources of power are context-relevant and how they operate?
3. Have you explained where power comes from and how it’s maintained (or ended)?
4. Have you shown the effects of (different types of) power?
5. Have you provided evidence to back up your explanations and analyses of sources and effects of power?
6. Have you compared multiple ways to utilize power to defend your identification of the most effective strategy?
7. Have you investigated the object of power (who is affected by the power) and how their unique features or the relationship with them demands specific power?
8. Have you explained the leverage in a specific form of power and the (expected) effect on the group?

## Common pitfalls

1. Assuming power is held by one individual or unit in analysis without including how power is distributed or part of a larger structure.
2. Not placing identified power dynamics within theoretical frameworks for power.
3. Seeing power as static instead of dynamic – thus not accounting for changes in power.
4. Failing to provide evidence or an established framework in support of your analysis or relying on superficial explanations of sources or relationships of power.

## Applying the HC at Minerva

1. Political science: One standard definition of political science is “the study of power,” which shows how central #powerdynamics will be to this field, mostly when describing and analyzing power. You will encounter various paradigms that explain power as working in a few ways: from residing in institutions or structures to coming from pure self-interest of states, from forms of soft power such as culture to studies of hard power like military capabilities. In general, it is wise to focus on explaining what definitions of power you will be using, often referring to existing methods (either complying with those or explaining why you would do it differently). Since #powerdynamics might overlap with some LOs, asking your professor for advice on applying this HC and course LOs together is helpful.
2. Structural power (and injustice): In philosophy, history, and other humanities and social sciences, you might encounter studies of structural forms of power. These tend to call into question assumptions about sources of power, drawing to the surface less obvious ways power, oppression, and domination are often at work in our societies. Think about ways in which power comes from non-obvious sources, such as the power coming from recording, naming, or classifying. It is relevant for anyone working with data, definitions, or historical records. If you point out such non-obvious power sources, describe how they work. Another great application of #powerdynamics is to tell how different powers change over time. Finally, there are practical applications of using power. You might create an understanding of a structural power and explain how to channel or challenge it.
3. Business: Power is relevant in many areas of business, especially in courses on management and strategy. Power within companies is about analyzing the ability to understand or influence the behavior of those making up the company. Power without companies focuses on the influence on/from consumers, competitors, or institutions. You might analyze a company’s relative power, which can direct suggestions on their strategic approach. Promising applications of #powerdynamics in business will often explain the type of power best utilized to create leverage and achieve a specific goal. Still, it can also be applied more generally and descriptively, for example, by explaining why a particular event happened within a sector or business. Often, you will think about #strategize together with #powerdynamics for business.
4. Computer Science: As technology rapidly advances, it is wise to think about forms of power in technology. Whether the power of defining, categorizing, and analyzing will interest data scientists and those developing algorithms or the economic and political power exercised through social media platforms. Designing technological tools in specific ways is essential to how power structures in our society will continue to evolve. For example, the Cambridge Analytica scandal showed that people’s behavior could be influenced by their social media feeds. Many actors were involved in making that manipulative power possible - from the engineers who designed the algorithm to those providing misleading input to that algorithm.
5. Psychology: Psychological studies of power might look at how power is perceived and how people respond to power being exercised on them. Since power arises when we collectively believe in it (social construct), psychology is critical to understanding its nature.

## Applying the HC outside Minerva

1. Working groups, Networks: The power of relationships may be the most significant source of power across. It encompasses a great many things: the power you have in a network from (the diversity, amount, or structure of) your connections, the power you have based on the type of connection you have with one individual, or the way power is inherently based in how we relate to one another in an entire society (and how it is distributed across groups of people unequally).
2. Personal relationships: When focusing on individual relationships, whether romantic, familial, friendly, professional, or other, we find that power is an essential factor in our interactions. A nuanced, context-sensitive, and relational understanding of power is necessary here. Depending on your relationship type and history with a person, different sources of power might affect that relationship. Power is more ambiguous and tends to change based on the perception of one another.
3. Activism: Activism is often an exercise in fighting against rigid structures and institutions. As the saying goes, there is power in numbers, and activist campaigns can set an agenda and draw attention to specific topics or spark debate. Because you often need more formal power as an activist, you must channel and exercise your power creatively. An example is activism through art, in which controversial ideas are brought to a larger public to spark conversation.

## Key resources

1. Bal, Vidula, Michael Campbell, Judith Steed, and Kyle Meddings. 'The Role of Power in Effective Leadership,' 1 January 2008.
- This report lays out significant power uses in leadership, so be mindful of the overlaps with #leadprinciples when using this resource. It also discusses how power is leveraged with colleagues or managers. The authors argue that the power of relationships is the most vital of the types discussed. — [link](https://my.minerva.edu/academics/hc-resources/hc-handbook/leadprinciples/)
2. Castells, Manuel. 'Network Theory| A Network Theory of Power'. International Journal of Communication 5, no. 0 (8 April 2011): 15.
- From communications science, relevant for anyone involved in media/information networks. This article provides a lens of power through only networks. It is a great way to explain the distributed and interaction-based aspects of power, as well as the power in structures of people. An essential insight from the article is that networks program themselves by determining (or reinforcing, most likely) the divisions of power. Terms to look out for include programming vs. switching power and metaprogramming. Note that it is from a communications science perspective, meaning that analysis of the flow of information as power is more emphasized than sources of power like institutions.
3. Moon, Suerie. 'Power in Global Governance: An Expanded Typology from Global Health.' Globalization and Health 15, no. 1 (28 November 2019): 74. https://doi.org/10.1186/s12992-019-0515-5
- This is an example of how power can be seen in a larger, structural context – in this case, governance through a global health perspective. The discussions on different definitions of power show the gaps in particular understandings of power. Ultimately, the author lays out a synthesized typology of power in governance institutions, but these terms are insightful in other contexts, too. Seek out Table 1 for a good overview of the types and examples!
4. McCammon, Christopher. 'Domination'. In The Stanford Encyclopedia of Philosophy, edited by Edward N. Zalta, Winter 2018. Metaphysics Research Lab, Stanford University, 2018. https://plato.stanford.edu/archives/win2018/entries/domination/
- This resource cleverly explains how to analyze domination as an exercise of power. Pay particular attention to the idea that power in domination sometimes comes from the ability to affect someone rather than exercising that power. The resource also categorizes power in a few different ways, which contrasts the more individual definitions of power discussed in this Handbook.
5. Rebolledo, M. (2023, April 24). Iris Marion Young's Five Faces of Oppression. Critical Legal Thinking. https://criticallegalthinking.com/2023/04/24/iris-marion-youngs-five-faces-of-oppression/  
- This is a short overview of political philosopher Iris Marion Young's highly influential account of oppression's five different aspects (or faces): exploitation, marginalization, powerlessness, cultural imperialism, and violence. Young's distinctions have had broad applicability in the late 20th and early 21st centuries and offer a way to distinguish between oppression and domination.
6. Sardo, Michael C. (March 24th, 2020). Pols 101 Class 23: The Three Faces of Power [Video] Youtube. https://www.youtube.com/watch?v=19gpbZl4DpU  
- This is a lecture video by Prof. Michael Sardo on the 3 dimensions of power theory developed by Steven Lukes, with some additions and modifications made by Lukes' student, John Gaventa. The first part of the video (the first ~20 minutes) focuses on explaining the three dimensions/faces of power.
7. Tappan, Mark. 'Reframing Internalized Oppression and Internalized Domination: From the Psychological to the Sociocultural.' Teachers College Record. 108 (1 October 2006): 2115–44. https://doi.org/10.1111/j.1467-9620.2006.00776.x. 
- This in-depth resource describes a process by which oppression and domination are internalized, leading to dynamics that further reduce the power of a marginalized group. Read this resource if you're interested in the psychology behind these topics or focusing on systems of power.

